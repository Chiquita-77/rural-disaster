package com.lg.ruraldisasterplatform.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@TableName("emergency_order")
public class EmergencyOrderEntity {

    @TableId(type = IdType.AUTO)
    private Long orderId;

    private String title;
    private String content;
    private Long publisherId;
    private String publisherName;

    @TableField(value = "publisher_time", fill = FieldFill.INSERT)
    private LocalDateTime publishTime;

    private Integer status;

    // 修复：把 Integer 改成 String，和数据库里的字符串值（如“全村”）对齐
    @TableField("scope_type")
    private String scopeType;

    @TableField("village_ids")
    private String villageIds;
}