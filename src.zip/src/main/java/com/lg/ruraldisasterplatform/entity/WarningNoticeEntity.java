package com.lg.ruraldisasterplatform.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import java.time.LocalDateTime;

/**
 * 灾害预警通知实体类（对应warning_notice表）
 * 字段和数据库表完全一致
 */
@Data
@TableName("warning_notice")
public class WarningNoticeEntity {

    /**
     * 预警ID（主键）
     */
    @TableId(type = IdType.AUTO)
    private Long warningId;

    /**
     * 预警标题
     */
    private String title;

    /**
     * 预警内容
     */
    private String content;

    /**
     * 灾害类型ID（关联disaster_type表id）
     */
    private Long disasterTypeId;

    /**
     * 目标村庄ID（多个用逗号分隔）
     */
    private String targetVillageIds;

    /**
     * 发布人ID（关联管理员/信息员表）
     */
    private Long publisherId;

    /**
     * 发布时间
     */
    private LocalDateTime publishTime;

    /**
     * 是否已启用（原推送状态，语义改为：0=禁用，1=启用）
     */
    private Integer isPushed;

    /**
     * 启用/禁用时间
     */
    private LocalDateTime pushTime;

    /**
     * 已读人数
     */
    private Integer readCount;

    /**
     * 未读人数
     */
    private Integer unreadCount;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 更新时间
     */
    private LocalDateTime updateTime;

    // 新增：发布者类型（admin=管理员，info_user=信息员）
    private String submitterType;
}