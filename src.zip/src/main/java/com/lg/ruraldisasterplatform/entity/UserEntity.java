package com.lg.ruraldisasterplatform.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@TableName("user_inf") // 表名是 user_inf，不是 user_info
public class UserEntity {

    @TableId(value = "user_id", type = IdType.AUTO)
    private Long userId;

    private String username;
    private String password;
    private String phone;
    private String avatar;

    private Integer status; // 1=启用，0=禁用
    private Integer role;   // 1=村民, 2=信息员, 3=管理员

    @TableField("village_id")
    private Long villageId; // 所属村庄

    @TableField("town_id")
    private Long townId;    // 所属乡镇（管理员用）

    @TableField("create_time")
    private LocalDateTime createTime;

    @TableField("update_time")
    private LocalDateTime updateTime;

    @TableLogic // 逻辑删除
    @TableField("is_deleted")
    private Integer isDeleted;
}