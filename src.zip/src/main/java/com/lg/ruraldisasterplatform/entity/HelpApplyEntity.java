package com.lg.ruraldisasterplatform.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.time.LocalDateTime;

/**
 * 支援申请表实体类
 * 对应表：help_apply
 */
@Data
@TableName("help_apply")
public class HelpApplyEntity {

    /**
     * 申请ID(主键)
     */
    @TableId(type = IdType.AUTO)
    private Long applyId;

    /**
     * 村庄ID
     */
    private Long villageId;

    /**
     * 申请人ID
     */
    private Long applicantId;

    /**
     * 申请标题
     */
    private String title;

    /**
     * 申请详情
     */
    private String detail;

    /**
     * 图片路径(多个用,分隔)
     */
    private String imagePath;

    /**
     * 提交时间
     */
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime submitTime;

    /**
     * 审批人ID
     */
    private Long approverId;

    /**
     * 调度详情
     */
    private String dispatchDetail;

    /**
     * 处理时间
     */
    private LocalDateTime handleTime;

    /**
     * 状态(0=待审批,1=已通过,2=已驳回)
     */
    private Integer status;
}