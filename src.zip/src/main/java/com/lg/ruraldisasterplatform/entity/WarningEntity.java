package com.lg.ruraldisasterplatform.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@TableName("warning_inf")
public class WarningEntity {

    @TableId(type = IdType.AUTO)
    private Long warningId;

    private String title;
    private String content;

    private Integer level;      // 1=低, 2=中, 3=高, 4=紧急
    private Integer type;       // 1=暴雨, 2=洪水...

    private String locationDesc;

    private Long villageId;
    private Long townId;
    private Long publisherId;

    private LocalDateTime publishTime;
    private LocalDateTime expireTime;

    private Integer status;     // 0=草稿,1=发布,2=过期
    @TableLogic                 // MyBatis-Plus 软删除注解
    private Integer isDeleted;

    private LocalDateTime createTime;
    private LocalDateTime updateTime;
}