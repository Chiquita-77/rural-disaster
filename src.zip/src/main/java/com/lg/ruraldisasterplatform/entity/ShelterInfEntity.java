package com.lg.ruraldisasterplatform.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@TableName("shelter_inf")
public class ShelterInfEntity {

    @TableId(type = IdType.AUTO)
    private Long shelterId;

    private String name;              // 避难所名称（如“XX村小学”）
    private String address;           // 详细地址
    private Double latitude;          // 经度
    private Double longitude;         // 纬度
    private Integer capacity;         // 最大容纳人数
    private Integer currentOccupancy; // 当前人数
    private Integer status;           // 状态：0=关闭, 1=开放, 2=满员
    private String contactPerson;     // 联系人
    private String contactPhone;      // 联系电话
    private String facilities;        // 设施说明（如“有水、电、厕所”）
    private String photoUrl;          // 外观照片

    private Long villageId;           // 所属村庄ID
    private Long townId;              // 所属乡镇ID

    private Integer isDeleted;        // 软删除：0=正常, 1=删除
    private LocalDateTime createTime;
    private LocalDateTime updateTime;
}