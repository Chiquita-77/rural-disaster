package com.lg.ruraldisasterplatform.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import java.time.LocalDateTime;

/**
 * 防灾指南实体类（对应disaster_guide表）
 */
@Data
@TableName("disaster_guide")
public class DisasterGuideEntity {

    /**
     * 指南ID（主键）
     */
    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 指南标题
     */
    private String title;

    /**
     * 指南内容
     */
    private String content;

    /**
     * 封面图URL
     */
    private String coverImage;

    /**
     * 指南分类（如暴雨/滑坡/洪水/地震）
     */
    private String category;

    /**
     * 排序号（用于前端展示排序）
     */
    private Integer sortNum;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 更新时间
     */
    private LocalDateTime updateTime;
}