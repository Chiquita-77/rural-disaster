package com.lg.ruraldisasterplatform.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import java.time.LocalDateTime;

/**
 * 应急指令实体类
 * 对应表：emergency_instruction
 */
@Data
@TableName("emergency_instruction")
public class EmergencyInstructionEntity {
    /** 指令ID */
    @TableId(type = IdType.AUTO)
    private Long instructionId;
    /** 指令标题 */
    private String title;
    /** 指令内容 */
    private String content;
    /** 目标村庄ID（JSON数组） */
    private String targetVillageIds;
    /** 发布时间 */
    private LocalDateTime createTime;
    /** 发布人ID（乡镇管理员） */
    private Long createUserId;
    /** 目标村庄名称 */
    private String villageName;
}