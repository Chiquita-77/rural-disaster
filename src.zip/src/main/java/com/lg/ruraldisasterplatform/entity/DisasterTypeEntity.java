package com.lg.ruraldisasterplatform.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import java.time.LocalDateTime;

/**
 * 灾害类型实体类（对应disaster_type表）
 */
@Data
@TableName("disaster_type")
public class DisasterTypeEntity {

    /**
     * 主键ID
     */
    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 灾害名称（如暴雨、滑坡）
     */
    private String disasterName;

    /**
     * 预警级别数量（4=蓝黄橙红四级）
     */
    private Integer warningLevel;

    /**
     * 预警级别说明（各等级标准）
     */
    private String warningLevelDesc;

    /**
     * 灾害成因
     */
    private String disasterCause;

    /**
     * 主要危害
     */
    private String disasterHarm;

    /**
     * 应对要点
     */
    private String responsePoints;

    /**
     * 排序号（用于前端展示排序）
     */
    private Integer sortNum;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 更新时间
     */
    private LocalDateTime updateTime;
}