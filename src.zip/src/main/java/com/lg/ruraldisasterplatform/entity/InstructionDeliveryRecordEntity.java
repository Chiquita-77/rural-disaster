package com.lg.ruraldisasterplatform.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import java.time.LocalDateTime;

/**
 * 应急指令送达记录实体类
 * 对应表：instruction_delivery_record
 */
@Data
@TableName("instruction_delivery_record")
public class InstructionDeliveryRecordEntity {
    /** 记录ID */
    @TableId(type = IdType.AUTO)
    private Long recordId;
    /** 关联指令ID */
    private Long instructionId;
    /** 接收用户ID */
    private Long userId;
    /** 阅读时间（NULL=未读） */
    private LocalDateTime readTime;
    /** 用户所属村庄ID */
    private Long villageId;
}