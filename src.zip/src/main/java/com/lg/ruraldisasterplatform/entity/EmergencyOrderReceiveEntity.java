package com.lg.ruraldisasterplatform.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import lombok.Data;
import java.time.LocalDateTime;

@Data
public class EmergencyOrderReceiveEntity {

    @TableId(type = IdType.AUTO)
    private Long recordId;

    private Long orderId;

    // 数据库字段是 receive_user_id，显式指定映射
    @TableField("receive_user_id")
    private Long receiveUserId;

    private Long villageId;

    // 数据库字段是 is_read，显式指定映射
    @TableField("is_read")
    private Integer isRead;

    private LocalDateTime readTime;
}