package com.lg.ruraldisasterplatform.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.time.LocalDateTime;
import java.util.List;

@Data
@TableName("disaster_report")
public class DisasterReportEntity {

    @TableId(type = IdType.AUTO)
    private Long reportId;

    private String title;
    private String content;
    private String images;
    private String location;
    private Long villageId;

    private Integer status;
    private String handleResult;
    @TableField("handle_time")
    private LocalDateTime handleTime;

    @TableField(value = "create_time", fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    @TableField(exist = false)
    private List<String> imageList;

    // 👇 补上这个内部枚举，和 Controller 对应
    public enum StatusEnum {
        PENDING(0, "待处理"),
        HANDLED(1, "已处理");

        private final int code;
        private final String desc;

        StatusEnum(int code, String desc) {
            this.code = code;
            this.desc = desc;
        }

        public int getCode() {
            return code;
        }

        public String getDesc() {
            return desc;
        }
    }
}