package com.lg.ruraldisasterplatform.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.time.LocalDateTime;

/**
 * 信息员风险提示操作记录实体类
 */
@Data
@TableName("info_user_tip_operate_log")
public class InfoUserTipOperateLogEntity {

    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 信息员用户ID（关联user_inf.user_id）
     */
    private Long infoUserId;

    /**
     * 关联风险提示ID（关联risk_tip.tip_id）
     */
    private Long riskTipId;

    /**
     * 风险提示标题（冗余存储）
     */
    private String tipTitle;

    /**
     * 发布时间（冗余存储risk_tip.create_time）
     */
    private LocalDateTime publishTime;

    /**
     * 审核状态：0=待审核，1=已通过，2=已驳回
     */
    private Integer reviewStatus;

    /**
     * 审核意见（冗余存储risk_tip.review_comment）
     */
    private String reviewComment;

    /**
     * 记录创建时间
     */
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    /**
     * 记录更新时间
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
}