package com.lg.ruraldisasterplatform.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@TableName("support_request")
public class SupportRequestEntity {

    @TableId(type = IdType.AUTO)
    private Long requestId;        // 申请ID

    private String title;          // 申请标题
    private String content;        // 申请内容
    private String resources;      // 所需资源（JSON数组：["帐篷", "饮用水"]）
    private Long villageId;        // 申请村庄ID
    private String villageName;    // 村庄名称（冗余，便于展示）

    private Integer status;        // 状态：0=待审批, 1=已批准, 2=已拒绝
    private String approvalResult; // 审批意见

    // 关键：指定数据库字段名，避免映射失败
    @TableField("approve_time")
    private LocalDateTime approveTime; // 审批时间

    // 自动填充创建时间，无需手动赋值
    @TableField(value = "create_time", fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    // 状态枚举：统一管理，避免硬编码
    public enum StatusEnum {
        PENDING(0, "待审批"),
        APPROVED(1, "已批准"),
        REJECTED(2, "已拒绝");

        private final int code;
        private final String desc;

        StatusEnum(int code, String desc) {
            this.code = code;
            this.desc = desc;
        }

        public int getCode() {
            return code;
        }
    }
}