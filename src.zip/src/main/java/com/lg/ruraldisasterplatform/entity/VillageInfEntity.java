package com.lg.ruraldisasterplatform.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("village_inf")
public class VillageInfEntity {
    @TableId(value = "village_id", type = IdType.AUTO)
    private Long villageId;

    private String villageName;
    private String province;
    private String city;
    private String district;
    private String address;
    private String contactPerson;
    private String phone;

    @TableLogic
    private Integer isDeleted;

    private LocalDateTime createTime;
    private LocalDateTime updateTime;
}