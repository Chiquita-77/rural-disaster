package com.lg.ruraldisasterplatform.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.time.LocalDateTime;

/**
 * 村民灾情上报操作记录实体类
 */
@Data
@TableName("villager_report_operate_log")
public class VillagerReportOperateLogEntity {

    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 村民用户ID（关联user_inf.user_id）
     */
    private Long villagerId;

    /**
     * 关联灾情上报ID（关联disaster_report.report_id）
     */
    private Long disasterReportId;

    /**
     * 灾情上报标题（冗余存储）
     */
    private String reportTitle;

    /**
     * 上报时间（冗余存储disaster_report.create_time）
     */
    private LocalDateTime reportTime;

    /**
     * 处理状态：0=待处理，1=处理中，2=已完成，3=已驳回
     */
    private Integer handleStatus;

    /**
     * 处理结果（冗余存储disaster_report.handle_result）
     */
    private String handleResult;

    /**
     * 记录创建时间
     */
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    /**
     * 记录更新时间
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
}