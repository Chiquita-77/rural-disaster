package com.lg.ruraldisasterplatform.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.time.LocalDateTime;

/**
 * 风险提示实体类（对应 risk_tip 表）
 */
@Data
@TableName("risk_tip") // 对应数据库表名
public class RiskTipEntity {

    /**
     * 风险提示ID（主键，自增）
     */
    @TableId(type = IdType.AUTO)
    private Long tipId;

    /**
     * 提示标题
     */
    @TableField("title")
    private String title;

    /**
     * 提示内容
     */
    @TableField("content")
    private String content;

    /**
     * 所属村庄ID
     */
    @TableField("village_id")
    private Long villageId;

    /**
     * 逻辑删除状态：1=正常, 0=删除
     */
    @TableField("status")
    private Integer status;

    /**
     * 审核状态：0=待审核, 1=通过, -1=驳回
     */
    @TableField("review_status")
    private Integer reviewStatus;

    /**
     * 审核意见（驳回时填写）
     */
    @TableField("review_comment")
    private String reviewComment;

    /**
     * 审核时间
     */
    @TableField("review_time")
    private LocalDateTime reviewTime;

    /**
     * 创建时间（插入时自动填充）
     */
    @TableField(value = "create_time", fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    // 序列化标识
    @TableField(exist = false)
    private static final long serialVersionUID = 1L;
}