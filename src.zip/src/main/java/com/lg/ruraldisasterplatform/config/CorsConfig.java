package com.lg.ruraldisasterplatform.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class CorsConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**") // 匹配所有接口（因为context-path已经是/api，无需再加）
                .allowedOriginPatterns("http://localhost:5173", "http://192.168.1.36:5173") // 允许所有前端地址
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS") // 增加OPTIONS预检请求
                .allowedHeaders("*")
                .allowCredentials(true)
                .maxAge(3600);
    }
}