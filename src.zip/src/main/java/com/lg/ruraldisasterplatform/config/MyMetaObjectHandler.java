package com.lg.ruraldisasterplatform.config;

import com.baomidou.mybatisplus.core.handlers.MetaObjectHandler;
import org.apache.ibatis.reflection.MetaObject;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

/**
 * MyBatis-Plus 字段自动填充配置
 * 用于自动填充创建时间、提交时间等字段
 */
@Component // 必须加这个注解，让Spring扫描到
public class MyMetaObjectHandler implements MetaObjectHandler {

    /**
     * 插入数据时自动填充（比如提交支援申请时填充submitTime）
     */
    @Override
    public void insertFill(MetaObject metaObject) {
        // 填充支援申请表的submitTime字段（LocalDateTime类型）
        this.strictInsertFill(
                metaObject,
                "submitTime", // 对应实体类的submitTime字段名
                LocalDateTime.class, // 字段类型
                LocalDateTime.now() // 填充当前时间
        );

        // 如果你还有其他表需要自动填充（比如createTime），可以继续加
        // this.strictInsertFill(metaObject, "createTime", LocalDateTime.class, LocalDateTime.now());
    }

    /**
     * 更新数据时自动填充（比如审批支援申请时填充handleTime）
     */
    @Override
    public void updateFill(MetaObject metaObject) {
        // 可选：填充处理时间（审批支援申请时用）
        this.strictUpdateFill(
                metaObject,
                "handleTime", // 对应实体类的handleTime字段名
                LocalDateTime.class,
                LocalDateTime.now()
        );
    }
}