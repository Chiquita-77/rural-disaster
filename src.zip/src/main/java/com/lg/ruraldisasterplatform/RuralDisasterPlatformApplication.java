package com.lg.ruraldisasterplatform;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.lg.ruraldisasterplatform.mapper")  // 扫描所有 Mapper 接口
public class RuralDisasterPlatformApplication {

    public static void main(String[] args) {
        SpringApplication.run(RuralDisasterPlatformApplication.class, args);
    }

}
