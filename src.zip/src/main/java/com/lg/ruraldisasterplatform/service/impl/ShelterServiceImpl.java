package com.lg.ruraldisasterplatform.service.impl;

import com.lg.ruraldisasterplatform.entity.ShelterInfEntity;
import com.lg.ruraldisasterplatform.mapper.ShelterInfMapper;
import com.lg.ruraldisasterplatform.service.ShelterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import java.util.List;

@Service
public class ShelterServiceImpl implements ShelterService {

    @Autowired
    private ShelterInfMapper shelterInfMapper;

    @Override
    public List<ShelterInfEntity> listByVillage(Long villageId) {
        return shelterInfMapper.selectList(
                new QueryWrapper<ShelterInfEntity>()
                        .eq("village_id", villageId)
                        .eq("is_deleted", 0)
                        .eq("status", 1)  // 只查“开放中”的
                        .orderByAsc("current_occupancy") // 人少的排前面
        );
    }

    @Override
    public ShelterInfEntity getById(Long shelterId) {
        return shelterInfMapper.selectById(shelterId);
    }
}