package com.lg.ruraldisasterplatform.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.lg.ruraldisasterplatform.entity.InfoUserTipOperateLogEntity;
import java.util.List;

/**
 * 信息员风险提示操作记录Service接口
 */
public interface InfoUserTipOperateLogService extends IService<InfoUserTipOperateLogEntity> {

    /**
     * 根据信息员ID查询我的风险提示发布记录
     * @param infoUserId 信息员ID
     * @return 操作记录列表
     */
    List<InfoUserTipOperateLogEntity> getMyTipLog(Long infoUserId);

    /**
     * 新增/更新操作记录（发布风险提示时调用）
     * @param logEntity 操作记录实体
     * @return 是否成功
     */
    boolean saveOrUpdateTipLog(InfoUserTipOperateLogEntity logEntity);
}