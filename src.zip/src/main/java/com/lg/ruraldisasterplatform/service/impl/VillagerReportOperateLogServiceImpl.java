package com.lg.ruraldisasterplatform.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.lg.ruraldisasterplatform.entity.VillagerReportOperateLogEntity;
import com.lg.ruraldisasterplatform.mapper.VillagerReportOperateLogMapper;
import com.lg.ruraldisasterplatform.service.VillagerReportOperateLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * 村民灾情上报操作记录Service实现类
 */
@Service
public class VillagerReportOperateLogServiceImpl extends ServiceImpl<VillagerReportOperateLogMapper, VillagerReportOperateLogEntity>
        implements VillagerReportOperateLogService {

    @Autowired
    private VillagerReportOperateLogMapper reportOperateLogMapper;

    @Override
    public List<VillagerReportOperateLogEntity> getMyReportLog(Long villagerId) {
        // 查询该村民的所有操作记录，按上报时间倒序
        return reportOperateLogMapper.selectByVillagerId(villagerId);
    }

    @Override
    public boolean saveOrUpdateReportLog(VillagerReportOperateLogEntity logEntity) {
        return this.saveOrUpdate(logEntity);
    }
}