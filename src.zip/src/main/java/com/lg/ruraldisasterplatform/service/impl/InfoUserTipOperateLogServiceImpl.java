package com.lg.ruraldisasterplatform.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.lg.ruraldisasterplatform.entity.InfoUserTipOperateLogEntity;
import com.lg.ruraldisasterplatform.mapper.InfoUserTipOperateLogMapper;
import com.lg.ruraldisasterplatform.service.InfoUserTipOperateLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 信息员风险提示操作记录Service实现类
 */
@Service
public class InfoUserTipOperateLogServiceImpl extends ServiceImpl<InfoUserTipOperateLogMapper, InfoUserTipOperateLogEntity>
        implements InfoUserTipOperateLogService {

    @Autowired
    private InfoUserTipOperateLogMapper tipOperateLogMapper;

    @Override
    public List<InfoUserTipOperateLogEntity> getMyTipLog(Long infoUserId) {
        // 查询该信息员的所有操作记录，按发布时间倒序
        return tipOperateLogMapper.selectByInfoUserId(infoUserId);
    }

    @Override
    public boolean saveOrUpdateTipLog(InfoUserTipOperateLogEntity logEntity) {
        return this.saveOrUpdate(logEntity);
    }
}