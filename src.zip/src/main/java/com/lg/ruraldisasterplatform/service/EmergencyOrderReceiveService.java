package com.lg.ruraldisasterplatform.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.lg.ruraldisasterplatform.entity.EmergencyOrderReceiveEntity;

/**
 * 应急指令送达记录Service
 */
public interface EmergencyOrderReceiveService extends IService<EmergencyOrderReceiveEntity> {

    /**
     * 查询用户未读指令数量
     */
    int getUnreadCount(Long userId);

    /**
     * 标记指令为已读
     */
    boolean markAsRead(Long orderId, Long userId);

    /**
     * 检查用户是否已接收该指令
     */
    boolean checkReceived(Long orderId, Long userId);
}