package com.lg.ruraldisasterplatform.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.lg.ruraldisasterplatform.entity.RiskTipEntity;
import com.lg.ruraldisasterplatform.mapper.RiskTipMapper;
import com.lg.ruraldisasterplatform.service.RiskTipService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Map;

/**
 * 风险提示服务实现类
 */
@Service
public class RiskTipServiceImpl extends ServiceImpl<RiskTipMapper, RiskTipEntity> implements RiskTipService {

    @Autowired
    private RiskTipMapper riskTipMapper; // 注入Mapper

    // 原有方法：联表查询待审核列表
    @Override
    public List<Map<String, Object>> getReviewListWithVillageName() {
        return this.getBaseMapper().selectReviewListWithVillageName();
    }

    // 新增：按审核状态统计
    @Override
    public List<Map<String, Object>> countTipByReviewStatus() {
        return riskTipMapper.countTipByReviewStatus();
    }

    // 新增：按村庄统计
    @Override
    public List<Map<String, Object>> countTipByVillage() {
        return riskTipMapper.countTipByVillage();
    }
}