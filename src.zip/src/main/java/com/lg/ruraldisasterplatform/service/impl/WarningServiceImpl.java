package com.lg.ruraldisasterplatform.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.lg.ruraldisasterplatform.entity.WarningEntity;
import com.lg.ruraldisasterplatform.mapper.WarningMapper;
import com.lg.ruraldisasterplatform.service.WarningService;
import org.springframework.stereotype.Service;

@Service
public class WarningServiceImpl extends ServiceImpl<WarningMapper, WarningEntity> implements WarningService {

    @Override
    public WarningEntity publish(WarningEntity warning) {
        // 你原来的发布逻辑
        this.save(warning);
        return warning;
    }

    @Override
    public IPage<WarningEntity> listByVillage(Long villageId, Integer status, Page<WarningEntity> page) {
        // 你原来的分页查询逻辑
        LambdaQueryWrapper<WarningEntity> qw = new LambdaQueryWrapper<>();
        if (villageId != null) {
            qw.eq(WarningEntity::getVillageId, villageId);
        }
        if (status != null) {
            qw.eq(WarningEntity::getStatus, status);
        }
        return this.page(page, qw);
    }
}