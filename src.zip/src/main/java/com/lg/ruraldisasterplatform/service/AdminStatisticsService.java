package com.lg.ruraldisasterplatform.service;

import java.util.Map;

/**
 * 管理员端-灾情与预警统计服务接口
 */
public interface AdminStatisticsService {

    /**
     * 灾情上报概览统计（状态分布+村庄排行）
     */
    Map<String, Object> getReportOverview();

    /**
     * 灾情上报时间趋势统计
     * @param period 统计周期：day/week/month/year
     */
    Map<String, Object> getReportTrend(String period);

    /**
     * 风险提示概览统计（审核状态+村庄排行）
     */
    Map<String, Object> getTipOverview();

    /**
     * 预警与指令概览统计
     */
    Map<String, Object> getWarningInstructionOverview();
}