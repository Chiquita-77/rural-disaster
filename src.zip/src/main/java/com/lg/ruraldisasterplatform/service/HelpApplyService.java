package com.lg.ruraldisasterplatform.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.lg.ruraldisasterplatform.entity.HelpApplyEntity;
import java.util.List;
import java.util.Map;

public interface HelpApplyService extends IService<HelpApplyEntity> {
    // 原有方法（保持不变）
    List<HelpApplyEntity> getHelpListByVillageId(Long villageId);

    // 修复：去掉参数，和实现类的方法签名完全一致
    List<Map<String, Object>> getAdminHelpListWithVillageName();

    boolean submitHelpApply(HelpApplyEntity helpApply);
    boolean approveHelpApply(Long applyId, Long approverId, Integer status, String dispatchDetail);
}