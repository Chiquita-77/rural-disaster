package com.lg.ruraldisasterplatform.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.lg.ruraldisasterplatform.entity.EmergencyOrderEntity;

import java.util.List;
import java.util.Map;

public interface EmergencyOrderService extends IService<EmergencyOrderEntity> {

    // 原有方法（保持不变）
    IPage<EmergencyOrderEntity> selectAdminPage(Page<EmergencyOrderEntity> page, Integer status);
    boolean publishOrder(EmergencyOrderEntity order);
    boolean updateOrderStatus(Long orderId, Integer status);
    List<Map<String, Object>> getOrderReceiveStats();
    List<Map<String, Object>> getUnreadDetails(Long orderId, Long villageId);

    // 新增：补全用户端需要的 selectUserOrders 方法（严格匹配 Controller 调用）
    List<EmergencyOrderEntity> selectUserOrders(Long villageId);
}