package com.lg.ruraldisasterplatform.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.lg.ruraldisasterplatform.entity.InstructionDeliveryRecordEntity;

/**
 * 应急指令送达记录Service接口
 */
public interface InstructionDeliveryRecordService extends IService<InstructionDeliveryRecordEntity> {
}