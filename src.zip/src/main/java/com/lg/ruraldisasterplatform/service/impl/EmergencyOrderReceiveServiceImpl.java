package com.lg.ruraldisasterplatform.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.lg.ruraldisasterplatform.entity.EmergencyOrderReceiveEntity;
import com.lg.ruraldisasterplatform.mapper.EmergencyOrderReceiveMapper;
import com.lg.ruraldisasterplatform.service.EmergencyOrderReceiveService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

/**
 * 应急指令送达记录Service实现
 */
@Slf4j // 新增日志注解，方便排查问题
@Service
@RequiredArgsConstructor
public class EmergencyOrderReceiveServiceImpl extends ServiceImpl<EmergencyOrderReceiveMapper,
        EmergencyOrderReceiveEntity> implements EmergencyOrderReceiveService {

    private final EmergencyOrderReceiveMapper receiveMapper;

    /**
     * 查询用户未读指令数量（isRead=0）
     */
    @Override
    public int getUnreadCount(Long userId) {
        try {
            // 优先调用Mapper的自定义方法，失败则用通用查询兜底
            int count = receiveMapper.selectUnreadCount(userId);
            log.info("用户{}的未读指令数量：{}", userId, count);
            return count;
        } catch (Exception e) {
            log.error("调用Mapper查询未读数量失败，使用通用查询兜底", e);
            // 通用查询兜底（防止Mapper方法未定义）
            LambdaQueryWrapper<EmergencyOrderReceiveEntity> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(EmergencyOrderReceiveEntity::getReceiveUserId, userId)
                    .eq(EmergencyOrderReceiveEntity::getIsRead, 0);
            return Math.toIntExact(this.count(wrapper));
        }
    }

    /**
     * 标记指令为已读
     */
    @Override
    public boolean markAsRead(Long orderId, Long userId) {
        try {
            // 优先调用Mapper的自定义方法
            int rows = receiveMapper.updateReadStatus(orderId, userId);
            if (rows > 0) {
                log.info("用户{}标记指令{}为已读成功", userId, orderId);
                return true;
            }
            // 自定义方法无更新，用通用更新兜底
            LambdaQueryWrapper<EmergencyOrderReceiveEntity> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(EmergencyOrderReceiveEntity::getOrderId, orderId)
                    .eq(EmergencyOrderReceiveEntity::getReceiveUserId, userId);

            EmergencyOrderReceiveEntity updateEntity = new EmergencyOrderReceiveEntity();
            updateEntity.setIsRead(1); // 1=已读
            updateEntity.setReadTime(LocalDateTime.now());

            boolean success = this.update(updateEntity, wrapper);
            log.info("用户{}标记指令{}为已读（兜底）：{}", userId, orderId, success);
            return success;
        } catch (Exception e) {
            log.error("用户{}标记指令{}为已读失败", userId, orderId, e);
            return false;
        }
    }

    /**
     * 检查用户是否已接收该指令
     */
    @Override
    public boolean checkReceived(Long orderId, Long userId) {
        try {
            // 优先调用Mapper的自定义方法
            EmergencyOrderReceiveEntity receive = receiveMapper.selectByOrderIdAndUserId(orderId, userId);
            if (receive != null) {
                return true;
            }
            // 自定义方法无结果，用通用查询兜底
            LambdaQueryWrapper<EmergencyOrderReceiveEntity> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(EmergencyOrderReceiveEntity::getOrderId, orderId)
                    .eq(EmergencyOrderReceiveEntity::getReceiveUserId, userId);
            return this.count(wrapper) > 0;
        } catch (Exception e) {
            log.error("检查用户{}是否接收指令{}失败", userId, orderId, e);
            return false; // 异常时默认无权限，避免报错
        }
    }
}