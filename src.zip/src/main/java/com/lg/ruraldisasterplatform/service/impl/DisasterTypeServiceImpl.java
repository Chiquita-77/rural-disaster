package com.lg.ruraldisasterplatform.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.lg.ruraldisasterplatform.entity.DisasterTypeEntity;
import com.lg.ruraldisasterplatform.mapper.DisasterTypeMapper;
import com.lg.ruraldisasterplatform.service.DisasterTypeService;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * 灾害类型服务实现类
 */
@Service
public class DisasterTypeServiceImpl extends ServiceImpl<DisasterTypeMapper, DisasterTypeEntity> implements DisasterTypeService {

    /**
     * 获取所有灾害类型（按sort_num升序）
     */
    @Override
    public List<DisasterTypeEntity> getAllDisasterTypes() {
        LambdaQueryWrapper<DisasterTypeEntity> wrapper = new LambdaQueryWrapper<>();
        wrapper.orderByAsc(DisasterTypeEntity::getSortNum);
        return this.list(wrapper);
    }

    /**
     * 根据ID获取灾害类型详情
     */
    @Override
    public DisasterTypeEntity getDisasterTypeById(Long id) {
        if (id == null || id <= 0) {
            return null;
        }
        return this.getById(id);
    }
}