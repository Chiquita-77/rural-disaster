package com.lg.ruraldisasterplatform.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.lg.ruraldisasterplatform.entity.VillageInfEntity;
import com.lg.ruraldisasterplatform.mapper.VillageInfMapper;
import com.lg.ruraldisasterplatform.service.VillageInfService;
import org.springframework.stereotype.Service;

/**
 * 村庄信息服务实现类
 */
@Service
public class VillageInfServiceImpl extends ServiceImpl<VillageInfMapper, VillageInfEntity> implements VillageInfService {

    /**
     * 根据ID查询，自动过滤已逻辑删除的记录
     */
    @Override
    public VillageInfEntity getVillageById(Long villageId) {
        LambdaQueryWrapper<VillageInfEntity> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(VillageInfEntity::getVillageId, villageId);
        // 自动过滤逻辑删除数据（is_deleted=0）
        return this.getOne(queryWrapper);
    }
}