package com.lg.ruraldisasterplatform.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.lg.ruraldisasterplatform.entity.UserEntity;
import com.lg.ruraldisasterplatform.mapper.UserMapper;
import com.lg.ruraldisasterplatform.service.UserService;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, UserEntity> implements UserService {

    @Override
    public UserEntity register(UserEntity user) {
        // 检查用户名/手机号是否已存在
        LambdaQueryWrapper<UserEntity> qw = new LambdaQueryWrapper<>();
        qw.eq(UserEntity::getUsername, user.getUsername())
                .or()
                .eq(UserEntity::getPhone, user.getPhone());
        if (this.count(qw) > 0) {
            return null;
        }

        // 补充默认值
        user.setStatus(1);
        user.setIsDeleted(0);
        user.setCreateTime(LocalDateTime.now());
        user.setUpdateTime(LocalDateTime.now());

        boolean saved = this.save(user);
        return saved ? user : null;
    }

    @Override
    public UserEntity login(String phone, String password, Integer role) {
        LambdaQueryWrapper<UserEntity> qw = new LambdaQueryWrapper<>();
        qw.eq(UserEntity::getPhone, phone)
                .eq(UserEntity::getPassword, password)
                .eq(UserEntity::getRole, role)
                .eq(UserEntity::getStatus, 1)
                .eq(UserEntity::getIsDeleted, 0);

        UserEntity user = this.getOne(qw);
        if (user == null) {
            return null;
        }
        user.setPassword(null);
        return user;
    }

    // ========== 新增修改方法 ==========
    @Override
    public boolean updateUserInfo(UserEntity user) {
        // 1. 先查询用户是否存在
        UserEntity existUser = this.getById(user.getUserId());
        if (existUser == null) {
            return false;
        }
        // 2. 只更新非空字段（避免覆盖原有值）
        if (user.getUsername() != null) {
            existUser.setUsername(user.getUsername());
        }
        if (user.getPhone() != null) {
            existUser.setPhone(user.getPhone());
        }
        if (user.getPassword() != null) {
            existUser.setPassword(user.getPassword());
        }
        // 3. 更新时间
        existUser.setUpdateTime(LocalDateTime.now());
        // 4. 执行更新
        return this.updateById(existUser);
    }
}