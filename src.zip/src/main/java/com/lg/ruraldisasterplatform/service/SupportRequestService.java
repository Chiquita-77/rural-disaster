package com.lg.ruraldisasterplatform.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.lg.ruraldisasterplatform.entity.SupportRequestEntity;

public interface SupportRequestService extends IService<SupportRequestEntity> {
}