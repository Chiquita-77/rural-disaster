package com.lg.ruraldisasterplatform.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.lg.ruraldisasterplatform.entity.EmergencyInstructionEntity;

/**
 * 应急指令Service接口
 */
public interface EmergencyInstructionService extends IService<EmergencyInstructionEntity> {
}