package com.lg.ruraldisasterplatform.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.lg.ruraldisasterplatform.entity.DisasterGuideEntity;
import com.lg.ruraldisasterplatform.mapper.DisasterGuideMapper;
import com.lg.ruraldisasterplatform.service.DisasterGuideService;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * 防灾指南服务实现类
 */
@Service
public class DisasterGuideServiceImpl extends ServiceImpl<DisasterGuideMapper, DisasterGuideEntity> implements DisasterGuideService {

    /**
     * 获取所有防灾指南（按sort_num升序）
     */
    @Override
    public List<DisasterGuideEntity> getAllDisasterGuides() {
        LambdaQueryWrapper<DisasterGuideEntity> wrapper = new LambdaQueryWrapper<>();
        wrapper.orderByAsc(DisasterGuideEntity::getSortNum);
        return this.list(wrapper);
    }

    /**
     * 根据分类查询防灾指南（按sort_num升序）
     */
    @Override
    public List<DisasterGuideEntity> getDisasterGuidesByCategory(String category) {
        if (category == null || category.trim().isEmpty()) {
            return getAllDisasterGuides();
        }
        LambdaQueryWrapper<DisasterGuideEntity> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(DisasterGuideEntity::getCategory, category)
                .orderByAsc(DisasterGuideEntity::getSortNum);
        return this.list(wrapper);
    }

    /**
     * 根据ID获取防灾指南详情
     */
    @Override
    public DisasterGuideEntity getDisasterGuideById(Long id) {
        if (id == null || id <= 0) {
            return null;
        }
        return this.getById(id);
    }
}