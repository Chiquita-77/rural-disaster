package com.lg.ruraldisasterplatform.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.lg.ruraldisasterplatform.entity.DisasterReportEntity;
import com.lg.ruraldisasterplatform.mapper.DisasterReportMapper;
import com.lg.ruraldisasterplatform.service.DisasterReportService;
import org.springframework.stereotype.Service;

@Service
public class DisasterReportServiceImpl extends ServiceImpl<DisasterReportMapper, DisasterReportEntity> implements DisasterReportService {
}