package com.lg.ruraldisasterplatform.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.lg.ruraldisasterplatform.entity.EmergencyOrderEntity;
import com.lg.ruraldisasterplatform.entity.EmergencyOrderReceiveEntity;
import com.lg.ruraldisasterplatform.mapper.EmergencyOrderMapper;
import com.lg.ruraldisasterplatform.mapper.EmergencyOrderReceiveMapper;
import com.lg.ruraldisasterplatform.service.EmergencyOrderService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

// 【关键】@Service 注解必须有，让 Spring 识别为 Bean
@Service
// 【关键】@RequiredArgsConstructor 必须有，用于注入 mapper
@RequiredArgsConstructor
public class EmergencyOrderServiceImpl extends ServiceImpl<EmergencyOrderMapper, EmergencyOrderEntity>
        implements EmergencyOrderService {

    // 【关键】注入自定义的 EmergencyOrderReceiveMapper
    private final EmergencyOrderReceiveMapper emergencyOrderReceiveMapper;

    // 原有方法完全保留，只改 publishOrder 里的调用逻辑
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean publishOrder(EmergencyOrderEntity order) {
        order.setPublishTime(LocalDateTime.now());
        order.setStatus(1);
        if (!this.save(order)) {
            return false;
        }

        // 👇 核心修改：按 scopeType 生成接收记录（替换原来写死的模拟数据）
        List<EmergencyOrderReceiveEntity> receiveList = new ArrayList<>();

        // 1. scopeType="0" → 全村指令：给所有村民生成接收记录
        if ("0".equals(order.getScopeType())) {
            // 模拟所有村民ID（你可以替换为从数据库查询的真实ID）
            List<Long> allVillagerIds = List.of(1001L, 1002L, 1003L, 1004L, 1005L, 1006L, 1007L, 1008L, 1009L, 1010L);
            for (Long userId : allVillagerIds) {
                EmergencyOrderReceiveEntity receive = new EmergencyOrderReceiveEntity();
                receive.setOrderId(order.getOrderId());
                receive.setReceiveUserId(userId);
                receive.setVillageId(101L); // 统一设为101村（或从用户表查真实村庄ID）
                receive.setIsRead(0);
                receiveList.add(receive);
            }
        }
        // 2. scopeType="1" → 指定村庄：给指定村庄村民生成记录（保留原有逻辑）
        else if ("1".equals(order.getScopeType())) {
            Long[] villageIds = {1L, 2L, 3L};
            Long[] userIds = {1001L, 1002L, 1003L, 1004L, 1005L, 1006L};
            int index = 0;
            for (Long villageId : villageIds) {
                for (int i = 0; i < 2; i++) {
                    EmergencyOrderReceiveEntity receive = new EmergencyOrderReceiveEntity();
                    receive.setOrderId(order.getOrderId());
                    receive.setReceiveUserId(userIds[index++]);
                    receive.setVillageId(villageId);
                    receive.setIsRead(0);
                    receiveList.add(receive);
                }
            }
        }

        // 修复核心：用注入的自定义Mapper直接调用 batchInsert
        if (!receiveList.isEmpty()) {
            emergencyOrderReceiveMapper.batchInsert(receiveList);
        }
        return true;
    }

    @Override
    public IPage<EmergencyOrderEntity> selectAdminPage(Page<EmergencyOrderEntity> page, Integer status) {
        LambdaQueryWrapper<EmergencyOrderEntity> wrapper = new LambdaQueryWrapper<>();
        if (status != null) {
            wrapper.eq(EmergencyOrderEntity::getStatus, status);
        }
        wrapper.orderByDesc(EmergencyOrderEntity::getPublishTime);
        // 修复：用 this.page 调用分页，不是 baseMapper.selectAdminPage
        return this.page(page, wrapper);
    }

    @Override
    public boolean updateOrderStatus(Long orderId, Integer status) {
        EmergencyOrderEntity order = this.getById(orderId);
        if (order == null) {
            return false;
        }
        order.setStatus(status);
        return this.updateById(order);
    }

    @Override
    public List<Map<String, Object>> getOrderReceiveStats() {
        return baseMapper.selectOrderReceiveStats();
    }

    @Override
    public List<Map<String, Object>> getUnreadDetails(Long orderId, Long villageId) {
        return baseMapper.selectUnreadDetails(orderId, villageId);
    }

    // 【已修改】简化版：只查生效中的指令，去掉复杂过滤（村民/信息员能看到所有生效中指令）
    @Override
    public List<EmergencyOrderEntity> selectUserOrders(Long villageId) {
        LambdaQueryWrapper<EmergencyOrderEntity> wrapper = new LambdaQueryWrapper<>();
        // 只保留「生效中」过滤，去掉villageId/scopeType复杂逻辑
        wrapper.eq(EmergencyOrderEntity::getStatus, 1)
                .orderByDesc(EmergencyOrderEntity::getPublishTime);
        return this.list(wrapper);
    }
}