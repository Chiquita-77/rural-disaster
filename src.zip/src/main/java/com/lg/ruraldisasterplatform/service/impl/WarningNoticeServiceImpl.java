package com.lg.ruraldisasterplatform.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.lg.ruraldisasterplatform.entity.WarningNoticeEntity;
import com.lg.ruraldisasterplatform.mapper.WarningNoticeMapper;
import com.lg.ruraldisasterplatform.service.WarningNoticeService;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 灾害预警通知服务实现类
 */
@Service
public class WarningNoticeServiceImpl extends ServiceImpl<WarningNoticeMapper, WarningNoticeEntity> implements WarningNoticeService {

    /**
     * 按推送状态筛选预警列表
     */
    // WarningNoticeServiceImpl.java 修改listByPushStatus方法
    @Override
    public List<WarningNoticeEntity> listByPushStatus(Integer isPushed) {
        LambdaQueryWrapper<WarningNoticeEntity> wrapper = new LambdaQueryWrapper<>();
        if (isPushed != null) {
            wrapper.eq(WarningNoticeEntity::getIsPushed, isPushed);
        }
        wrapper.orderByDesc(WarningNoticeEntity::getPublishTime);
        return this.baseMapper.selectList(wrapper); // 直接调用BaseMapper的selectList
    }

    /**
     * 获取预警接收统计（复用应急指令统计逻辑）
     */
    @Override
    public Map<String, Integer> getReadUnreadStat(Long warningId) {
        Map<String, Integer> statMap = new HashMap<>();
        // 1. 查询预警基础数据
        WarningNoticeEntity notice = this.getById(warningId);
        if (notice == null) {
            statMap.put("readCount", 0);
            statMap.put("unreadCount", 0);
            return statMap;
        }

        // 2. 直接返回数据库中已统计的人数（实际项目可对接接收记录表计算）
        statMap.put("readCount", notice.getReadCount());
        statMap.put("unreadCount", notice.getUnreadCount());
        statMap.put("totalCount", notice.getReadCount() + notice.getUnreadCount());
        return statMap;
    }

    /**
     * 二次推送预警（更新推送状态和时间）
     */
    @Override
    public boolean repushWarning(Long warningId) {
        WarningNoticeEntity notice = this.getById(warningId);
        if (notice == null) {
            return false;
        }

        // 更新推送状态为已推送，重置推送时间
        notice.setIsPushed(1);
        notice.setPushTime(LocalDateTime.now());
        notice.setUpdateTime(LocalDateTime.now());
        return this.updateById(notice);
    }
}