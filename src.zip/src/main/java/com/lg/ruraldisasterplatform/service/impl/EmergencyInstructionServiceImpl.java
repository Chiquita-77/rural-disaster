package com.lg.ruraldisasterplatform.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.lg.ruraldisasterplatform.entity.EmergencyInstructionEntity;
import com.lg.ruraldisasterplatform.mapper.EmergencyInstructionMapper;
import com.lg.ruraldisasterplatform.service.EmergencyInstructionService;
import org.springframework.stereotype.Service;

/**
 * 应急指令Service实现类
 */
@Service
public class EmergencyInstructionServiceImpl extends ServiceImpl<EmergencyInstructionMapper, EmergencyInstructionEntity> implements EmergencyInstructionService {
}