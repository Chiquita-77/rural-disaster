package com.lg.ruraldisasterplatform.service;

import com.lg.ruraldisasterplatform.entity.ShelterInfEntity;
import java.util.List;

public interface ShelterService {
    List<ShelterInfEntity> listByVillage(Long villageId);
    ShelterInfEntity getById(Long shelterId);
}