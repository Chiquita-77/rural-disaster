package com.lg.ruraldisasterplatform.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.lg.ruraldisasterplatform.entity.UserEntity;

public interface UserService extends IService<UserEntity> {
    UserEntity register(UserEntity user);
    UserEntity login(String phone, String password, Integer role);
    boolean updateUserInfo(UserEntity user);
}