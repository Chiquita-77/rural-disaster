package com.lg.ruraldisasterplatform.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.lg.ruraldisasterplatform.entity.InstructionDeliveryRecordEntity;
import com.lg.ruraldisasterplatform.mapper.InstructionDeliveryRecordMapper;
import com.lg.ruraldisasterplatform.service.InstructionDeliveryRecordService;
import org.springframework.stereotype.Service;

/**
 * 应急指令送达记录Service实现类
 */
@Service
public class InstructionDeliveryRecordServiceImpl extends ServiceImpl<InstructionDeliveryRecordMapper, InstructionDeliveryRecordEntity> implements InstructionDeliveryRecordService {
}