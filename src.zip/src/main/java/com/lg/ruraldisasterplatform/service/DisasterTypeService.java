package com.lg.ruraldisasterplatform.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.lg.ruraldisasterplatform.entity.DisasterTypeEntity;
import java.util.List;

/**
 * 灾害类型服务接口
 */
public interface DisasterTypeService extends IService<DisasterTypeEntity> {

    /**
     * 获取所有灾害类型（按sort_num升序）
     */
    List<DisasterTypeEntity> getAllDisasterTypes();

    /**
     * 根据ID获取灾害类型详情
     */
    DisasterTypeEntity getDisasterTypeById(Long id);
}