package com.lg.ruraldisasterplatform.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.lg.ruraldisasterplatform.entity.WarningEntity;

public interface WarningService extends IService<WarningEntity> {
    // 你原来的 publish、listByVillage 等方法可以保留
    WarningEntity publish(WarningEntity warning);
    IPage<WarningEntity> listByVillage(Long villageId, Integer status, Page<WarningEntity> page);
}