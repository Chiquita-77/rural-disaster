package com.lg.ruraldisasterplatform.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.lg.ruraldisasterplatform.entity.WarningNoticeEntity;
import com.lg.ruraldisasterplatform.mapper.DisasterReportMapper;
import com.lg.ruraldisasterplatform.service.AdminStatisticsService;
import com.lg.ruraldisasterplatform.service.RiskTipService;
import com.lg.ruraldisasterplatform.service.WarningNoticeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 管理员端-灾情与预警统计服务实现类
 */
@Service
// 移除 Lombok 的 @RequiredArgsConstructor 注解
public class AdminStatisticsServiceImpl implements AdminStatisticsService {

    @Autowired
    private DisasterReportMapper disasterReportMapper;

    @Autowired
    private RiskTipService riskTipService;

    @Autowired
    private WarningNoticeService warningNoticeService;

    @Override
    public Map<String, Object> getReportOverview() {
        Map<String, Object> result = new HashMap<>();

        // 1. 灾情状态分布（已验证可用）
        List<Map<String, Object>> statusDist = disasterReportMapper.countReportByStatus();
        result.put("statusDistribution", statusDist);

        // 2. 按村庄统计灾情（已验证可用）
        List<Map<String, Object>> villageRank = disasterReportMapper.countReportByVillage();
        result.put("villageRank", villageRank);

        // 3. 灾情总上报数
        long total = disasterReportMapper.selectCount(null);
        result.put("totalCount", total);

        return result;
    }

    @Override
    public Map<String, Object> getReportTrend(String period) {
        Map<String, Object> result = new HashMap<>();
        // 按周期统计灾情趋势（保留，可选使用）
        List<Map<String, Object>> trendData = disasterReportMapper.countReportTrend(period);
        result.put("trendData", trendData);
        result.put("period", period);
        return result;
    }

    @Override
    public Map<String, Object> getTipOverview() {
        Map<String, Object> result = new HashMap<>();

        // 1. 风险提示审核状态分布
        List<Map<String, Object>> reviewDist = riskTipService.countTipByReviewStatus();
        result.put("reviewDistribution", reviewDist);

        // 2. 按村庄统计风险提示
        List<Map<String, Object>> villageRank = riskTipService.countTipByVillage();
        result.put("villageRank", villageRank);

        // 3. 风险提示总发布数
        long total = riskTipService.count(null);
        result.put("totalCount", total);

        return result;
    }

    @Override
    public Map<String, Object> getWarningInstructionOverview() {
        Map<String, Object> result = new HashMap<>();

        // 1. 预警通知总数
        long warningTotal = warningNoticeService.count(null);
        result.put("warningTotal", warningTotal);

        // 2. 已启用预警数
        long enabledWarning = warningNoticeService.count(new LambdaQueryWrapper<WarningNoticeEntity>()
                .eq(WarningNoticeEntity::getIsPushed, 1));
        result.put("enabledWarning", enabledWarning);

        return result;
    }
}