package com.lg.ruraldisasterplatform.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.lg.ruraldisasterplatform.entity.HelpApplyEntity;
import com.lg.ruraldisasterplatform.mapper.HelpApplyMapper;
import com.lg.ruraldisasterplatform.service.HelpApplyService;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Service
public class HelpApplyServiceImpl extends ServiceImpl<HelpApplyMapper, HelpApplyEntity> implements HelpApplyService {

    @Override
    public List<HelpApplyEntity> getHelpListByVillageId(Long villageId) {
        LambdaQueryWrapper<HelpApplyEntity> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(HelpApplyEntity::getVillageId, villageId)
                .orderByDesc(HelpApplyEntity::getSubmitTime);
        return this.list(wrapper);
    }

    // 修复：方法签名和接口完全一致（无参数）
    @Override
    public List<Map<String, Object>> getAdminHelpListWithVillageName() {
        return this.getBaseMapper().selectAdminHelpListWithVillageName();
    }

    @Override
    public boolean submitHelpApply(HelpApplyEntity helpApply) {
        helpApply.setSubmitTime(LocalDateTime.now());
        helpApply.setStatus(0);
        return this.save(helpApply);
    }

    @Override
    public boolean approveHelpApply(Long applyId, Long approverId, Integer status, String dispatchDetail) {
        HelpApplyEntity helpApply = this.getById(applyId);
        if (helpApply == null) {
            return false;
        }
        helpApply.setApproverId(approverId);
        helpApply.setStatus(status);
        helpApply.setDispatchDetail(dispatchDetail);
        helpApply.setHandleTime(LocalDateTime.now());
        return this.updateById(helpApply);
    }
}