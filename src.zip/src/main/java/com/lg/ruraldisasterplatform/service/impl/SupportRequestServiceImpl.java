package com.lg.ruraldisasterplatform.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.lg.ruraldisasterplatform.entity.SupportRequestEntity;
import com.lg.ruraldisasterplatform.mapper.SupportRequestMapper;
import com.lg.ruraldisasterplatform.service.SupportRequestService;
import org.springframework.stereotype.Service;

@Service
public class SupportRequestServiceImpl extends ServiceImpl<SupportRequestMapper, SupportRequestEntity> implements SupportRequestService {
}