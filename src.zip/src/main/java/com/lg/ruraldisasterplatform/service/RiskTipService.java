package com.lg.ruraldisasterplatform.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.lg.ruraldisasterplatform.entity.RiskTipEntity;

import java.util.List;
import java.util.Map;

/**
 * 风险提示服务接口
 */
public interface RiskTipService extends IService<RiskTipEntity> {
    // 基础 CRUD 由 MyBatis-Plus IService 提供，无需额外编写
    // 原有方法：联表查询待审核列表（含村庄名称）
    List<Map<String, Object>> getReviewListWithVillageName();

    // 新增：按审核状态统计风险提示数量
    List<Map<String, Object>> countTipByReviewStatus();

    // 新增：按村庄统计风险提示数量
    List<Map<String, Object>> countTipByVillage();
}