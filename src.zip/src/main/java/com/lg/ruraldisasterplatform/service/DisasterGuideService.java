package com.lg.ruraldisasterplatform.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.lg.ruraldisasterplatform.entity.DisasterGuideEntity;
import java.util.List;

/**
 * 防灾指南服务接口
 */
public interface DisasterGuideService extends IService<DisasterGuideEntity> {

    /**
     * 获取所有防灾指南（按sort_num升序）
     */
    List<DisasterGuideEntity> getAllDisasterGuides();

    /**
     * 根据分类查询防灾指南（按sort_num升序）
     */
    List<DisasterGuideEntity> getDisasterGuidesByCategory(String category);

    /**
     * 根据ID获取防灾指南详情
     */
    DisasterGuideEntity getDisasterGuideById(Long id);
}