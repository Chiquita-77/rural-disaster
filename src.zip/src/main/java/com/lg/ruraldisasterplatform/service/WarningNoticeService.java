package com.lg.ruraldisasterplatform.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.lg.ruraldisasterplatform.entity.WarningNoticeEntity;
import java.util.List;
import java.util.Map;

/**
 * 灾害预警通知服务接口
 */
public interface WarningNoticeService extends IService<WarningNoticeEntity> {

    /**
     * 按推送状态筛选预警列表
     * @param isPushed 0=未推送，1=已推送，null=全部
     */
    List<WarningNoticeEntity> listByPushStatus(Integer isPushed);

    /**
     * 获取预警接收统计（已读/未读人数）
     * @param warningId 预警ID
     */
    Map<String, Integer> getReadUnreadStat(Long warningId);

    /**
     * 二次推送预警
     * @param warningId 预警ID
     */
    boolean repushWarning(Long warningId);
}