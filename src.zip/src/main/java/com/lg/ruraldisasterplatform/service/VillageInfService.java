package com.lg.ruraldisasterplatform.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.lg.ruraldisasterplatform.entity.VillageInfEntity;

/**
 * 村庄信息服务接口
 */
public interface VillageInfService extends IService<VillageInfEntity> {

    /**
     * 根据村庄ID查询村庄详情（逻辑删除过滤）
     * @param villageId 村庄ID
     * @return 村庄信息实体
     */
    VillageInfEntity getVillageById(Long villageId);
}