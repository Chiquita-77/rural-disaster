package com.lg.ruraldisasterplatform.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.lg.ruraldisasterplatform.entity.VillagerReportOperateLogEntity;
import java.util.List;

/**
 * 村民灾情上报操作记录Service接口
 */
public interface VillagerReportOperateLogService extends IService<VillagerReportOperateLogEntity> {

    /**
     * 根据村民ID查询我的操作记录
     * @param villagerId 村民ID
     * @return 操作记录列表
     */
    List<VillagerReportOperateLogEntity> getMyReportLog(Long villagerId);

    /**
     * 新增/更新操作记录（上报灾情时调用）
     * @param logEntity 操作记录实体
     * @return 是否成功
     */
    boolean saveOrUpdateReportLog(VillagerReportOperateLogEntity logEntity);
}