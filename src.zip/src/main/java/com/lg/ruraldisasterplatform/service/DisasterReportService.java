package com.lg.ruraldisasterplatform.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.lg.ruraldisasterplatform.entity.DisasterReportEntity;

public interface DisasterReportService extends IService<DisasterReportEntity> {
}