package com.lg.ruraldisasterplatform.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class WarningDTO {

    @NotBlank(message = "标题不能为空")
    @Size(max = 50, message = "标题不能超过50个字符")
    private String title;

    @NotBlank(message = "内容不能为空")
    @Size(max = 500, message = "内容不能超过500个字符")
    private String content;

    @NotNull(message = "预警等级不能为空")
    private Integer level; // 1:紧急, 2:严重, 3:较重, 4:一般

    @NotNull(message = "村庄ID不能为空")
    private Long villageId;

    // 👇 新增：管理员密码字段（和你现有代码完全兼容）
    @NotBlank(message = "请输入管理员密码")
    private String adminPass;
}