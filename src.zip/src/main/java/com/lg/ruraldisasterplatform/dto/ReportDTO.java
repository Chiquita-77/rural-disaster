package com.lg.ruraldisasterplatform.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

@Data
public class ReportDTO {
    @NotBlank private String title;
    @NotBlank private String content;
    private List<String> images;
    private BigDecimal latitude;
    private BigDecimal longitude;
    @NotNull private Long villageId;
}