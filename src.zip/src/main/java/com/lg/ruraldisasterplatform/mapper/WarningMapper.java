package com.lg.ruraldisasterplatform.mapper;

import com.lg.ruraldisasterplatform.entity.WarningEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface WarningMapper extends BaseMapper<WarningEntity> {
}