package com.lg.ruraldisasterplatform.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lg.ruraldisasterplatform.entity.EmergencyInstructionEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 * 应急指令Mapper
 * 基于MyBatis-Plus实现基础CRUD
 */
@Mapper
public interface EmergencyInstructionMapper extends BaseMapper<EmergencyInstructionEntity> {
}