package com.lg.ruraldisasterplatform.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lg.ruraldisasterplatform.entity.DisasterReportEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * 灾情上报Mapper
 */
@Mapper
public interface DisasterReportMapper extends BaseMapper<DisasterReportEntity> {

    /**
     * 按状态统计灾情数量（已验证可用）
     */
    List<Map<String, Object>> countReportByStatus();

    /**
     * 按村庄统计灾情数量（已验证可用）
     */
    List<Map<String, Object>> countReportByVillage();

    /**
     * 按周期统计灾情趋势（保留，可选使用）
     */
    List<Map<String, Object>> countReportTrend(@Param("period") String period);
}