package com.lg.ruraldisasterplatform.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lg.ruraldisasterplatform.entity.InfoUserTipOperateLogEntity;
import org.apache.ibatis.annotations.Mapper;
import java.util.List;

/**
 * 信息员风险提示操作记录Mapper
 */
@Mapper
public interface InfoUserTipOperateLogMapper extends BaseMapper<InfoUserTipOperateLogEntity> {

    /**
     * 根据信息员ID查询操作记录
     * @param infoUserId 信息员ID
     * @return 操作记录列表
     */
    List<InfoUserTipOperateLogEntity> selectByInfoUserId(Long infoUserId);
}