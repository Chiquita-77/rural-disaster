package com.lg.ruraldisasterplatform.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lg.ruraldisasterplatform.entity.EmergencyOrderEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

@Mapper
public interface EmergencyOrderMapper extends BaseMapper<EmergencyOrderEntity> {

    // 修复：把 default 方法改成注解 SQL，直接写分页查询
    @Select("SELECT * FROM emergency_order " +
            "WHERE ${ew.customSqlSegment} " +
            "ORDER BY publisher_time DESC")
    List<EmergencyOrderEntity> selectAdminPage(@Param("ew") com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<EmergencyOrderEntity> wrapper);

    // 核心修复：所有 publish_time 改成 publisher_time，和数据库字段完全对齐
    @Select("SELECT " +
            "eo.order_id, " +
            "eo.title, " +
            "eo.publisher_name, " +
            "eo.publisher_time, " +  // 关键修复：publish_time → publisher_time
            "eo.status, " +
            "COUNT(eor.record_id) AS total_receive, " +
            "SUM(CASE WHEN eor.is_read = 1 THEN 1 ELSE 0 END) AS read_count, " +
            "SUM(CASE WHEN eor.is_read = 0 THEN 1 ELSE 0 END) AS unread_count " +
            "FROM emergency_order eo " +
            "LEFT JOIN emergency_order_receive eor ON eo.order_id = eor.order_id " +
            "GROUP BY eo.order_id, eo.title, eo.publisher_name, eo.publisher_time, eo.status " +  // 关键修复：publish_time → publisher_time
            "ORDER BY eo.publisher_time DESC")  // 关键修复：publish_time → publisher_time
    List<Map<String, Object>> selectOrderReceiveStats();

    @Select("SELECT " +
            "eor.record_id, " +
            "eor.receive_user_id, " +
            "eor.village_id, " +
            "vi.village_name, " +
            "eor.is_read, " +
            "eor.read_time " +
            "FROM emergency_order_receive eor " +
            "LEFT JOIN village_inf vi ON eor.village_id = vi.village_id " +
            "WHERE eor.order_id = #{orderId} " +
            "AND eor.is_read = 0 " +
            "AND ( #{villageId} IS NULL OR eor.village_id = #{villageId} )")
    List<Map<String, Object>> selectUnreadDetails(
            @Param("orderId") Long orderId,
            @Param("villageId") Long villageId);
}