package com.lg.ruraldisasterplatform.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lg.ruraldisasterplatform.entity.SupportRequestEntity;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SupportRequestMapper extends BaseMapper<SupportRequestEntity> {
}