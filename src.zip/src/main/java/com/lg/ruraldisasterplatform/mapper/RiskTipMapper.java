package com.lg.ruraldisasterplatform.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lg.ruraldisasterplatform.entity.RiskTipEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

@Mapper
public interface RiskTipMapper extends BaseMapper<RiskTipEntity> {
    // 原有方法：联表查询待审核列表（含村庄名称）
    @Select("SELECT rt.*, vi.village_name " +
            "FROM risk_tip rt " +
            "LEFT JOIN village_inf vi ON rt.village_id = vi.village_id " +
            "WHERE rt.status = 1 AND rt.review_status = 0 " +
            "ORDER BY rt.create_time DESC")
    List<Map<String, Object>> selectReviewListWithVillageName();

    // 新增：按审核状态统计风险提示数量
    @Select("SELECT " +
            "  review_status AS status, " +
            "  COUNT(*) AS count, " +
            "  CASE review_status " +
            "    WHEN 0 THEN '待审核' " +
            "    WHEN 1 THEN '已通过' " +
            "    WHEN 2 THEN '已驳回' " +
            "    ELSE '未知' " +
            "  END AS status_name " +
            "FROM risk_tip " +
            "GROUP BY review_status;")
    List<Map<String, Object>> countTipByReviewStatus();

    // 新增：按村庄统计风险提示数量
    @Select("SELECT " +
            "  vi.village_name, " +
            "  COUNT(rt.tip_id) AS tip_count " +
            "FROM risk_tip rt " +
            "LEFT JOIN village_inf vi ON rt.village_id = vi.village_id " +
            "GROUP BY rt.village_id, vi.village_name " +
            "ORDER BY tip_count DESC;")
    List<Map<String, Object>> countTipByVillage();
}