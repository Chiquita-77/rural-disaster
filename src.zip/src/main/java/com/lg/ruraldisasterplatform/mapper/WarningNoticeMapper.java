package com.lg.ruraldisasterplatform.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lg.ruraldisasterplatform.entity.WarningNoticeEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 * 灾害预警通知Mapper（基于MyBatis-Plus）
 */
@Mapper
public interface WarningNoticeMapper extends BaseMapper<WarningNoticeEntity> {


}