package com.lg.ruraldisasterplatform.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lg.ruraldisasterplatform.entity.VillageInfEntity;
import org.springframework.stereotype.Repository;

@Repository
public interface VillageInfMapper extends BaseMapper<VillageInfEntity> {
}