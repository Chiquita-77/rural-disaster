package com.lg.ruraldisasterplatform.mapper;

import com.lg.ruraldisasterplatform.entity.ShelterInfEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ShelterInfMapper extends BaseMapper<ShelterInfEntity> {
}