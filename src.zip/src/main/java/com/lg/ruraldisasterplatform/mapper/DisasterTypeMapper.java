package com.lg.ruraldisasterplatform.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lg.ruraldisasterplatform.entity.DisasterTypeEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 * 灾害类型Mapper（基于MyBatis-Plus）
 */
@Mapper
public interface DisasterTypeMapper extends BaseMapper<DisasterTypeEntity> {
}