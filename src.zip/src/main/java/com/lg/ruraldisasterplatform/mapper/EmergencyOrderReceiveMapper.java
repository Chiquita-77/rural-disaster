package com.lg.ruraldisasterplatform.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lg.ruraldisasterplatform.entity.EmergencyOrderReceiveEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Insert;

import java.util.List;

@Mapper
public interface EmergencyOrderReceiveMapper extends BaseMapper<EmergencyOrderReceiveEntity> {

    @Insert("<script>" +
            "INSERT INTO emergency_order_receive (order_id, receive_user_id, village_id, is_read) " +
            "VALUES " +
            "<foreach collection='list' item='item' separator=','> " +
            "(#{item.orderId}, #{item.receiveUserId}, #{item.villageId}, 0) " +
            "</foreach>" +
            "</script>")
    int batchInsert(@Param("list") List<EmergencyOrderReceiveEntity> list);

    int selectUnreadCount(@Param("receiveUserId") Long receiveUserId);

    int updateReadStatus(@Param("orderId") Long orderId, @Param("receiveUserId") Long receiveUserId);

    EmergencyOrderReceiveEntity selectByOrderIdAndUserId(
            @Param("orderId") Long orderId,
            @Param("receiveUserId") Long receiveUserId);
}