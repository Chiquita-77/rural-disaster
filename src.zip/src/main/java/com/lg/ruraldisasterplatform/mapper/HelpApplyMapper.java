package com.lg.ruraldisasterplatform.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lg.ruraldisasterplatform.entity.HelpApplyEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

@Mapper
public interface HelpApplyMapper extends BaseMapper<HelpApplyEntity> {
    // 修复：去掉动态条件，直接写完整联表SQL，100%兼容MySQL 5.6
    @Select("SELECT ha.*, vi.village_name " +
            "FROM help_apply ha " +
            "LEFT JOIN village_inf vi ON ha.village_id = vi.village_id " +
            "ORDER BY ha.submit_time DESC")
    List<Map<String, Object>> selectAdminHelpListWithVillageName();
}