package com.lg.ruraldisasterplatform.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lg.ruraldisasterplatform.entity.VillagerReportOperateLogEntity;
import org.apache.ibatis.annotations.Mapper;
import java.util.List;

/**
 * 村民灾情上报操作记录Mapper
 */
@Mapper
public interface VillagerReportOperateLogMapper extends BaseMapper<VillagerReportOperateLogEntity> {

    /**
     * 根据村民ID查询操作记录
     * @param villagerId 村民ID
     * @return 操作记录列表
     */
    List<VillagerReportOperateLogEntity> selectByVillagerId(Long villagerId);
}