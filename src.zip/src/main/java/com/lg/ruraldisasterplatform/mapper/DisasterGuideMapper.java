package com.lg.ruraldisasterplatform.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lg.ruraldisasterplatform.entity.DisasterGuideEntity;
import org.apache.ibatis.annotations.Mapper;
import java.util.List;

/**
 * 防灾指南Mapper（基于MyBatis-Plus）
 */
@Mapper
public interface DisasterGuideMapper extends BaseMapper<DisasterGuideEntity> {

    /**
     * 根据分类查询防灾指南（按sort_num升序）
     */
    List<DisasterGuideEntity> selectByCategory(String category);
}