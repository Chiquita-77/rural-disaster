package com.lg.ruraldisasterplatform.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lg.ruraldisasterplatform.entity.InstructionDeliveryRecordEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 * 应急指令送达记录Mapper
 */
@Mapper
public interface InstructionDeliveryRecordMapper extends BaseMapper<InstructionDeliveryRecordEntity> {
}