package com.lg.ruraldisasterplatform.controller;

import com.lg.ruraldisasterplatform.common.Result;
import com.lg.ruraldisasterplatform.entity.HelpApplyEntity;
import com.lg.ruraldisasterplatform.service.HelpApplyService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/help")
@RequiredArgsConstructor
public class HelpApplyController {

    private final HelpApplyService helpApplyService;

    @GetMapping("/list")
    public Result<List<HelpApplyEntity>> getHelpList(@RequestParam Long villageId) {
        List<HelpApplyEntity> helpList = helpApplyService.getHelpListByVillageId(villageId);
        return Result.success(helpList);
    }

    @GetMapping("/admin/list")
    public Result<List<Map<String, Object>>> getAdminHelpList() {
        // 修复：调用无参的 getAdminHelpListWithVillageName 方法
        List<Map<String, Object>> list = helpApplyService.getAdminHelpListWithVillageName();
        return Result.success(list);
    }

    @PostMapping("/submit")
    public Result<String> submitHelpApply(@RequestBody HelpApplyEntity helpApply) {
        // 1. 参数校验（保留）
        if (helpApply.getVillageId() == null || helpApply.getVillageId() <= 0) {
            return Result.error("村庄ID不能为空");
        }
        if (helpApply.getApplicantId() == null || helpApply.getApplicantId() <= 0) {
            return Result.error("申请人ID不能为空");
        }
        if (helpApply.getTitle() == null || helpApply.getTitle().trim().isEmpty()) {
            return Result.error("申请标题不能为空");
        }
        if (helpApply.getDetail() == null || helpApply.getDetail().trim().isEmpty()) {
            return Result.error("申请详情不能为空");
        }

        // 2. 只补充必填字段（submitTime、status），不修改villageId
        helpApply.setSubmitTime(LocalDateTime.now());
        helpApply.setStatus(0);

        // 3. 保存数据（保留前端传入的villageId）
        boolean isSuccess = helpApplyService.save(helpApply);
        return isSuccess ? Result.success("支援申请提交成功，等待审批") : Result.error("提交失败");
    }

    @PostMapping("/approve")
    public Result<String> approveHelpApply(@RequestBody ApproveRequest request) {
        if (request.getStatus() != 1 && request.getStatus() != 2) {
            return Result.error("审批状态无效，仅支持1(已通过)/2(已驳回)");
        }
        boolean isSuccess = helpApplyService.approveHelpApply(
                request.getApplyId(),
                request.getApproverId(),
                request.getStatus(),
                request.getDispatchDetail()
        );
        return isSuccess ? Result.success("支援申请审批成功") : Result.error("申请ID不存在");
    }

    public static class ApproveRequest {
        private Long applyId;
        private Long approverId;
        private Integer status;
        private String dispatchDetail;

        public Long getApplyId() { return applyId; }
        public void setApplyId(Long applyId) { this.applyId = applyId; }
        public Long getApproverId() { return approverId; }
        public void setApproverId(Long approverId) { this.approverId = approverId; }
        public Integer getStatus() { return status; }
        public void setStatus(Integer status) { this.status = status; }
        public String getDispatchDetail() { return dispatchDetail; }
        public void setDispatchDetail(String dispatchDetail) { this.dispatchDetail = dispatchDetail; }
    }
}