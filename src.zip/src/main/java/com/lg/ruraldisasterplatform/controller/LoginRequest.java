package com.lg.ruraldisasterplatform.controller;

public class LoginRequest {
    private String phone;
    private String password;

    // getter/setter
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
}