package com.lg.ruraldisasterplatform.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.lg.ruraldisasterplatform.common.Result;
import com.lg.ruraldisasterplatform.entity.*;
import com.lg.ruraldisasterplatform.service.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 预警+应急指令统一控制器（适配Spring Boot 3 + MyBatis-Plus 3.5.6）
 * 路径：/warning
 */
@RestController
@RequestMapping("/warning")
@RequiredArgsConstructor
@Slf4j
public class WarningController {

    // 原有预警服务
    @Autowired
    private WarningService warningService;
    // 应急指令相关服务
    @Autowired
    private EmergencyInstructionService emergencyInstructionService;
    @Autowired
    private InstructionDeliveryRecordService instructionDeliveryRecordService;
    @Autowired
    private UserService userService; // 确保项目中存在该服务及UserEntity实体
    @Autowired
    private final RiskTipService riskTipService;

    // ===================== 原有预警功能（完全保留，适配高版本） =====================
    @PostMapping("/publish")
    public Result<WarningEntity> publish(@RequestBody WarningEntity warning) {
        try {
            WarningEntity result = warningService.publish(warning);
            return Result.success(result);
        } catch (Exception e) {
            log.error("发布预警异常", e);
            return Result.error("发布预警失败");
        }
    }

    @GetMapping("/{id}")
    public Result<WarningEntity> get(@PathVariable Long id) {
        WarningEntity warning = warningService.getById(id); // 替换原get方法，适配MyBatis-Plus规范
        if (warning == null) {
            return Result.error("预警信息不存在");
        }
        return Result.success(warning);
    }

    @GetMapping("/list")
    public Result<IPage<WarningEntity>> list(
            @RequestParam(value = "villageId", required = false) Long villageId,
            @RequestParam(value = "status", required = false) Integer status,
            @RequestParam(value = "pageNum", defaultValue = "1") int pageNum,
            @RequestParam(value = "pageSize", defaultValue = "10") int pageSize
    ) {
        Page<WarningEntity> page = new Page<>(pageNum, pageSize);
        IPage<WarningEntity> result = warningService.listByVillage(villageId, status, page);
        return Result.success(result);
    }
    /**
     * 村民端查询历史预警记录（支持筛选状态/日期）
     * 接口地址：/warning/history/list
     */
    @GetMapping("/history/list")
    public Result<List<RiskTipEntity>> listHistoryWarnings(
            @RequestParam(required = false) Long villageId,          // 村庄ID（可选）
            @RequestParam(required = false) Integer reviewStatus,    // 审核状态：0=待审核 1=已通过 -1=已驳回（可选）
            @RequestParam(required = false) String date              // 筛选日期：yyyy-MM-dd（可选）
    ) {
        LambdaQueryWrapper<RiskTipEntity> qw = new LambdaQueryWrapper<>();
        qw.eq(RiskTipEntity::getStatus, 1); // 只查未删除的记录

        // 1. 按村庄筛选（可选）
        if (villageId != null) {
            qw.eq(RiskTipEntity::getVillageId, villageId);
        }
        // 2. 按审核状态筛选（可选）
        if (reviewStatus != null) {
            qw.eq(RiskTipEntity::getReviewStatus, reviewStatus);
        }
        // 3. 按日期筛选（可选）
        if (date != null && !date.isEmpty()) {
            qw.apply("DATE(create_time) = {0}", date); // 匹配发布日期
        }

        // 按发布时间倒序排列（最新的在前）
        qw.orderByDesc(RiskTipEntity::getCreateTime);
        return Result.success(riskTipService.list(qw));
    }
    /**
     * 修复版：预警统计接口（用Map替代WarningStatsVO，解决编译错误）
     * 接口路径：/warning/stats
     * 请求参数：villageId（村庄ID）
     * 返回：urgent(紧急预警)、serious(严重预警)、total(累计预警)
     */
    @GetMapping("/stats")
    public Result<Map<String, Integer>> getWarningStats(@RequestParam Long villageId) {
        if (villageId == null || villageId <= 0) {
            return Result.error("村庄ID无效");
        }

        // 1. 统计紧急预警（level=1）
        LambdaQueryWrapper<WarningEntity> urgentWrapper = new LambdaQueryWrapper<>();
        urgentWrapper.eq(WarningEntity::getVillageId, villageId)
                .eq(WarningEntity::getLevel, 1)
                .eq(WarningEntity::getIsDeleted, 0); // 过滤已删除数据
        int urgentCount = (int) warningService.count(urgentWrapper);

        // 2. 统计严重预警（level=2）
        LambdaQueryWrapper<WarningEntity> seriousWrapper = new LambdaQueryWrapper<>();
        seriousWrapper.eq(WarningEntity::getVillageId, villageId)
                .eq(WarningEntity::getLevel, 2)
                .eq(WarningEntity::getIsDeleted, 0);
        int seriousCount = (int) warningService.count(seriousWrapper);

        // 3. 统计累计预警（所有有效预警）
        LambdaQueryWrapper<WarningEntity> totalWrapper = new LambdaQueryWrapper<>();
        totalWrapper.eq(WarningEntity::getVillageId, villageId)
                .eq(WarningEntity::getIsDeleted, 0);
        int totalCount = (int) warningService.count(totalWrapper);

        // 4. 封装返回数据（匹配前端接收格式）
        Map<String, Integer> stats = new HashMap<>();
        stats.put("urgent", urgentCount);
        stats.put("serious", seriousCount);
        stats.put("total", totalCount);

        return Result.success(stats);
    }

    @PostMapping("/{id}/cancel")
    public Result<String> cancelWarning(@PathVariable Long id) {
        log.info("收到解除预警请求，ID：{}", id);
        // 适配MyBatis-Plus 3.5.6的查询方式
        WarningEntity warning = warningService.getById(id);
        if (warning == null || warning.getIsDeleted() == 1) {
            log.warn("预警解除失败，ID：{}，原因：预警不存在/已删除", id);
            return Result.error("预警信息不存在");
        }
        // 补充更新逻辑（适配高版本字段赋值）
        warning.setStatus(0);
        warning.setUpdateTime(LocalDateTime.now());
        boolean updated = warningService.updateById(warning); // 替换原update方法，规范操作
        if (updated) {
            log.info("预警解除成功，ID：{}", id);
            return Result.success("预警已解除");
        } else {
            log.error("预警解除失败，ID：{}，原因：数据库更新失败", id);
            return Result.error("解除失败，请重试");
        }
    }

    // ===================== 应急指令核心功能（适配高版本，无报错） =====================
    /**
     * 乡镇端：下发应急指令
     * 请求路径：/warning/instruction/send
     */
    @PostMapping("/instruction/send")
    public Result<String> sendInstruction(@RequestBody EmergencyInstructionEntity instruction) {
        try {
            instruction.setCreateTime(LocalDateTime.now());
            instruction.setCreateUserId(getCurrentAdminId()); // 替换为实际管理员ID逻辑
            boolean saved = emergencyInstructionService.save(instruction);
            if (saved) {
                log.info("应急指令下发成功，标题：{}，ID：{}", instruction.getTitle(), instruction.getInstructionId());
                return Result.success("指令下发成功");
            } else {
                log.error("应急指令下发失败，标题：{}", instruction.getTitle());
                return Result.error("下发失败，请重试");
            }
        } catch (Exception e) {
            log.error("下发应急指令异常", e);
            return Result.error("系统异常，下发失败");
        }
    }

    /**
     * 村民端：按村庄ID查询应急指令列表
     * 请求路径：/warning/instruction/list?targetVillageId=xxx
     */
    @GetMapping("/instruction/list")
    public Result<List<EmergencyInstructionEntity>> getInstructionList(
            @RequestParam("targetVillageId") Long targetVillageId
    ) {
        if (targetVillageId == null) {
            return Result.error("村庄ID不能为空");
        }
        // 适配MyBatis-Plus 3.5.6的查询逻辑
        LambdaQueryWrapper<EmergencyInstructionEntity> qw = new LambdaQueryWrapper<>();
        qw.orderByDesc(EmergencyInstructionEntity::getCreateTime);
        List<EmergencyInstructionEntity> allList = emergencyInstructionService.list(qw);
        // 过滤当前村庄的指令（兼容JSON格式的targetVillageIds）
        List<EmergencyInstructionEntity> villageList = allList.stream()
                .filter(item -> {
                    String targetIds = item.getTargetVillageIds();
                    return targetIds != null && targetIds.contains(targetVillageId.toString());
                })
                .collect(Collectors.toList());
        log.info("查询应急指令列表成功，村庄ID：{}，指令数量：{}", targetVillageId, villageList.size());
        return Result.success(villageList);
    }

    /**
     * 村民端：查询单条应急指令详情
     * 请求路径：/warning/instruction/{id}
     */
    @GetMapping("/instruction/{id}")
    public Result<EmergencyInstructionEntity> getInstructionDetail(@PathVariable Long id) {
        EmergencyInstructionEntity instruction = emergencyInstructionService.getById(id);
        if (instruction == null) {
            log.warn("查询应急指令详情失败，ID：{}，原因：指令不存在", id);
            return Result.error("指令不存在");
        }
        return Result.success(instruction);
    }

    /**
     * 村民端：标记指令为已读（适配MyBatis-Plus 3.5.6，无existsById报错）
     * 请求路径：/warning/instruction/{id}/read
     */
    @PostMapping("/instruction/{id}/read")
    public Result<String> markAsRead(@PathVariable Long id) {
        Long userId = getCurrentUserId(); // 替换为实际用户ID逻辑
        if (userId == null) {
            log.warn("标记应急指令已读失败，指令ID：{}，原因：用户未登录", id);
            return Result.error("请先登录");
        }
        // 替换existsById：用getById判断指令是否存在（适配3.5.6版本）
        EmergencyInstructionEntity instruction = emergencyInstructionService.getById(id);
        if (instruction == null) {
            log.warn("标记应急指令已读失败，指令ID：{}，原因：指令不存在", id);
            return Result.error("指令不存在");
        }
        // 获取用户所属村庄（确保UserEntity有villageId字段）
        UserEntity user = userService.getById(userId);
        if (user == null || user.getVillageId() == null) {
            log.warn("标记应急指令已读失败，用户ID：{}，原因：用户信息异常/无所属村庄", userId);
            return Result.error("用户信息异常，请重试");
        }
        Long villageId = user.getVillageId();

        // 检查是否已读，避免重复记录
        LambdaQueryWrapper<InstructionDeliveryRecordEntity> qw = new LambdaQueryWrapper<>();
        qw.eq(InstructionDeliveryRecordEntity::getInstructionId, id)
                .eq(InstructionDeliveryRecordEntity::getUserId, userId);
        InstructionDeliveryRecordEntity record = instructionDeliveryRecordService.getOne(qw);

        try {
            if (record == null) {
                // 新增已读记录
                record = new InstructionDeliveryRecordEntity();
                record.setInstructionId(id);
                record.setUserId(userId);
                record.setVillageId(villageId);
                record.setReadTime(LocalDateTime.now());
                instructionDeliveryRecordService.save(record);
            } else if (record.getReadTime() == null) {
                // 更新未读为已读
                record.setReadTime(LocalDateTime.now());
                instructionDeliveryRecordService.updateById(record);
            }
            log.info("标记应急指令已读成功，指令ID：{}，用户ID：{}", id, userId);
            return Result.success("已标记为已读");
        } catch (Exception e) {
            log.error("标记应急指令已读异常，指令ID：{}，用户ID：{}", id, userId, e);
            return Result.error("标记失败，请重试");
        }
    }

    /**
     * 乡镇端：查询指令送达统计（修复long/int类型转换问题）
     * 请求路径：/warning/instruction/{id}/delivery-stats
     */
    @GetMapping("/instruction/{id}/delivery-stats")
    public Result<Map<String, Object>> getDeliveryStats(@PathVariable Long id) {
        // 替换existsById：适配3.5.6版本
        EmergencyInstructionEntity instruction = emergencyInstructionService.getById(id);
        if (instruction == null) {
            log.warn("查询应急指令送达统计失败，指令ID：{}，原因：指令不存在", id);
            return Result.error("指令不存在");
        }
        // 统计总接收人数和已读人数（用long接收count结果，适配3.5.6返回值类型）
        LambdaQueryWrapper<InstructionDeliveryRecordEntity> totalQw = new LambdaQueryWrapper<>();
        totalQw.eq(InstructionDeliveryRecordEntity::getInstructionId, id);
        long total = instructionDeliveryRecordService.count(totalQw); // 修复int→long

        LambdaQueryWrapper<InstructionDeliveryRecordEntity> readQw = new LambdaQueryWrapper<>();
        readQw.eq(InstructionDeliveryRecordEntity::getInstructionId, id)
                .isNotNull(InstructionDeliveryRecordEntity::getReadTime);
        long read = instructionDeliveryRecordService.count(readQw); // 修复int→long

        // 组装统计数据（适配前端展示）
        Map<String, Object> stats = new HashMap<>();
        stats.put("total", total);
        stats.put("read", read);
        stats.put("unread", total - read);
        stats.put("readRate", total == 0 ? 0 : (read * 100.0 / total)); // 保留小数，更精准

        log.info("查询应急指令送达统计成功，指令ID：{}，已读/总人数：{}/{}，已读率：{}%",
                id, read, total, String.format("%.2f", stats.get("readRate")));
        return Result.success(stats);
    }

    // ===================== 工具方法（适配Spring Boot 3，替换为实际逻辑） =====================
    /**
     * 获取当前登录用户ID（村民/村级）
     * 适配Spring Boot 3：可从RequestContextHolder获取请求头解析JWT
     */
    private Long getCurrentUserId() {
        // 示例：Spring Boot 3中从请求头解析token（替换为你的实际逻辑）
        // HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
        // String token = request.getHeader("Authorization");
        // return JwtUtil.extractUserId(token);

        // 测试用固定值，实际开发替换为上面的逻辑
        return 1001L;
    }

    /**
     * 获取当前乡镇管理员ID
     */
    private Long getCurrentAdminId() {
        // 示例：从管理员token解析（适配Spring Boot 3）
        // HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
        // String token = request.getHeader("Admin-Token");
        // return AdminJwtUtil.extractAdminId(token);

        // 测试用固定值，实际开发替换
        return 2001L;
    }
}