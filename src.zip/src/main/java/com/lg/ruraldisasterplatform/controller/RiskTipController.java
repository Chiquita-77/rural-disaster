package com.lg.ruraldisasterplatform.controller;

import com.lg.ruraldisasterplatform.common.Result;
import com.lg.ruraldisasterplatform.entity.RiskTipEntity;
import com.lg.ruraldisasterplatform.service.RiskTipService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/tip")
@RequiredArgsConstructor
public class RiskTipController {

    private final RiskTipService riskTipService;

    /** 村级发布风险提示 */
    @PostMapping("/publish")
    public Result<String> publishTip(@RequestBody RiskTipEntity tip) {
        if (tip.getVillageId() == null || tip.getTitle() == null || tip.getContent() == null) {
            return Result.error("标题、内容、村庄ID不能为空");
        }
        tip.setStatus(1);           // 逻辑删除：1=正常
        tip.setReviewStatus(0);     // 审核状态：0=待审核
        tip.setCreateTime(LocalDateTime.now());
        boolean saved = riskTipService.save(tip);
        return saved ? Result.success("提交成功，等待乡镇审核") : Result.error("提交失败");
    }

    /** 村民查看本村风险提示（未修改，完全兼容） */
    @GetMapping("/list")
    public Result<List<RiskTipEntity>> listTips(@RequestParam(required = false) Long villageId) {
        com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<RiskTipEntity> qw =
                new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<>();
        qw.eq(RiskTipEntity::getStatus, 1);        // 未删除
        qw.eq(RiskTipEntity::getReviewStatus, 1);  // 已通过审核
        if (villageId != null) {
            qw.eq(RiskTipEntity::getVillageId, villageId);
        }
        qw.orderByDesc(RiskTipEntity::getCreateTime);
        return Result.success(riskTipService.list(qw));
    }

    /** 乡镇查看待审核列表（修改：返回联表结果，含村庄名称） */
    @GetMapping("/review/list")
    public Result<List<Map<String, Object>>> getReviewList() {
        // 调用联表查询方法，返回包含村庄名称的 Map 列表
        List<Map<String, Object>> list = riskTipService.getReviewListWithVillageName();
        return Result.success(list);
    }

    /** 乡镇审核操作（完全不变，兼容原有逻辑） */
    @PostMapping("/{id}/review")
    public Result<String> reviewTip(
            @PathVariable Long id,
            @RequestBody Map<String, Object> payload
    ) {
        Integer reviewStatus = (Integer) payload.get("status"); // 1=通过, -1=驳回
        String comment = (String) payload.get("comment");

        if (reviewStatus == null || (reviewStatus != 1 && reviewStatus != -1)) {
            return Result.error("状态无效（仅支持1=通过/-1=驳回）");
        }

        RiskTipEntity tip = riskTipService.getById(id);
        if (tip == null || tip.getStatus() != 1) {
            return Result.error("风险提示不存在或已删除");
        }

        tip.setReviewStatus(reviewStatus);
        tip.setReviewComment(comment);
        tip.setReviewTime(LocalDateTime.now());

        boolean updated = riskTipService.updateById(tip);
        return updated ? Result.success("审核成功") : Result.error("审核失败");
    }
}