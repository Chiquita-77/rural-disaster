package com.lg.ruraldisasterplatform.controller;

import com.lg.ruraldisasterplatform.common.Result;
import com.lg.ruraldisasterplatform.service.AdminStatisticsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * 管理员端-灾情与预警统计控制器（最简版，确保能被Spring扫描）
 */
@RestController
@RequestMapping("/admin/statistics")
// 移除所有Lombok注解，避免依赖问题
public class AdminStatisticsController {

    // 显式Autowired注入，确保Service能被找到
    @Autowired
    private AdminStatisticsService statisticsService;

    // ========== 测试接口（优先验证） ==========
    @GetMapping("/test")
    public Result<String> test() {
        return Result.success("statistics controller is alive");
    }

    // ========== 灾情上报概览 ==========
    @GetMapping("/report-overview")
    public Result<Map<String, Object>> getReportOverview() {
        try {
            Map<String, Object> data = statisticsService.getReportOverview();
            return Result.success(data);
        } catch (Exception e) {
            e.printStackTrace(); // 打印异常日志，方便排查
            return Result.error("查询灾情统计失败：" + e.getMessage());
        }
    }

    // ========== 灾情趋势 ==========
    @GetMapping("/report-trend")
    public Result<Map<String, Object>> getReportTrend(@RequestParam(defaultValue = "month") String period) {
        try {
            Map<String, Object> data = statisticsService.getReportTrend(period);
            return Result.success(data);
        } catch (Exception e) {
            e.printStackTrace();
            return Result.error("查询灾情趋势失败：" + e.getMessage());
        }
    }

    // ========== 风险提示概览 ==========
    @GetMapping("/tip-overview")
    public Result<Map<String, Object>> getTipOverview() {
        try {
            Map<String, Object> data = statisticsService.getTipOverview();
            return Result.success(data);
        } catch (Exception e) {
            e.printStackTrace();
            return Result.error("查询风险提示统计失败：" + e.getMessage());
        }
    }

    // ========== 预警指令概览 ==========
    @GetMapping("/warning-instruction-overview")
    public Result<Map<String, Object>> getWarningInstructionOverview() {
        try {
            Map<String, Object> data = statisticsService.getWarningInstructionOverview();
            return Result.success(data);
        } catch (Exception e) {
            e.printStackTrace();
            return Result.error("查询预警指令统计失败：" + e.getMessage());
        }
    }
}