package com.lg.ruraldisasterplatform.controller;

import com.lg.ruraldisasterplatform.common.Result;
import com.lg.ruraldisasterplatform.entity.DisasterGuideEntity;
import com.lg.ruraldisasterplatform.service.DisasterGuideService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

/**
 * 管理员端-防灾指南管理控制器
 */
@RestController
@RequestMapping("/admin/guide")
@RequiredArgsConstructor
public class AdminDisasterGuideController {

    private final DisasterGuideService disasterGuideService;

    // 保存/新增/编辑指南
    @PostMapping("/save")
    public Result<Boolean> saveGuide(@RequestBody DisasterGuideEntity guide) {
        try {
            boolean success = disasterGuideService.saveOrUpdate(guide);
            return success ? Result.success(true) : Result.error("保存失败");
        } catch (Exception e) {
            return Result.error("保存异常：" + e.getMessage());
        }
    }

    // 更新状态（用sortNum存状态：1=启用，0=禁用）
    @PostMapping("/status")
    public Result<Boolean> updateStatus(@RequestParam Long id, @RequestParam Integer status) {
        try {
            DisasterGuideEntity guide = disasterGuideService.getById(id);
            if (guide == null) {
                return Result.error("指南不存在");
            }
            guide.setSortNum(status); // 临时用sortNum存状态
            boolean success = disasterGuideService.updateById(guide);
            return success ? Result.success(true) : Result.error("状态更新失败");
        } catch (Exception e) {
            return Result.error("状态更新异常：" + e.getMessage());
        }
    }
}