package com.lg.ruraldisasterplatform.controller;

import com.lg.ruraldisasterplatform.common.Result;
import com.lg.ruraldisasterplatform.entity.VillagerReportOperateLogEntity;
import com.lg.ruraldisasterplatform.service.VillagerReportOperateLogService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 村民端 - 我的操作记录控制器（独立职责，专门处理“我的”相关接口）
 */
@RestController
@RequestMapping("/villager/my")
@RequiredArgsConstructor
public class VillagerMyController {

    private final VillagerReportOperateLogService reportOperateLogService;

    /**
     * 村民查询自己的灾情上报操作记录（含处理状态）
     * 接口路径：/villager/my/report-log
     * @param villagerId 当前登录村民的ID（前端传参）
     */
    @GetMapping("/report-log")
    public Result<List<VillagerReportOperateLogEntity>> getMyReportLog(@RequestParam Long villagerId) {
        if (villagerId == null || villagerId <= 0) {
            return Result.error("村民ID无效");
        }
        try {
            List<VillagerReportOperateLogEntity> logList = reportOperateLogService.getMyReportLog(villagerId);
            return Result.success(logList);
        } catch (Exception e) {
            return Result.error("查询我的上报记录失败：" + e.getMessage());
        }
    }
}