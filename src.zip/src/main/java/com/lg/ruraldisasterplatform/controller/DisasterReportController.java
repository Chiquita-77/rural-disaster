package com.lg.ruraldisasterplatform.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lg.ruraldisasterplatform.common.Result;
import com.lg.ruraldisasterplatform.entity.DisasterReportEntity;
import com.lg.ruraldisasterplatform.service.DisasterReportService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;

/**
 * 灾情上报控制器（区分信息员/管理员权限）
 * 信息员：仅核实本村待核实灾情
 * 管理员：管理所有灾情（查看/处理/统计）
 */
@RestController
@RequestMapping("/report")
@RequiredArgsConstructor
public class DisasterReportController {

    // 注入服务层和JSON解析工具
    private final DisasterReportService reportService;
    private final ObjectMapper objectMapper;

    /**
     * 1. 村民上报灾情
     * 核心优化：优先绑定登录用户的村庄ID，避免前端传错
     */
    @PostMapping("/submit")
    public Result<String> submitReport(
            @RequestBody DisasterReportEntity report,
            // 从请求头获取登录用户的村庄ID（需结合权限框架，如Token解析）
            @RequestHeader(value = "villageId", required = false) Long loginVillageId
    ) {
        try {
            // 优先使用登录态的村庄ID，确保归属正确
            if (loginVillageId != null && loginVillageId > 0) {
                report.setVillageId(loginVillageId);
            }

            // 必填参数校验
            if (report.getVillageId() == null || report.getVillageId() <= 0) {
                return Result.error("村庄ID不能为空且必须为有效数字");
            }
            if (report.getTitle() == null || report.getTitle().trim().isEmpty()) {
                return Result.error("上报标题不能为空");
            }
            if (report.getContent() == null || report.getContent().trim().isEmpty()) {
                return Result.error("灾情内容不能为空");
            }

            // 图片字段空值兜底（避免JSON解析报错）
            if (report.getImages() == null || report.getImages().trim().isEmpty()) {
                report.setImages("[]");
            }

            // 初始化固定字段
            report.setStatus(0); // 0=待核实（统一状态枚举）
            report.setCreateTime(LocalDateTime.now());

            // 保存数据
            boolean saved = reportService.save(report);
            return saved ? Result.success("灾情上报成功，等待核实") : Result.error("灾情上报失败");
        } catch (Exception e) {
            e.printStackTrace();
            return Result.error("系统异常：" + e.getMessage());
        }
    }

    /**
     * 2. 村民查看自己的上报记录
     * 按村庄ID筛选（仅能看本村）
     */
    @GetMapping("/my")
    public Result<List<DisasterReportEntity>> getMyReports(@RequestParam Long villageId) {
        if (villageId == null || villageId <= 0) {
            return Result.error("村庄ID不能为空");
        }

        LambdaQueryWrapper<DisasterReportEntity> qw = new LambdaQueryWrapper<>();
        qw.eq(DisasterReportEntity::getVillageId, villageId);
        qw.orderByDesc(DisasterReportEntity::getCreateTime);

        List<DisasterReportEntity> list = reportService.list(qw);
        parseImageList(list);

        return Result.success(list);
    }

    /**
     * 3. 按ID查询单条灾情记录
     * 通用接口（信息员/管理员/村民均可调用）
     */
    @GetMapping("/{id}")
    public Result<DisasterReportEntity> getReportById(@PathVariable Long id) {
        if (id == null || id <= 0) {
            return Result.error("灾情ID无效");
        }

        // 按reportId精准查询（避免主键字段不匹配）
        DisasterReportEntity report = reportService.getOne(
                new LambdaQueryWrapper<DisasterReportEntity>()
                        .eq(DisasterReportEntity::getReportId, id)
        );
        if (report == null) {
            return Result.error("灾情记录不存在");
        }

        parseImageList(Collections.singletonList(report));
        return Result.success(report);
    }

    /**
     * 4. 信息员查看待核实列表
     * 核心限制：仅能查看本村待核实灾情（强制过滤villageId）
     */
    @GetMapping("/info/list")
    public Result<List<DisasterReportEntity>> infoListReports(
            @RequestParam Long villageId, // 信息员必须传本村ID（非空）
            @RequestParam(required = false, defaultValue = "0") Integer status
    ) {
        // 强制校验村庄ID（信息员只能看本村）
        if (villageId == null || villageId <= 0) {
            return Result.error("村庄ID不能为空");
        }

        LambdaQueryWrapper<DisasterReportEntity> qw = new LambdaQueryWrapper<>();
        qw.eq(DisasterReportEntity::getVillageId, villageId); // 仅查本村
        qw.eq(DisasterReportEntity::getStatus, status == null ? 0 : status); // 默认查待核实
        qw.orderByDesc(DisasterReportEntity::getCreateTime);

        List<DisasterReportEntity> list = reportService.list(qw);
        parseImageList(list);

        return Result.success(list);
    }

    /**
     * 5. 信息员核实灾情（仅能修改状态，无最终管理权限）
     * 核心限制：仅能核实本村灾情
     */
    @PostMapping("/info/handle/{reportId}")
    public Result<String> infoHandleReport(
            @PathVariable Long reportId,
            @RequestBody HandleReportRequest request,
            @RequestParam Long villageId // 信息员所属村庄ID（校验归属）
    ) {
        // 参数校验
        if (reportId == null || reportId <= 0) {
            return Result.error("灾情ID不能为空");
        }
        if (villageId == null || villageId <= 0) {
            return Result.error("村庄ID不能为空");
        }
        if (request == null || request.getHandleResult() == null || request.getHandleResult().trim().isEmpty()) {
            return Result.error("处理结果不能为空");
        }
        if (request.getStatus() == null || (request.getStatus() != 1 && request.getStatus() != 2)) {
            return Result.error("状态只能是1（已核实）或2（驳回）");
        }

        // 1. 查询灾情记录（同时校验归属：必须是本村的灾情）
        DisasterReportEntity report = reportService.getOne(
                new LambdaQueryWrapper<DisasterReportEntity>()
                        .eq(DisasterReportEntity::getReportId, reportId)
                        .eq(DisasterReportEntity::getVillageId, villageId) // 仅能操作本村灾情
        );
        if (report == null) {
            return Result.error("灾情记录不存在或不属于当前村庄");
        }

        // 2. 仅更新核实状态和结果（信息员无其他权限）
        report.setStatus(request.getStatus()); // 1=已核实，2=驳回
        report.setHandleResult(request.getHandleResult());
        report.setHandleTime(LocalDateTime.now());

        // 3. 保存更新
        boolean updated = reportService.updateById(report);
        return updated ? Result.success("灾情核实成功") : Result.error("灾情核实失败");
    }

    /**
     * 6. 管理员查看所有灾情（全局权限，可按状态筛选）
     */
    @GetMapping("/admin/list")
    public Result<List<DisasterReportEntity>> getAdminList(
            @RequestParam(required = false) Integer status, // 可选：按状态筛选
            @RequestParam(required = false) Long villageId // 可选：按村庄筛选
    ) {
        LambdaQueryWrapper<DisasterReportEntity> qw = new LambdaQueryWrapper<>();
        // 按状态筛选（不传则查所有）
        if (status != null) {
            qw.eq(DisasterReportEntity::getStatus, status);
        }
        // 按村庄筛选（不传则查所有村庄）
        if (villageId != null && villageId > 0) {
            qw.eq(DisasterReportEntity::getVillageId, villageId);
        }
        qw.orderByDesc(DisasterReportEntity::getCreateTime);

        List<DisasterReportEntity> list = reportService.list(qw);
        parseImageList(list);

        return Result.success(list);
    }

    /**
     * 7. 管理员处理灾情（最终管理权限，可修改任意状态）
     */
    @PostMapping("/admin/handle/{reportId}")
    public Result<String> adminHandleReport(
            @PathVariable Long reportId,
            @RequestBody HandleReportRequest request
    ) {
        // 参数校验
        if (reportId == null || reportId <= 0) {
            return Result.error("灾情ID不能为空");
        }
        if (request == null || request.getHandleResult() == null || request.getHandleResult().trim().isEmpty()) {
            return Result.error("处理结果不能为空");
        }
        if (request.getStatus() == null || request.getStatus() < 0 || request.getStatus() > 2) {
            return Result.error("状态只能是0（待核实）、1（已核实）、2（驳回）");
        }

        // 1. 查询灾情记录（管理员可查所有）
        DisasterReportEntity report = reportService.getOne(
                new LambdaQueryWrapper<DisasterReportEntity>()
                        .eq(DisasterReportEntity::getReportId, reportId)
        );
        if (report == null) {
            return Result.error("灾情记录不存在");
        }

        // 2. 管理员可修改任意状态（最终管理）
        report.setStatus(request.getStatus());
        report.setHandleResult(request.getHandleResult());
        report.setHandleTime(LocalDateTime.now());

        // 3. 保存更新
        boolean updated = reportService.updateById(report);
        return updated ? Result.success("灾情处理成功") : Result.error("灾情处理失败");
    }

    /**
     * 工具方法：解析JSON格式的images字段为List<String>
     */
    private void parseImageList(List<DisasterReportEntity> list) {
        if (list == null || list.isEmpty()) {
            return;
        }

        list.forEach(report -> {
            try {
                if (report.getImages() != null && !report.getImages().trim().isEmpty()) {
                    report.setImageList(objectMapper.readValue(
                            report.getImages(),
                            new TypeReference<List<String>>() {}
                    ));
                } else {
                    report.setImageList(List.of()); // 空列表兜底
                }
            } catch (Exception e) {
                e.printStackTrace();
                report.setImageList(List.of()); // 解析失败置空
            }
        });
    }

    /**
     * 内部类：接收处理上报的参数
     * 包含处理结果和状态（适配信息员/管理员）
     */
    public static class HandleReportRequest {
        private String handleResult; // 处理/核实结果
        private Integer status;      // 状态（0=待核实，1=已核实，2=驳回）

        // Getter & Setter
        public String getHandleResult() {
            return handleResult;
        }

        public void setHandleResult(String handleResult) {
            this.handleResult = handleResult;
        }

        public Integer getStatus() {
            return status;
        }

        public void setStatus(Integer status) {
            this.status = status;
        }
    }
}