package com.lg.ruraldisasterplatform.controller;

import com.lg.ruraldisasterplatform.common.Result;
import com.lg.ruraldisasterplatform.entity.DisasterGuideEntity;
import com.lg.ruraldisasterplatform.service.DisasterGuideService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

/**
 * 防灾指南控制器
 */
@RestController
@RequestMapping("/guide")
@RequiredArgsConstructor
public class DisasterGuideController {

    private final DisasterGuideService disasterGuideService;

    /**
     * 获取所有防灾指南列表（支持按分类筛选）
     * @param category 指南分类（可选，如暴雨/滑坡）
     */
    @GetMapping("/list")
    public Result<List<DisasterGuideEntity>> getDisasterGuideList(
            @RequestParam(required = false) String category
    ) {
        List<DisasterGuideEntity> list = disasterGuideService.getDisasterGuidesByCategory(category);
        return Result.success(list);
    }

    /**
     * 获取单个防灾指南详情
     */
    @GetMapping("/{id}")
    public Result<DisasterGuideEntity> getDisasterGuideDetail(@PathVariable Long id) {
        if (id == null || id <= 0) {
            return Result.error("指南ID无效");
        }
        DisasterGuideEntity entity = disasterGuideService.getDisasterGuideById(id);
        if (entity == null) {
            return Result.error("防灾指南不存在");
        }
        return Result.success(entity);
    }
}