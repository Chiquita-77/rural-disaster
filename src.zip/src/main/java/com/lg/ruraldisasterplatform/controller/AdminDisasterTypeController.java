package com.lg.ruraldisasterplatform.controller;

import com.lg.ruraldisasterplatform.common.Result;
import com.lg.ruraldisasterplatform.entity.DisasterTypeEntity;
import com.lg.ruraldisasterplatform.service.DisasterTypeService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 管理员端 - 灾害类型管理控制器（对接前端/admin/disaster/type接口）
 */
@RestController
@RequestMapping("/admin/disaster/type")  // 前端请求的路径，必须和这个一致
@RequiredArgsConstructor
public class AdminDisasterTypeController {

    private final DisasterTypeService disasterTypeService;

    // 1. 前端获取灾害类型列表（对应前端 get('/admin/disaster/type/list')）
    @GetMapping("/list")
    public Result<List<DisasterTypeEntity>> getTypeList() {
        // 复用你现有Service的查询逻辑，按排序号升序返回
        List<DisasterTypeEntity> list = disasterTypeService.getAllDisasterTypes();
        return Result.success(list);
    }

    // 2. 前端保存/新增/编辑灾害类型（对应前端 post('/admin/disaster/type/save')）
    @PostMapping("/save")
    public Result<Boolean> saveType(@RequestBody DisasterTypeEntity typeEntity) {
        try {
            // 复用MyBatis-Plus的保存/更新方法
            boolean success = disasterTypeService.saveOrUpdate(typeEntity);
            return success ? Result.success(true) : Result.error("保存失败");
        } catch (Exception e) {
            return Result.error("保存异常：" + e.getMessage());
        }
    }

    // 3. 前端更新状态（启用/禁用，前端 post('/admin/disaster/type/status')）
    @PostMapping("/status")
    public Result<Boolean> updateStatus(@RequestParam Long id, @RequestParam Integer status) {
        try {
            DisasterTypeEntity entity = disasterTypeService.getById(id);
            if (entity == null) {
                return Result.error("灾害类型不存在");
            }
            // 这里给status字段赋值（你现有实体没有status，先临时用sortNum替代，后续再加字段）
            entity.setSortNum(status); // 临时方案：先用sortNum存状态（1=启用，0=禁用）
            boolean success = disasterTypeService.updateById(entity);
            return success ? Result.success(true) : Result.error("状态更新失败");
        } catch (Exception e) {
            return Result.error("状态更新异常：" + e.getMessage());
        }
    }
}