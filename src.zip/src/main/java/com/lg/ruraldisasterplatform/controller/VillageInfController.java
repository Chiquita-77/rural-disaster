package com.lg.ruraldisasterplatform.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.lg.ruraldisasterplatform.common.Result;
import com.lg.ruraldisasterplatform.entity.VillageInfEntity;
import com.lg.ruraldisasterplatform.service.VillageInfService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 村庄信息控制器
 */
@RestController
@RequestMapping("/village")
@RequiredArgsConstructor
public class VillageInfController {

    private final VillageInfService villageInfService;

    /**
     * 根据村庄ID查询村庄详情
     * 接口路径：/village/getById
     */
    @GetMapping("/getById")
    public Result<VillageInfEntity> getVillageById(@RequestParam Long villageId) {
        if (villageId == null || villageId <= 0) {
            return Result.error("村庄ID无效");
        }
        VillageInfEntity village = villageInfService.getVillageById(villageId);
        if (village == null) {
            return Result.error("村庄信息不存在");
        }
        return Result.success(village);
    }
    /**
     * 查询所有村庄列表（用于注册页选择）
     * 接口路径：/village/list
     */
    // 后续可以在这里扩展其他村庄相关接口，比如：
    // - /village/list：查询所有村庄列表
    @GetMapping("/list")
    public Result<List<VillageInfEntity>> getAllVillages() {
        List<VillageInfEntity> list = villageInfService.list(
                new LambdaQueryWrapper<VillageInfEntity>()
                        .eq(VillageInfEntity::getIsDeleted, 0)
                        .orderByAsc(VillageInfEntity::getVillageId)
        );
        return Result.success(list);
    }
    // - /village/update：更新村庄信息
    // - /village/delete：删除村庄（逻辑删除）
}