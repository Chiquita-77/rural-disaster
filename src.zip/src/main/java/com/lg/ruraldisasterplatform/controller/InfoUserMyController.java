package com.lg.ruraldisasterplatform.controller;

import com.lg.ruraldisasterplatform.common.Result;
import com.lg.ruraldisasterplatform.entity.InfoUserTipOperateLogEntity;
import com.lg.ruraldisasterplatform.service.InfoUserTipOperateLogService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

/**
 * 信息员端-我的操作记录Controller
 */
@RestController
@RequestMapping("/info-user/my")
@RequiredArgsConstructor
public class InfoUserMyController {

    private final InfoUserTipOperateLogService tipOperateLogService;

    /**
     * 信息员查询自己发布的风险提示操作记录（含审核状态）
     * 接口路径：/info-user/my/tip-log
     * @param infoUserId 当前登录信息员的ID（前端传参）
     */
    @GetMapping("/tip-log")
    public Result<List<InfoUserTipOperateLogEntity>> getMyTipLog(@RequestParam Long infoUserId) {
        if (infoUserId == null || infoUserId <= 0) {
            return Result.error("信息员ID无效");
        }
        try {
            List<InfoUserTipOperateLogEntity> logList = tipOperateLogService.getMyTipLog(infoUserId);
            return Result.success(logList);
        } catch (Exception e) {
            return Result.error("查询我的风险提示记录失败：" + e.getMessage());
        }
    }
}