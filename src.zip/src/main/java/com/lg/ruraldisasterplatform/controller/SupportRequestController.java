package com.lg.ruraldisasterplatform.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.lg.ruraldisasterplatform.common.Result;
import com.lg.ruraldisasterplatform.entity.SupportRequestEntity;
import com.lg.ruraldisasterplatform.service.SupportRequestService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/support")
@RequiredArgsConstructor
public class SupportRequestController {

    private final SupportRequestService supportService;

    /** 村级信息员提交支援申请 */
    @PostMapping("/apply")
    public Result<String> applySupport(@RequestBody SupportRequestEntity request) {
        // 用枚举替代硬编码
        request.setStatus(SupportRequestEntity.StatusEnum.PENDING.getCode());
        // 无需手动设置createTime，数据库自动填充
        boolean saved = supportService.save(request);
        return saved ? Result.success("申请提交成功") : Result.error("提交失败");
    }

    /** 乡镇查看所有待审批申请 */
    @GetMapping("/admin/list")
    public Result<List<SupportRequestEntity>> getAdminList() {
        LambdaQueryWrapper<SupportRequestEntity> qw = new LambdaQueryWrapper<>();
        qw.eq(SupportRequestEntity::getStatus, SupportRequestEntity.StatusEnum.PENDING.getCode());
        qw.orderByDesc(SupportRequestEntity::getCreateTime);
        return Result.success(supportService.list(qw));
    }

    /** 乡镇审批申请（类型安全：用实体类接收参数） */
    @PostMapping("/admin/{id}/approve")
    public Result<String> approveRequest(
            @PathVariable Long id,
            @RequestBody ApprovalRequest request
    ) {
        // 参数校验
        if (request.getDecision() == null || (request.getDecision() != 1 && request.getDecision() != 2)) {
            return Result.error("请选择审批结果");
        }
        if (request.getResult() == null || request.getResult().trim().isEmpty()) {
            return Result.error("审批意见不能为空");
        }

        // 先查询申请是否存在
        SupportRequestEntity supportRequest = supportService.getById(id);
        if (supportRequest == null) {
            return Result.error("申请记录不存在");
        }

        // 更新审批信息
        supportRequest.setStatus(request.getDecision());
        supportRequest.setApprovalResult(request.getResult().trim());
        supportRequest.setApproveTime(LocalDateTime.now());

        boolean updated = supportService.updateById(supportRequest);
        return updated ?
                Result.success(request.getDecision() == 1 ? "已批准" : "已拒绝") :
                Result.error("审批失败");
    }

    // 内部类：接收审批参数（类型安全）
    public static class ApprovalRequest {
        private Integer decision; // 1=批准, 2=拒绝
        private String result;    // 审批意见

        // getter/setter
        public Integer getDecision() {
            return decision;
        }

        public void setDecision(Integer decision) {
            this.decision = decision;
        }

        public String getResult() {
            return result;
        }

        public void setResult(String result) {
            this.result = result;
        }
    }
}