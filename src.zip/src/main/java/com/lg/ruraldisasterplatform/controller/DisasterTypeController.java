package com.lg.ruraldisasterplatform.controller;

import com.lg.ruraldisasterplatform.common.Result;
import com.lg.ruraldisasterplatform.entity.DisasterTypeEntity;
import com.lg.ruraldisasterplatform.service.DisasterTypeService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

/**
 * 灾害类型科普控制器
 */
@RestController
@RequestMapping("/guide/disaster-type")
@RequiredArgsConstructor
public class DisasterTypeController {

    private final DisasterTypeService disasterTypeService;

    /**
     * 获取所有灾害类型列表（前端科普列表页用）
     */
    @GetMapping("/list")
    public Result<List<DisasterTypeEntity>> getDisasterTypeList() {
        List<DisasterTypeEntity> list = disasterTypeService.getAllDisasterTypes();
        return Result.success(list);
    }

    /**
     * 获取单个灾害类型详情（前端科普详情页用）
     */
    @GetMapping("/{id}")
    public Result<DisasterTypeEntity> getDisasterTypeDetail(@PathVariable Long id) {
        if (id == null || id <= 0) {
            return Result.error("灾害类型ID无效");
        }
        DisasterTypeEntity entity = disasterTypeService.getDisasterTypeById(id);
        if (entity == null) {
            return Result.error("灾害类型不存在");
        }
        return Result.success(entity);
    }
}