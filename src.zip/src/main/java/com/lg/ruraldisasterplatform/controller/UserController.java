package com.lg.ruraldisasterplatform.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.lg.ruraldisasterplatform.common.Result;
import com.lg.ruraldisasterplatform.entity.UserEntity;
import com.lg.ruraldisasterplatform.service.UserService;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 合并版用户控制器（前台+后台接口统一管理）
 * 前台接口：/user/register、/user/login（路径不变，对前端无影响）
 * 后台接口：/user/admin/list、/user/admin/{id}/toggle（路径微调，不影响前端）
 */
@RestController
@RequestMapping("/user") // 统一前缀 /user
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    // ======================== 前台接口（登录/注册）========================
    /**
     * 前台注册接口（路径：/user/register → 完全保留原路径，无影响）
     */
    @PostMapping("/register")
    public Result<UserEntity> register(@RequestBody UserEntity user) {
        System.out.println("注册接口被调用了！");
        UserEntity registeredUser = userService.register(user);
        if (registeredUser == null) {
            return Result.error("注册失败，用户名/手机号已存在");
        }
        registeredUser.setPassword(null); // 清除敏感信息
        return Result.success(registeredUser);
    }

    /**
     * 前台登录接口（路径：/user/login → 完全保留原路径，无影响）
     * 传参：{phone: "", password: "", role: 1/2/3}
     */
    @PostMapping("/login")
    public Result<UserEntity> login(@RequestBody LoginRequest request) {
        UserEntity user = userService.login(request.getPhone(), request.getPassword(), request.getRole());
        if (user == null) {
            return Result.error("手机号、密码或角色错误，或账号已禁用");
        }
        user.setPassword(null); // 清除敏感信息
        return Result.success(user);
    }

    // ======================== 后台接口（管理员用户管理）========================
    /**
     * 后台获取用户列表（路径：/user/admin/list → 仅调整前缀，无影响）
     */
    @GetMapping("/admin/user/list")
    public Result<List<UserEntity>> getUserList() {
        LambdaQueryWrapper<UserEntity> qw = new LambdaQueryWrapper<>();
        qw.ne(UserEntity::getRole, 3)      // 排除乡镇管理员
                .eq(UserEntity::getIsDeleted, 0) // 未删除
                .orderByDesc(UserEntity::getCreateTime);

        List<UserEntity> userList = userService.list(qw);
        return Result.success(userList);
    }

    /**
     * 后台切换用户状态（路径：/user/admin/{id}/toggle → 仅调整前缀，无影响）
     */
    @PostMapping("/admin/{id}/toggle")
    public Result<String> toggleUserStatus(@PathVariable Long id) {
        UserEntity user = userService.getById(id);
        if (user == null || user.getIsDeleted() == 1) {
            return Result.error("用户不存在或已删除");
        }

        user.setStatus(user.getStatus() == 1 ? 0 : 1);
        boolean updateSuccess = userService.updateById(user);

        if (updateSuccess) {
            String msg = user.getStatus() == 1 ? "账号已启用" : "账号已禁用";
            return Result.success(msg);
        } else {
            return Result.error("操作失败，请重试");
        }
    }

    /**
     * 前台修改个人信息接口（路径：/user/update → 对应前端 /api/user/update）
     * 传参：{userId: "", username: "", phone: "", password: ""}
     */
    @PostMapping("/update")
    public Result<String> updateUserInfo(@RequestBody UserEntity user) {
        // 校验必填参数
        if (user.getUserId() == null) {
            return Result.error("用户ID不能为空");
        }
        // 调用Service修改信息
        boolean success = userService.updateUserInfo(user);
        return success ? Result.success("修改成功") : Result.error("修改失败");
    }


    // ======================== 内部类（登录请求DTO）========================
    @Data
    public static class LoginRequest {
        private String phone;       // 手机号
        private String password;    // 密码
        private Integer role;       // 角色：1=村民，2=信息员，3=管理员
    }
}