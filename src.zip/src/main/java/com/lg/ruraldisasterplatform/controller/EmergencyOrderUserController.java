package com.lg.ruraldisasterplatform.controller;

import com.lg.ruraldisasterplatform.common.Result;
import com.lg.ruraldisasterplatform.entity.EmergencyOrderEntity;
import com.lg.ruraldisasterplatform.service.EmergencyOrderReceiveService;
import com.lg.ruraldisasterplatform.service.EmergencyOrderService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 村民/信息员应急指令查看Controller
 */
@Slf4j // 新增日志注解
@RestController
@RequestMapping("/user/emergency/order")
@RequiredArgsConstructor
public class EmergencyOrderUserController {

    private final EmergencyOrderService emergencyOrderService;
    private final EmergencyOrderReceiveService receiveService;

    /**
     * 查询用户可查看的应急指令
     */
    @GetMapping("/list")
    public Result<List<EmergencyOrderEntity>> getUserOrderList(@RequestParam Long villageId) {
        try {
            log.info("开始查询村庄{}的生效中应急指令", villageId);
            List<EmergencyOrderEntity> orderList = emergencyOrderService.selectUserOrders(villageId);
            log.info("村庄{}查询到{}条生效中应急指令", villageId, orderList.size());
            return Result.success(orderList);
        } catch (Exception e) {
            log.error("查询村庄{}的应急指令失败", villageId, e);
            return Result.error("查询应急指令失败：" + e.getMessage());
        }
    }

    /**
     * 查询未读指令数量
     */
    @GetMapping("/unread/count")
    public Result<Integer> getUnreadCount(@RequestParam Long userId) {
        try {
            log.info("查询用户{}的未读指令数量", userId);
            int count = receiveService.getUnreadCount(userId);
            return Result.success(count);
        } catch (Exception e) {
            log.error("查询用户{}未读指令数量失败", userId, e);
            return Result.success(0); // 异常时返回0，不影响前端
        }
    }

    /**
     * 标记指令为已读
     */
    @PostMapping("/read/{orderId}")
    public Result<String> markAsRead(@PathVariable Long orderId, @RequestParam Long userId) {
        try {
            log.info("用户{}标记指令{}为已读", userId, orderId);
            boolean success = receiveService.markAsRead(orderId, userId);
            if (success) {
                return Result.success("标记已读成功");
            } else {
                return Result.error("标记失败：未找到该指令的接收记录");
            }
        } catch (Exception e) {
            log.error("用户{}标记指令{}为已读失败", userId, orderId, e);
            return Result.error("标记已读失败：" + e.getMessage());
        }
    }

    /**
     * 查询指令详情
     */
    @GetMapping("/detail/{orderId}")
    public Result<EmergencyOrderEntity> getOrderDetail(
            @PathVariable Long orderId,
            @RequestParam Long userId) {
        // 👇 核心修改：直接查询指令，不做权限检查
        EmergencyOrderEntity order = emergencyOrderService.getById(orderId);
        if (order == null) {
            return Result.error("指令不存在");
        }
        // 自动标记为已读（不影响查看）
        receiveService.markAsRead(orderId, userId);
        return Result.success(order);
    }
}