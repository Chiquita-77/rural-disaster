package com.lg.ruraldisasterplatform.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.lg.ruraldisasterplatform.common.Result;
import com.lg.ruraldisasterplatform.entity.EmergencyOrderEntity;
import com.lg.ruraldisasterplatform.service.EmergencyOrderService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/admin/emergency/order")
@RequiredArgsConstructor
public class EmergencyOrderAdminController {

    private final EmergencyOrderService emergencyOrderService;

    @GetMapping("/list")
    public Result<IPage<EmergencyOrderEntity>> getOrderList(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(required = false) Integer status) {
        Page<EmergencyOrderEntity> page = new Page<>(pageNum, pageSize);
        IPage<EmergencyOrderEntity> orderPage = emergencyOrderService.selectAdminPage(page, status);
        return Result.success(orderPage);
    }

    @PostMapping("/publish")
    public Result<String> publishOrder(@RequestBody EmergencyOrderEntity order) {
        if (order.getTitle() == null || order.getTitle().trim().isEmpty()) {
            return Result.error("指令标题不能为空");
        }
        if (order.getContent() == null || order.getContent().trim().isEmpty()) {
            return Result.error("指令内容不能为空");
        }
        if (order.getPublisherId() == null) {
            return Result.error("发布人ID不能为空");
        }
        if (order.getPublisherName() == null || order.getPublisherName().trim().isEmpty()) {
            return Result.error("发布人名称不能为空");
        }
        if (order.getScopeType() == null) {
            return Result.error("适用范围不能为空");
        }
        if ("1".equals(order.getScopeType()) && (order.getVillageIds() == null || order.getVillageIds().trim().isEmpty())) {
            return Result.error("指定村庄适用时，村庄ID不能为空");
        }

        boolean success = emergencyOrderService.publishOrder(order);
        return success ? Result.success("指令发布成功") : Result.error("指令发布失败");
    }

    @PostMapping("/status")
    public Result<String> updateOrderStatus(
            @RequestParam Long orderId,
            @RequestParam Integer status) {
        if (status != 0 && status != 1 && status != 2) {
            return Result.error("状态值无效，仅支持0=未生效、1=生效中、2=已失效");
        }
        boolean success = emergencyOrderService.updateOrderStatus(orderId, status);
        return success ? Result.success("状态更新成功") : Result.error("状态更新失败，指令不存在");
    }

    @GetMapping("/detail/{orderId}")
    public Result<EmergencyOrderEntity> getOrderDetail(@PathVariable Long orderId) {
        EmergencyOrderEntity order = emergencyOrderService.getById(orderId);
        if (order == null) {
            return Result.error("指令不存在");
        }
        return Result.success(order);
    }

    @GetMapping("/receive/stats")
    public Result<List<Map<String, Object>>> getOrderReceiveStats() {
        List<Map<String, Object>> stats = emergencyOrderService.getOrderReceiveStats();
        return Result.success(stats);
    }

    @GetMapping("/unread/detail")
    public Result<List<Map<String, Object>>> getUnreadDetails(
            @RequestParam Long orderId,
            @RequestParam(required = false) Long villageId) {
        List<Map<String, Object>> details = emergencyOrderService.getUnreadDetails(orderId, villageId);
        return Result.success(details);
    }
}