package com.lg.ruraldisasterplatform.controller;

import com.lg.ruraldisasterplatform.common.Result;
import com.lg.ruraldisasterplatform.entity.WarningNoticeEntity;
import com.lg.ruraldisasterplatform.service.WarningNoticeService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 村民端 - 预警通知查询控制器
 */
@RestController
@RequestMapping("/villager/warning")
@RequiredArgsConstructor
public class VillagerWarningController {

    private final WarningNoticeService warningNoticeService;

    /**
     * 村民查看所有启用的预警（禁用的自动过滤）
     */
    @GetMapping("/list")
    public Result<List<WarningNoticeEntity>> getEnabledWarningList() {
        // 只返回启用状态（isPushed=1）的预警
        List<WarningNoticeEntity> list = warningNoticeService.listByPushStatus(1);
        return Result.success(list);
    }
}