package com.lg.ruraldisasterplatform.controller;

import com.lg.ruraldisasterplatform.entity.ShelterInfEntity;
import com.lg.ruraldisasterplatform.service.ShelterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/shelter")
public class ShelterController {

    @Autowired
    private ShelterService shelterService;

    // 查询本村所有开放的避难所
    @GetMapping("/list")
    public List<ShelterInfEntity> list(@RequestParam Long villageId) {
        return shelterService.listByVillage(villageId);
    }

    // 查看避难所详情
    @GetMapping("/{id}")
    public ShelterInfEntity detail(@PathVariable Long id) {
        return shelterService.getById(id);
    }
}