package com.lg.ruraldisasterplatform.controller;

import com.lg.ruraldisasterplatform.common.Result;
import com.lg.ruraldisasterplatform.entity.WarningNoticeEntity;
import com.lg.ruraldisasterplatform.service.WarningNoticeService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * 管理员端 - 灾害预警通知管理控制器
 */
@RestController
@RequestMapping("/admin/warning")
@RequiredArgsConstructor
public class AdminWarningNoticeController {

    private final WarningNoticeService warningNoticeService;

    /**
     * 1. 获取预警通知列表（支持按启用状态筛选）
     * @param isPushed 0=禁用，1=启用，不传=全部
     */
    @GetMapping("/list")
    public Result<List<WarningNoticeEntity>> getWarningList(
            @RequestParam(required = false) Integer isPushed
    ) {
        List<WarningNoticeEntity> list = warningNoticeService.listByPushStatus(isPushed);
        return Result.success(list);
    }

    /**
     * 2. 【注释掉】管理员不再发布预警，只做启用/禁用
     */
    /*
    @PostMapping("/save")
    public Result<Boolean> saveWarning(@RequestBody WarningNoticeEntity notice) {
        try {
            if (notice.getWarningId() == null) {
                notice.setPublishTime(LocalDateTime.now());
                notice.setIsPushed(0);
                notice.setReadCount(0);
                notice.setUnreadCount(0);
            }
            boolean success = warningNoticeService.saveOrUpdate(notice);
            return success ? Result.success(true) : Result.error("保存失败");
        } catch (Exception e) {
            return Result.error("保存异常：" + e.getMessage());
        }
    }
    */

    /**
     * 3. 获取单条预警详情
     */
    @GetMapping("/{warningId}")
    public Result<WarningNoticeEntity> getWarningDetail(@PathVariable Long warningId) {
        if (warningId == null || warningId <= 0) {
            return Result.error("预警ID无效");
        }
        WarningNoticeEntity notice = warningNoticeService.getById(warningId);
        if (notice == null) {
            return Result.error("预警通知不存在");
        }
        return Result.success(notice);
    }

    /**
     * 4. 管理员启用/禁用预警（核心修改）
     * @param warningId 预警ID
     * @param status 0=禁用，1=启用
     */
    @PostMapping("/toggle-status/{warningId}")
    public Result<Boolean> toggleWarningStatus(
            @PathVariable Long warningId,
            @RequestParam Integer status // 0=禁用，1=启用
    ) {
        try {
            WarningNoticeEntity notice = warningNoticeService.getById(warningId);
            if (notice == null) {
                return Result.error("预警通知不存在");
            }
            // 更新启用/禁用状态
            notice.setIsPushed(status);
            notice.setPushTime(status == 1 ? LocalDateTime.now() : null); // 启用时记录时间，禁用清空
            notice.setUpdateTime(LocalDateTime.now());
            boolean success = warningNoticeService.updateById(notice);
            return success ? Result.success(true) : Result.error("状态更新失败");
        } catch (Exception e) {
            return Result.error("状态更新异常：" + e.getMessage());
        }
    }

    /**
     * 5. 获取预警接收统计（保留）
     */
    @GetMapping("/stat/{warningId}")
    public Result<Map<String, Integer>> getWarningStat(@PathVariable Long warningId) {
        if (warningId == null || warningId <= 0) {
            return Result.error("预警ID无效");
        }
        Map<String, Integer> stat = warningNoticeService.getReadUnreadStat(warningId);
        return Result.success(stat);
    }

    /**
     * 6. 【注释掉】二次推送不再需要，改为启用/禁用
     */
    /*
    @PostMapping("/repush/{warningId}")
    public Result<Boolean> repushWarning(@PathVariable Long warningId) {
        try {
            boolean success = warningNoticeService.repushWarning(warningId);
            if (success) {
                return Result.success(true);
            } else {
                return Result.error("二次推送失败");
            }
        } catch (Exception e) {
            return Result.error("二次推送异常：" + e.getMessage());
        }
    }
    */

    /**
     * 7. 删除预警通知（保留）
     */
    @PostMapping("/delete/{warningId}")
    public Result<Boolean> deleteWarning(@PathVariable Long warningId) {
        try {
            boolean success = warningNoticeService.removeById(warningId);
            return success ? Result.success(true) : Result.error("删除失败");
        } catch (Exception e) {
            return Result.error("删除异常：" + e.getMessage());
        }
    }
}