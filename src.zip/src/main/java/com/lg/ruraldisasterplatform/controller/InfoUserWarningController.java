package com.lg.ruraldisasterplatform.controller;

import com.lg.ruraldisasterplatform.common.Result;
import com.lg.ruraldisasterplatform.entity.WarningNoticeEntity;
import com.lg.ruraldisasterplatform.service.WarningNoticeService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;

/**
 * 信息员端 - 灾害预警通知发布控制器
 */
@RestController
@RequestMapping("/info-user/warning")
@RequiredArgsConstructor
public class InfoUserWarningController {

    private final WarningNoticeService warningNoticeService;

    /**
     * 信息员发布预警（直接启用，村民可见）
     */
    @PostMapping("/submit")
    public Result<Boolean> submitWarning(@RequestBody WarningNoticeEntity notice) {
        try {
            // 信息员发布默认启用，村民直接可见
            notice.setIsPushed(1);
            notice.setPublishTime(LocalDateTime.now());
            notice.setPushTime(LocalDateTime.now()); // 启用时间=发布时间
            notice.setSubmitterType("info_user"); // 标记为信息员发布
            notice.setReadCount(0);
            notice.setUnreadCount(0);

            boolean success = warningNoticeService.save(notice);
            return success ? Result.success(true) : Result.error("发布失败");
        } catch (Exception e) {
            return Result.error("发布异常：" + e.getMessage());
        }
    }

    /**
     * 信息员获取自己发布的预警列表
     */
    @PostMapping("/my-list")
    public Result<java.util.List<WarningNoticeEntity>> getMyWarningList(@RequestBody Long publisherId) {
        // 实际项目中需按发布人ID筛选，这里简化返回全部（后续可优化）
        java.util.List<WarningNoticeEntity> list = warningNoticeService.listByPushStatus(null);
        return Result.success(list);
    }
}