package com.lg.ruraldisasterplatform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RuralDisasterPlatformApplicationTests {

    @Test
    void contextLoads() {
    }

}
