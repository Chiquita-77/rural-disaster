<template>
  <view class="container">
    <view class="form-item">
      <text class="label">灾情标题 *</text>
      <input
        v-model="formData.title"
        class="input"
        placeholder="如：山体滑坡阻断道路"
        maxlength="50"
      />
    </view>

    <view class="form-item">
      <text class="label">详细描述 *</text>
      <textarea
        v-model="formData.content"
        class="textarea"
        placeholder="请描述位置、严重程度、是否有人受伤等..."
        maxlength="500"
      />
    </view>

    <!-- 图片上传 -->
    <view class="form-item">
      <text class="label">现场照片（最多3张）</text>
      <view class="upload-area">
        <view 
          v-for="(img, index) in imageList" 
          :key="index" 
          class="preview"
        >
          <image :src="img" mode="aspectFill" />
          <view class="del" @click.stop="removeImage(index)">×</view>
        </view>
        <view 
          v-if="imageList.length < 3" 
          class="upload-btn"
          @click="chooseImage"
        >
          +
        </view>
      </view>
    </view>

    <!-- 自动获取位置（简化版） -->
    <view class="form-item">
      <text class="label">位置信息</text>
      <view class="readonly">{{ locationText || '点击获取位置' }}</view>
      <button class="location-btn" @click="getLocation">获取当前位置</button>
    </view>

    <button class="submit-btn" @click="handleSubmit" :loading="submitting">
      {{ submitting ? '提交中...' : '立即上报' }}
    </button>
  </view>
</template>

<script>
import { post } from '@/utils/request'

export default {
  data() {
    return {
      villageId: '',
      villageName: '',
      submitting: false,
      formData: {
        title: '',
        content: '',
        latitude: null,
        longitude: null
      },
      imageList: [], // 用于预览
      locationText: ''
    }
  },

  onLoad(options) {
    this.villageId = options.villageId || 101
    this.villageName = options.villageName || 'XX村'
  },

  methods: {
    // 选择图片（修复返回值解析错误）
    async chooseImage() {
      try {
        const res = await uni.chooseImage({
          count: 3 - this.imageList.length,
          sizeType: ['compressed'],
          sourceType: ['album', 'camera']
        })
        // 核心修复：uni.chooseImage返回值是tempFilePaths数组，不是res[1]
        if (res.tempFilePaths && res.tempFilePaths.length > 0) {
          this.imageList.push(...res.tempFilePaths)
        }
      } catch (err) {
        uni.showToast({ title: '选择图片失败', icon: 'none' })
      }
    },

    // 删除图片
    removeImage(index) {
      this.imageList.splice(index, 1)
    },

    // 获取位置（简化：只取经纬度）
    getLocation() {
      uni.getLocation({
        type: 'wgs84',
        success: (res) => {
          this.formData.latitude = res.latitude
          this.formData.longitude = res.longitude
          this.locationText = `纬度: ${res.latitude.toFixed(4)}, 经度: ${res.longitude.toFixed(4)}`
        },
        fail: () => {
          uni.showToast({ title: '获取位置失败', icon: 'none' })
        }
      })
    },

    // 提交（核心修复：图片数组转JSON字符串）
    async handleSubmit() {
      // 1. 表单校验
      if (!this.formData.title.trim()) {
        uni.showToast({ title: '请输入灾情标题', icon: 'none' })
        return
      }
      if (!this.formData.content.trim()) {
        uni.showToast({ title: '请输入详细描述', icon: 'none' })
        return
      }
      if (!this.villageId) {
        uni.showToast({ title: '村庄ID不能为空', icon: 'none' })
        return
      }

      this.submitting = true

      try {
        // 2. 处理图片（模拟上传，实际替换为你的OSS上传接口）
        let imageUrls = []
        if (this.imageList.length > 0) {
          // 模拟上传后的图片URL（实际开发替换为真实上传返回的URL）
          imageUrls = this.imageList.map((_, i) => `https://mock.com/report_${Date.now()}_${i}.jpg`)
        }

        // 3. 构造请求参数（核心：images数组转JSON字符串）
        const submitData = {
          title: this.formData.title.trim(),
          content: this.formData.content.trim(),
          images: JSON.stringify(imageUrls), // 转JSON字符串，匹配后端存储格式
          latitude: this.formData.latitude || 0, // 空值兜底
          longitude: this.formData.longitude || 0, // 空值兜底
          villageId: Number(this.villageId) // 确保是数字类型，匹配后端Long类型
        }

        // 4. 调用后端接口
        const res = await post('/report/submit', submitData)
        
        // 5. 提交成功处理
        if (res.code === 200) {
          uni.showToast({ title: '上报成功！', icon: 'success' })
          setTimeout(() => {
            uni.redirectTo({
              url: `/pages/village/detail?villageId=${this.villageId}`
            })
          }, 1000)
        } else {
          uni.showToast({ title: res.msg || '上报失败', icon: 'none' })
        }

      } catch (err) {
        console.error('上报失败:', err)
        uni.showToast({ title: '上报失败，请重试', icon: 'none' })
      } finally {
        this.submitting = false
      }
    }
  }
}
</script>

<style scoped>
/* 样式复用 publish.vue，略作调整 */
.container {
  padding: 30rpx;
  background-color: #f8f9fa;
}
.form-item {
  margin-bottom: 40rpx;
}
.label {
  display: block;
  font-size: 28rpx;
  color: #333;
  margin-bottom: 16rpx;
  font-weight: bold;
}
/* 修正：增加 input 高度，解决输入框太矮的问题 */
.input {
  width: 100%;
  padding: 20rpx;
  height: 80rpx; /* 新增高度 */
  background: white;
  border-radius: 12rpx;
  font-size: 28rpx;
  box-sizing: border-box;
}
.textarea, .readonly {
  width: 100%;
  padding: 20rpx;
  background: white;
  border-radius: 12rpx;
  font-size: 28rpx;
  box-sizing: border-box;
}
.textarea { min-height: 200rpx; line-height: 1.5; }

/* 图片上传区 */
.upload-area {
  display: flex;
  flex-wrap: wrap;
  gap: 20rpx;
}
.preview {
  position: relative;
  width: 180rpx;
  height: 180rpx;
}
.preview image {
  width: 100%;
  height: 100%;
  border-radius: 12rpx;
}
.del {
  position: absolute;
  top: -10rpx;
  right: -10rpx;
  width: 40rpx;
  height: 40rpx;
  background: red;
  color: white;
  border-radius: 50%;
  text-align: center;
  line-height: 40rpx;
}
.upload-btn {
  width: 180rpx;
  height: 180rpx;
  background: #f0f0f0;
  border-radius: 12rpx;
  font-size: 60rpx;
  color: #999;
  display: flex;
  align-items: center;
  justify-content: center;
}

.location-btn {
  margin-top: 20rpx;
  width: 200rpx;
  height: 60rpx;
  background: #409eff;
  color: white;
  font-size: 28rpx;
  border-radius: 8rpx;
  border: none;
}

.submit-btn {
  width: 100%;
  height: 90rpx;
  background: #e64340;
  color: white;
  font-size: 32rpx;
  border-radius: 16rpx;
  margin-top: 60rpx;
  border: none;
}
</style>