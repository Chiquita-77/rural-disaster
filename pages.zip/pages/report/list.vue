<template>
  <view class="page-wrapper">
    <view class="container">
      <!-- 加载状态 -->
      <view v-if="loading" class="empty">
        <text>加载中...</text>
      </view>
      
      <!-- 空状态 -->
      <view v-else-if="list.length === 0" class="empty">
        <text>暂无待核实的灾情上报</text>
      </view>
      
      <!-- 灾情列表 -->
      <view v-else class="report-list">
        <view 
          v-for="item in list" 
          :key="item.reportId" 
          class="report-item"
          @click="goDetail(item)"
        >
          <view class="header">
            <text class="title">{{ item.title || '灾情上报' }}</text>
            <text class="status">{{ getStatusText(item.status) }}</text>
          </view>
          <text class="content">{{ item.content || '暂无描述' }}</text>
          <view class="footer">
            <text class="time">{{ formatDate(item.createTime) }}</text>
            <view v-if="item.imageList && item.imageList.length" class="image-preview">
              <image :src="item.imageList[0]" mode="aspectFill" />
            </view>
          </view>
        </view>
      </view>
    </view>
  </view>
</template>

<script>
import { get } from '@/utils/request'
import { getCurrentVillageId } from '@/utils/auth'

export default {
  data() {
    return {
      villageId: '',
      list: [],
      loading: false,
      isLoading: false,
      lastLoadTime: 0
    }
  },
  onShow() {
    if (Date.now() - this.lastLoadTime < 1000) return
    this.loadList()
  },
  async onLoad(options) {
    this.villageId = Number(options.villageId) || Number(getCurrentVillageId())
    if (!this.villageId || this.villageId <= 0) {
      uni.showToast({ title: '当前村庄ID无效', icon: 'none' })
      return uni.navigateBack()
    }
    await this.loadList()
  },
  methods: {
    // 修复：用 switchTab 跳转到 tabbar 页面
    goBack() {
      uni.switchTab({
        url: '/pages/service/index'
      })
    },
    async loadList() {
      if (this.isLoading) return
      this.isLoading = true
      this.loading = true
      this.lastLoadTime = Date.now()

      try {
        const res = await get('/report/info/list', {
          villageId:101,
          status: 0
        })
        this.list = Array.isArray(res.data) ? res.data : []
      } catch (err) {
        console.error('加载灾情列表失败：', err)
        if (err.errMsg && !err.errMsg.includes('abort')) {
          uni.showToast({ title: '加载失败，请重试', icon: 'none', duration: 2000 })
        }
        this.list = []
      } finally {
        this.loading = false
        this.isLoading = false
      }
    },
    goDetail(item) {
      const reportId = item.reportId
      if (!reportId || reportId === 0 || reportId === "0") {
        uni.showToast({ title: '灾情ID无效', icon: 'none' })
        return
      }
      uni.navigateTo({
        url: `/pages/report/detail?id=${Number(reportId)}&villageId=${this.villageId}`
      })
    },
    getStatusText(status) {
      const textMap = { 0: '待核实', 1: '已核实', 2: '已驳回' }
      return textMap[status] || '未知状态'
    },
    formatDate(timeStr) {
      if (!timeStr) return '未知时间'
      return timeStr.includes('T') 
        ? timeStr.replace('T', ' ').substring(0, 16) 
        : timeStr.substring(0, 16)
    }
  }
}
</script>

<style scoped>
/* 新增顶部返回按钮样式 */
.page-wrapper {
  background: #f8f9fa;
  min-height: 100vh;
}
.top-back {
  display: flex;
  align-items: center;
  padding: 20rpx 20rpx 10rpx;
  background: #fff;
  border-bottom: 1px solid #eee;
}
.back-btn {
  width: 60rpx;
  height: 60rpx;
  display: flex;
  align-items: center;
  justify-content: center;
}
.back-icon {
  font-size: 36rpx;
  color: #333;
}
.page-title {
  flex: 1;
  text-align: center;
  font-size: 32rpx;
  font-weight: bold;
  color: #333;
}

/* 原有样式 */
.container { 
  padding: 20rpx; 
  background: #f8f9fa; 
  min-height: calc(100vh - 80rpx);
}
.empty { 
  text-align: center; 
  padding: 100rpx 0; 
  color: #999; 
  font-size: 28rpx;
}
.report-list {
  padding-bottom: 20rpx;
}
.report-item {
  background: white;
  border-radius: 16rpx;
  padding: 30rpx;
  margin-bottom: 20rpx;
  box-shadow: 0 2rpx 8rpx rgba(0,0,0,0.05);
  transition: all 0.2s;
}
.report-item:active {
  transform: scale(0.98);
}
.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20rpx;
}
.title { 
  font-size: 32rpx; 
  font-weight: bold; 
  color: #333;
}
.status { 
  color: #e64340; 
  font-size: 28rpx; 
  font-weight: 500;
}
.content { 
  font-size: 28rpx; 
  color: #333; 
  line-height: 1.5; 
  margin-bottom: 20rpx; 
}
.footer { 
  display: flex; 
  justify-content: space-between; 
  align-items: center; 
}
.time { 
  font-size: 24rpx; 
  color: #999; 
}
.image-preview {
  width: 80rpx;
  height: 80rpx;
  border-radius: 8rpx;
  overflow: hidden;
}
.image-preview image {
  width: 100%;
  height: 100%;
}
</style>