<template>
  <view class="container">
    <!-- 加载状态 -->
    <view v-if="loading" class="loading">
      <text>加载中...</text>
    </view>

    <!-- 灾情信息 -->
    <view v-else class="content-wrap">
      <view class="section">
        <view class="field">
          <text class="label">标题：</text>
          <text>{{ report.title || '无' }}</text>
        </view>
        <view class="field">
          <text class="label">描述：</text>
          <text>{{ report.content || '无' }}</text>
        </view>
        <view class="field" v-if="report.locationDesc">
          <text class="label">位置：</text>
          <text>{{ report.locationDesc }}</text>
        </view>
        <view class="field" v-if="report.latitude">
          <text class="label">坐标：</text>
          <text>{{ report.latitude.toFixed(4) }}, {{ report.longitude.toFixed(4) }}</text>
        </view>
        <view class="field" v-if="report.createTime">
          <text class="label">上报时间：</text>
          <text>{{ formatDate(report.createTime) }}</text>
        </view>
        <view class="field" v-if="report.status">
          <text class="label">当前状态：</text>
          <text :class="{'success': report.status === 1, 'fail': report.status === 2}">
            {{ report.status === 1 ? '已核实' : report.status === 2 ? '已驳回' : '待核实' }}
          </text>
        </view>
      </view>

      <!-- 图片展示 -->
      <view class="section" v-if="report.imageList && report.imageList.length">
        <text class="section-title">现场照片</text>
        <view class="image-grid">
          <image 
            v-for="(url, idx) in report.imageList" 
            :key="idx"
            :src="url" 
            class="preview-img"
            @click="previewImage(url)"
          />
        </view>
      </view>

      <!-- 处理结果输入框（仅待核实状态显示） -->
      <view class="section" v-if="report.status === 0">
        <text class="label required">处理结果 *</text>
        <textarea
          v-model="handleResult"
          class="textarea"
          placeholder="请输入核实结果/驳回原因..."
          maxlength="200"
        />
      </view>

      <!-- 操作区（仅待核实状态显示） -->
      <view class="action-bar" v-if="report.status === 0">
        <button class="btn reject" @click="handleReject">❌ 驳回</button>
        <button class="btn verify" @click="handleVerify">✅ 核实通过</button>
      </view>
    </view>
  </view>
</template>

<script>
import { get, post } from '@/utils/request'

export default {
  data() {
    return {
      reportId: '',
      villageId: '',
      report: {},
      handleResult: '',
      loading: false
    }
  },
  async onLoad(options) {
    // 接收参数并校验
    this.reportId = Number(options.id)
    this.villageId = Number(options.villageId)
    
    if (!this.reportId || this.reportId <= 0) {
      uni.showToast({ title: '灾情ID无效', icon: 'none' })
      return setTimeout(() => uni.navigateBack(), 1500)
    }
    if (!this.villageId || this.villageId <= 0) {
      uni.showToast({ title: '村庄ID无效', icon: 'none' })
      return setTimeout(() => uni.navigateBack(), 1500)
    }

    // 加载详情
    await this.loadDetail()
  },
  methods: {
    async loadDetail() {
      this.loading = true
      try {
        // 调用通用详情接口
        const res = await get(`/report/${this.reportId}`)
        this.report = res.data || {}
      } catch (err) {
        console.error('加载详情失败：', err)
        uni.showToast({ title: '加载详情失败', icon: 'none' })
      } finally {
        this.loading = false
      }
    },
    // 核实通过（status=1）
    async handleVerify() {
      if (!this.handleResult.trim()) {
        return uni.showToast({ title: '请输入核实结果', icon: 'none' })
      }
      await this.updateStatus(1, '核实通过')
    },
    // 驳回（status=2）
    async handleReject() {
      if (!this.handleResult.trim()) {
        return uni.showToast({ title: '请输入驳回原因', icon: 'none' })
      }
      await this.updateStatus(2, '驳回成功')
    },
    // 核心：调用信息员专属核实接口（修复版）
    async updateStatus(status, tipText) {
      // 前置校验：确保状态值合法
      if (![1, 2].includes(status)) {
        uni.showToast({ title: '状态参数错误', icon: 'none' })
        return
      }
      
      uni.showLoading({ title: '处理中...' })
      try {
        // 关键修复：把villageId直接拼到URL末尾，确保后端能接收到
        const requestUrl = `/report/info/handle/${this.reportId}?villageId=${this.villageId}`
        // 发起POST请求，参数仅传handleResult和status
        await post(requestUrl, {
          handleResult: this.handleResult.trim(), // 强制去空格，避免空字符串
          status: status // 确保status是1或2
        })
        
        uni.showToast({ title: tipText, icon: 'success' })
        // 跳转回列表页
        setTimeout(() => {
          uni.redirectTo({
            url: `/pages/report/list?villageId=${this.villageId}`
          })
        }, 800)
      } catch (err) {
        console.error('处理失败：', err)
        // 打印具体错误信息，方便排查
        console.error('错误详情：', err.response?.data || err.message)
        uni.showToast({ title: '操作失败', icon: 'none' })
      } finally {
        uni.hideLoading()
      }
    },
    // 预览图片
    previewImage(url) {
      uni.previewImage({
        urls: this.report.imageList,
        current: url
      })
    },
    // 格式化时间
    formatDate(timeStr) {
      if (!timeStr) return '未知时间'
      return timeStr.includes('T') 
        ? timeStr.replace('T', ' ').substring(0, 16) 
        : timeStr.substring(0, 16)
    }
  }
}
</script>

<style scoped>
.container { 
  padding: 30rpx; 
  background: #f8f9fa; 
  min-height: 100vh;
}
.loading {
  text-align: center;
  padding: 50rpx 0;
  color: #999;
  font-size: 28rpx;
}
.content-wrap {
  background: white;
  border-radius: 16rpx;
  padding: 30rpx;
}
.section {
  margin-bottom: 30rpx;
}
.section-title {
  font-weight: bold;
  margin-bottom: 20rpx;
  display: block;
  font-size: 30rpx;
}
.field {
  margin-bottom: 20rpx;
  line-height: 1.5;
  font-size: 28rpx;
}
.label {
  color: #e64340;
  font-weight: bold;
  margin-right: 10rpx;
}
.required::after {
  content: '*';
  color: #f44336;
  margin-left: 5rpx;
}
.success {
  color: #4caf50;
}
.fail {
  color: #f44336;
}
.image-grid {
  display: flex;
  flex-wrap: wrap;
  gap: 16rpx;
}
.preview-img {
  width: 200rpx;
  height: 200rpx;
  border-radius: 12rpx;
}
.textarea {
  width: 100%;
  padding: 20rpx;
  background: #f8f9fa;
  border-radius: 12rpx;
  font-size: 28rpx;
  min-height: 120rpx;
  margin-top: 10rpx;
  box-sizing: border-box;
  border: 1px solid #eee;
}
.action-bar {
  display: flex;
  justify-content: space-between;
  padding: 0 10rpx;
  margin-top: 20rpx;
}
.btn {
  flex: 1;
  height: 80rpx;
  border-radius: 12rpx;
  font-size: 32rpx;
  margin: 0 10rpx;
  border: none;
}
.verify {
  background: #4caf50;
  color: white;
}
.reject {
  background: #f44336;
  color: white;
}
</style>