<template>
  <view class="history-list-container">
    <view class="header-bar">
      <text class="title">历史灾情记录</text>
    </view>

    <view class="filter-bar">
      <picker @change="onStatusChange" :value="statusIndex" :range="statusList">
        <view class="filter-item">
          {{ statusList[statusIndex] }}
          <text class="arrow">▼</text>
        </view>
      </picker>
    </view>

    <view class="list-container">
      <view 
        v-for="item in reportList" 
        :key="item.reportId" 
        class="report-item"
        @click="goDetail(item.reportId)"
      >
        <view class="report-title">{{ item.title }}</view>
        <view class="report-content">{{ item.content }}</view>
        <view class="report-info">
          <text class="status-tag" :class="getStatusClass(item.status)">{{ getStatusText(item.status) }}</text>
          <text class="time">{{ formatTime(item.createTime) }}</text>
        </view>
      </view>

      <view v-if="reportList.length === 0" class="empty-tip">
        <text>暂无灾情记录</text>
      </view>
    </view>
  </view>
</template>

<script>
import { get } from '@/utils/request'
import { getUserInfo } from '@/utils/auth'

export default {
  data() {
    return {
      villageId: null,
      // 筛选列表匹配后端：0=待核实，1=已核实，2=已驳回
      statusList: ['全部', '待处理', '已处理'],
      statusIndex: 0,
      // 状态映射：后端值 → 前端文本（对齐之前的接口定义）
      statusMap: { 0: '待处理', 1: '已处理', 2: '已驳回' },
      reportList: []
    }
  },
  onLoad() {
    // 核心修改：强制写死为101，彻底抛弃userInfo里的villageId
    this.villageId = 101
    // 移除多余的villageId校验（因为已经强制为101，不可能为空）
    this.loadReportList()
  },
  methods: {
    async loadReportList() {
      try {
        // 1. 映射前端筛选值到后端status：
        // 前端index 0=全部 → 不传status；1=待处理→0；2=已处理→1/2
        const statusMap = { 1: 0, 2: 1 }
        const params = {
          villageId: this.villageId, // 必传101
          // 非全部时传递后端对应的status值
          ...(this.statusIndex !== 0 ? { status: statusMap[this.statusIndex] } : {})
        }
        
        // 2. 接口地址保持为村民历史灾情的 /report/my
        const res = await get('/report/my', params)
        if (res.code === 200 && res.data) {
          this.reportList = res.data
        } else {
          this.reportList = [] // 兜底为空数组，避免页面报错
          uni.showToast({ title: '加载失败', icon: 'none' })
        }
      } catch (err) {
        console.error('加载灾情列表异常：', err)
        // 新增：打印请求参数，方便排查
        console.error('请求参数：', { villageId: this.villageId, status: statusMap[this.statusIndex] })
        uni.showToast({ title: '网络异常，请重试', icon: 'none' })
      }
    },

    onStatusChange(e) {
      this.statusIndex = parseInt(e.detail.value)
      this.loadReportList()
    },

    // 匹配后端status值返回文本（兼容已驳回状态）
    getStatusText(status) {
      return this.statusMap[status] || '未知'
    },

    // 匹配后端status值设置样式（新增已驳回样式）
    getStatusClass(status) {
      const classMap = {
        0: 'status-pending',  // 待处理（黄色）
        1: 'status-handled',  // 已处理（绿色）
        2: 'status-rejected'  // 已驳回（红色）
      }
      return classMap[status] || 'status-default'
    },

    // 兼容后端LocalDateTime格式的时间格式化
    formatTime(timeStr) {
      if (!timeStr) return ''
      // 处理后端返回的 "2025-10-19T14:20:00" 格式
      const date = new Date(timeStr.replace('T', ' '))
      return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')} ${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`
    },

    // 跳转详情页，传递固定的101
    goDetail(reportId) {
      uni.navigateTo({ 
        url: `/pages/report/detail?id=${reportId}&villageId=101` 
      })
    }
  }
}
</script>

<style scoped>
.history-list-container {
  background-color: #f8f8f8;
  min-height: 100vh;
}
.header-bar {
  background: white;
  padding: 30rpx;
  text-align: center;
  box-shadow: 0 2rpx 8rpx rgba(0,0,0,0.05);
}
.title {
  font-size: 32rpx;
  font-weight: bold;
  color: #333;
}
.filter-bar {
  background: white;
  padding: 20rpx 30rpx;
  margin-bottom: 20rpx;
}
.filter-item {
  display: flex;
  align-items: center;
  font-size: 28rpx;
  color: #333;
}
.arrow {
  margin-left: 10rpx;
  font-size: 24rpx;
  color: #999;
}
.list-container {
  padding: 0 20rpx;
}
.report-item {
  background: white;
  border-radius: 16rpx;
  padding: 30rpx;
  margin-bottom: 20rpx;
  box-shadow: 0 2rpx 8rpx rgba(0,0,0,0.05);
}
.report-title {
  font-size: 30rpx;
  font-weight: bold;
  color: #333;
  margin-bottom: 15rpx;
}
.report-content {
  font-size: 26rpx;
  color: #666;
  margin-bottom: 20rpx;
  line-height: 1.5;
}
.report-info {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.status-tag {
  font-size: 22rpx;
  padding: 6rpx 12rpx;
  border-radius: 12rpx;
  color: white;
}
.status-pending { background-color: #faad14; } /* 待处理-黄色 */
.status-handled { background-color: #52c41a; }  /* 已处理-绿色 */
.status-default { background-color: #999; }    /* 未知-灰色 */
.time {
  font-size: 24rpx;
  color: #999;
}
.empty-tip {
  text-align: center;
  padding: 100rpx 0;
  color: #999;
  font-size: 28rpx;
}
</style>