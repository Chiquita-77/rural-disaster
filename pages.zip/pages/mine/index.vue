<template>
  <view class="mine-container">
    <!-- 未登录状态：密码登录表单 -->
    <view v-if="!isLogin" class="login-section">
      <view class="login-icon">👤</view>
      <view class="login-title">登录后使用完整功能</view>
      <view class="login-form">
        <view class="input-item">
          <text class="label">用户名/手机号</text>
          <input v-model="phone" type="text" placeholder="请输入手机号" class="input" />
        </view>
        <view class="input-item">
          <text class="label">密码</text>
          <input v-model="password" type="password" placeholder="请输入密码" class="input" />
        </view>
        <view class="input-item">
          <text class="label">角色选择</text>
          <picker @change="onRoleChange" :value="roleIndex" :range="roleList" class="picker">
            <view class="picker-text">{{ roleList[roleIndex] }}</view>
          </picker>
        </view>
        
        <button class="login-btn" @click="doLogin">登录</button>
        <button @click="goRegister" class="register-btn">注册账号</button>
        <view class="role-tip">
          <text>登录后自动识别身份：村民/信息员/管理员</text>
        </view>
      </view>
    </view>

    <!-- 已登录状态：个人中心 -->
    <view v-else class="user-section">
      <view class="user-card">
        <view class="avatar">{{ userInfo.username?.substring(0,1) || '用' }}</view>
        <view class="user-info">
          <view class="username">{{ userInfo.username || '未知用户' }}</view>
          <view class="role">{{ getRoleText(userInfo.role) }}</view>
          <view class="village">所属村庄：{{ userInfo.villageName || '未知村庄' }}</view>
        </view>
      </view>

      <view class="func-list">
        <view class="func-item" @click="editUserInfo">
          <text class="func-icon">✏️</text>
          <text class="func-text">修改个人信息</text>
        </view>
        <view class="func-item" @click="viewHistory">
          <text class="func-icon">📜</text>
          <text class="func-text">我的操作记录</text>
        </view>
        <view class="func-item" @click="doLogout" style="color: #ff4d4f;">
          <text class="func-icon">🚪</text>
          <text class="func-text">退出登录</text>
        </view>
      </view>
    </view>
  </view>
</template>

<script>
import { post } from '@/utils/request'
import { setUserInfo, getCurrentUserId } from '@/utils/auth'

export default {
  data() {
    return {
      isLogin: false,
      phone: '',
      password: '',
      roleList: ['村民', '村级信息员', '乡镇管理员'],
      roleIndex: 0,
      roleMap: { 0: 1, 1: 2, 2: 3 }, // 1=村民, 2=信息员, 3=管理员
      userInfo: {}
    }
  },
  onShow() {
    this.checkLoginStatus()
  },
  methods: {
    checkLoginStatus() {
      const userInfo = uni.getStorageSync('userInfo') || {}
      this.isLogin = !!userInfo.userId
      this.userInfo = userInfo
    },

    onRoleChange(e) {
      this.roleIndex = e.detail.value
    },

    // 密码登录逻辑（复用你原来的代码）
    async doLogin() {
      if (!this.phone || !this.password) {
        return uni.showToast({ title: '手机号/密码不能为空', icon: 'none' })
      }

      try {
        const res = await post('/user/login', {
          phone: this.phone,
          password: this.password,
          role: this.roleMap[this.roleIndex]
        })

        if (res.code === 200) {
          setUserInfo(res.data)
          this.userInfo = res.data
          this.isLogin = true
          uni.showToast({ title: '登录成功', icon: 'success' })
          uni.$emit('loginSuccess') // 通知首页/服务页刷新
          setTimeout(() => {
            uni.navigateBack({ delta: 1 }) // 自动返回上一页
          }, 1500)
        } else {
          uni.showToast({ title: res.msg || '登录失败', icon: 'none' })
        }
      } catch (err) {
        console.error('登录异常：', err)
        uni.showToast({ title: '网络异常，请重试', icon: 'none' })
      }
    },

    goRegister() {
      uni.navigateTo({ url: '/pages/auth/register' })
    },

    doLogout() {
      uni.showModal({
        title: '确认退出',
        content: '是否确定退出登录？',
        success: (res) => {
          if (res.confirm) {
            uni.removeStorageSync('userInfo')
            this.isLogin = false
            this.userInfo = {}
            uni.showToast({ title: '退出成功', icon: 'success' })
            uni.$emit('loginSuccess')
          }
        }
      })
    },

    getRoleText(role) {
      const roleMap = {
        1: '村民',
        2: '信息员',
        3: '乡镇管理员'
      }
      return roleMap[role] || '未知身份'
    },

    editUserInfo() {
      uni.navigateTo({ url: '/pages/mine/edit-info' })
    },

    viewHistory() {
      uni.navigateTo({ url: `/pages/mine/history?role=${this.userInfo.role}` })
    }
  }
}
</script>

<style scoped>
.mine-container {
  padding: 20rpx;
  background-color: #f8f8f8;
  min-height: 100vh;
}

/* 未登录样式：密码登录表单 */
.login-section {
  padding: 40rpx;
}
.login-icon {
  font-size: 100rpx;
  text-align: center;
  margin-bottom: 30rpx;
}
.login-title {
  font-size: 32rpx;
  text-align: center;
  color: #333;
  margin-bottom: 40rpx;
}
.login-form {
  background: white;
  padding: 40rpx;
  border-radius: 20rpx;
  box-shadow: 0 4rpx 12rpx rgba(0,0,0,0.05);
}
.input-item {
  margin-bottom: 30rpx;
}
.label {
  display: block;
  font-size: 28rpx;
  color: #333;
  margin-bottom: 10rpx;
}
.input, .picker-text {
  padding: 20rpx;
  border: 1rpx solid #eee;
  border-radius: 12rpx;
  font-size: 28rpx;
  color: #666;
}
.picker {
  border: 1rpx solid #eee;
  border-radius: 12rpx;
}
.picker-text {
  padding: 20rpx;
}
.login-btn {
  width: 100%;
  background: #1890ff;
  color: white;
  padding: 24rpx;
  border-radius: 12rpx;
  font-size: 32rpx;
  margin-top: 20rpx;
}
.register-btn {
  width: 100%;
  background: #52c41a;
  color: white;
  padding: 24rpx;
  border-radius: 12rpx;
  font-size: 32rpx;
  margin-top: 20rpx;
}
.role-tip {
  font-size: 24rpx;
  color: #999;
  text-align: center;
  margin-top: 20rpx;
}

/* 已登录样式：个人中心 */
.user-card {
  background: white;
  border-radius: 16rpx;
  padding: 30rpx;
  display: flex;
  align-items: center;
  margin-bottom: 30rpx;
  box-shadow: 0 2rpx 8rpx rgba(0,0,0,0.05);
}
.avatar {
  width: 100rpx;
  height: 100rpx;
  background: #1890ff;
  color: white;
  border-radius: 50%;
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 40rpx;
  margin-right: 30rpx;
}
.user-info {
  flex: 1;
}
.username {
  font-size: 32rpx;
  font-weight: bold;
  color: #333;
  margin-bottom: 10rpx;
}
.role {
  font-size: 28rpx;
  color: #1890ff;
  margin-bottom: 10rpx;
}
.village {
  font-size: 26rpx;
  color: #999;
}
.func-list {
  background: white;
  border-radius: 16rpx;
  box-shadow: 0 2rpx 8rpx rgba(0,0,0,0.05);
}
.func-item {
  display: flex;
  align-items: center;
  padding: 25rpx 30rpx;
  border-bottom: 1rpx solid #f0f0f0;
}
.func-item:last-child {
  border-bottom: none;
}
.func-icon {
  font-size: 32rpx;
  margin-right: 20rpx;
}
.func-text {
  font-size: 28rpx;
  color: #333;
}
</style>