<template>
  <view class="history-container">
    <view class="page-title">我的操作记录</view>

    <!-- 村民：显示灾情上报处理状态 -->
    <view v-if="role === 1" class="report-list">
      <view v-if="loading" class="loading">加载中...</view>
      <view v-else-if="reportList.length === 0" class="empty">暂无上报记录</view>
      <view v-else class="report-item" v-for="item in reportList" :key="item.reportId">
        <view class="report-title">{{ item.title }}</view>
        <view class="report-time">上报时间：{{ formatTime(item.createTime) }}</view>
        <view class="status-row">
          <text class="status-label">处理状态：</text>
          <text :class="['status-tag', getStatusClass(item.status)]">
            {{ getStatusText(item.status) }}
          </text>
        </view>
        <view v-if="item.handleResult" class="handle-result">
          处理结果：{{ item.handleResult }}
        </view>
      </view>
    </view>

    <!-- 信息员：显示风险提示审核记录 -->
    <view v-else-if="role === 2" class="tip-list">
      <view v-if="loading" class="loading">加载中...</view>
      <view v-else-if="tipList.length === 0" class="empty">暂无发布的风险提示记录</view>
      <view v-else class="tip-item" v-for="item in tipList" :key="item.tipId">
        <view class="tip-title">{{ item.title }}</view>
        <view class="tip-time">发布时间：{{ formatTime(item.createTime) }}</view>
        <view class="status-row">
          <text class="status-label">审核状态：</text>
          <text :class="['status-tag', getTipStatusClass(item.reviewStatus)]">
            {{ getTipStatusText(item.reviewStatus) }}
          </text>
        </view>
        <view v-if="item.reviewComment" class="review-comment">
          审核意见：{{ item.reviewComment }}
        </view>
      </view>
    </view>

    <!-- 管理员：预留 -->
    <view v-else class="empty">管理员操作记录功能开发中...</view>
  </view>
</template>

<script>
import { get } from '@/utils/request'
import { getCurrentUserId } from '@/utils/auth'

export default {
  data() {
    return {
      role: 1,
      loading: false,
      reportList: [],
      tipList: []
    }
  },
  onLoad(options) {
    this.role = parseInt(options.role) || 1
    this.loadMyHistory()
  },
  methods: {
    async loadMyHistory() {
      this.loading = true
      try {
        // 村民：查灾情上报记录
        if (this.role === 1) {
          const res = await get('/report/my', { villageId: 101 })
          if (res.code === 200) {
            this.reportList = res.data || []
          } else {
            uni.showToast({ title: res.msg || '加载失败', icon: 'none' })
          }
        } 
        // 信息员：查风险提示记录
        else if (this.role === 2) {
          const res = await get('/tip/list', { villageId: 101 })
          if (res.code === 200) {
            this.tipList = res.data || []
          } else {
            uni.showToast({ title: res.msg || '加载失败', icon: 'none' })
          }
        }
      } catch (err) {
        console.error('加载操作记录失败：', err)
        uni.showToast({ title: '网络异常', icon: 'none' })
      } finally {
        this.loading = false
      }
    },

    formatTime(timeStr) {
      if (!timeStr) return '-'
      return timeStr.replace('T', ' ').substring(0, 19)
    },

    // 村民-处理状态文本（兼容 undefined）
    getStatusText(status) {
      const map = {
        0: '待核实',
        1: '已核实',
        2: '已驳回'
      }
      // 核心修复：先判断 status 是否存在，避免 undefined 报错
      return status !== undefined ? map[status] || '未知' : '未知'
    },

    // 村民-处理状态样式类
    getStatusClass(status) {
      const map = {
        0: 'status-pending',
        1: 'status-done',
        2: 'status-rejected'
      }
      return status !== undefined ? map[status] || 'status-default' : 'status-default'
    },

    // 信息员-审核状态文本（兼容 undefined）
    getTipStatusText(status) {
      const map = {
        0: '待审核',
        1: '已通过',
        '-1': '已驳回'
      }
      return status !== undefined ? map[status] || '未知' : '未知'
    },

    // 信息员-审核状态样式类
    getTipStatusClass(status) {
      const map = {
        0: 'status-pending',
        1: 'status-done',
        '-1': 'status-rejected'
      }
      return status !== undefined ? map[status] || 'status-default' : 'status-default'
    }
  }
}
</script>

<style scoped>
.history-container {
  padding: 20rpx;
  background-color: #f8f8f8;
  min-height: 100vh;
}
.page-title {
  font-size: 36rpx;
  font-weight: bold;
  color: #333;
  margin-bottom: 30rpx;
  text-align: center;
}
.loading, .empty {
  text-align: center;
  color: #999;
  padding: 60rpx 0;
}
.report-list, .tip-list {
  background: white;
  border-radius: 16rpx;
  padding: 20rpx;
  box-shadow: 0 2rpx 8rpx rgba(0,0,0,0.05);
}
.report-item, .tip-item {
  padding: 25rpx 0;
  border-bottom: 1rpx solid #f0f0f0;
}
.report-item:last-child, .tip-item:last-child {
  border-bottom: none;
}
.report-title, .tip-title {
  font-size: 30rpx;
  color: #333;
  font-weight: 500;
  margin-bottom: 10rpx;
}
.report-time, .tip-time {
  font-size: 24rpx;
  color: #999;
  margin-bottom: 10rpx;
}
.status-row {
  display: flex;
  align-items: center;
  margin-bottom: 10rpx;
}
.status-label {
  font-size: 26rpx;
  color: #666;
}
.status-tag {
  font-size: 24rpx;
  padding: 4rpx 12rpx;
  border-radius: 8rpx;
}
.status-pending {
  background: #fff7e6;
  color: #fa8c16;
}
.status-done {
  background: #f6ffed;
  color: #52c41a;
}
.status-rejected {
  background: #fff2f0;
  color: #ff4d4f;
}
.status-default {
  background: #f5f5f5;
  color: #999;
}
.handle-result, .review-comment {
  font-size: 24rpx;
  color: #666;
  line-height: 1.5;
}
</style>