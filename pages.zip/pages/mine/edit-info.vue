<template>
  <view class="edit-container">
    <text class="title">修改个人信息</text>

    <view class="form">
      <view class="input-item">
        <text class="label">用户名</text>
        <input v-model="form.username" type="text" placeholder="请输入用户名" class="input" />
      </view>
      <view class="input-item">
        <text class="label">手机号</text>
        <input v-model="form.phone" type="number" disabled placeholder="手机号不可修改" class="input disabled" />
      </view>
      <view class="input-item">
        <text class="label">新密码（不修改则留空）</text>
        <input v-model="form.newPassword" type="password" placeholder="请输入6位以上新密码" class="input" />
      </view>
      <view class="input-item">
        <text class="label">确认新密码</text>
        <input v-model="form.confirmNewPassword" type="password" placeholder="请再次输入新密码" class="input" />
      </view>

      <button @click="handleUpdate" class="btn update-btn">保存修改</button>
      <button @click="goBack" class="btn back-btn">返回</button>
    </view>
  </view>
</template>

<script>
import { post } from '@/utils/request'
import { setUserInfo, getUserInfo } from '@/utils/auth'

export default {
  data() {
    return {
      form: {
        userId: null,
        username: '',
        phone: '',
        newPassword: '',
        confirmNewPassword: ''
      }
    }
  },
  onLoad() {
    // 页面加载时回显当前用户信息
    const userInfo = getUserInfo()
    if (!userInfo?.userId) {
      uni.showToast({ title: '请先登录', icon: 'none' })
      setTimeout(() => {
        uni.switchTab({ url: '/pages/mine/index' })
      }, 1500)
      return
    }
    this.form.userId = userInfo.userId
    this.form.username = userInfo.username
    this.form.phone = userInfo.phone
  },
  methods: {
    async handleUpdate() {
      // 前端校验
      if (!this.form.username) {
        return uni.showToast({ title: '用户名不能为空', icon: 'none' })
      }
      if (this.form.newPassword && this.form.newPassword.length < 6) {
        return uni.showToast({ title: '新密码长度不能少于6位', icon: 'none' })
      }
      if (this.form.newPassword && this.form.newPassword !== this.form.confirmNewPassword) {
        return uni.showToast({ title: '两次输入的新密码不一致', icon: 'none' })
      }

      try {
        // 调用后端更新接口（接口路径按你后端实际配置）
        const res = await post('/user/update', {
          userId: this.form.userId,
          username: this.form.username,
          // 只有填写了新密码才传password字段
          ...(this.form.newPassword ? { password: this.form.newPassword } : {})
        })

        if (res.code === 200) {
          // 更新缓存中的用户信息
          const oldUserInfo = getUserInfo()
          const newUserInfo = {
            ...oldUserInfo,
            username: this.form.username
          }
          setUserInfo(newUserInfo)

          uni.showToast({ title: '修改成功', icon: 'success' })
          // 通知全局刷新
          uni.$emit('loginSuccess')
          // 返回「我的」页面
          setTimeout(() => {
            uni.navigateBack()
          }, 1500)
        } else {
          uni.showToast({ title: res.msg || '修改失败', icon: 'none' })
        }
      } catch (err) {
        console.error('修改异常：', err)
        uni.showToast({ title: '网络异常，请重试', icon: 'none' })
      }
    },
    goBack() {
      uni.navigateBack()
    }
  }
}
</script>

<style scoped>
.edit-container {
  padding: 60rpx 40rpx;
  background-color: #f8f8f8;
  min-height: 100vh;
}
.title {
  display: block;
  font-size: 48rpx;
  text-align: center;
  margin-bottom: 60rpx;
  color: #1890ff;
  font-weight: bold;
}
.form {
  background: white;
  padding: 40rpx;
  border-radius: 20rpx;
  box-shadow: 0 4rpx 12rpx rgba(0,0,0,0.05);
}
.input-item {
  margin-bottom: 30rpx;
}
.label {
  display: block;
  font-size: 28rpx;
  color: #333;
  margin-bottom: 10rpx;
}
.input {
  padding: 20rpx;
  border: 1rpx solid #eee;
  border-radius: 12rpx;
  font-size: 28rpx;
  color: #666;
}
.input.disabled {
  background: #f5f5f5;
  color: #999;
}
.btn {
  width: 100%;
  padding: 24rpx;
  border-radius: 12rpx;
  color: white;
  font-size: 32rpx;
  margin-top: 20rpx;
}
.update-btn {
  background: #1890ff;
}
.back-btn {
  background: #999;
}
</style>