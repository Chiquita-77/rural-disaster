<template>
  <view class="admin-layout">
    <!-- 左侧菜单：宽度已加宽，文字能完整显示 -->
    <view class="sidebar">
      <view class="sidebar-title">乡镇灾害管理后台</view>
      <view 
        class="menu-item" 
        :class="{ active: currentPage === 'review' }"
        @click="goPage('review')"
      >
        ⚠️ 风险提示审核
      </view>
      <view 
        class="menu-item" 
        :class="{ active: currentPage === 'users' }"
        @click="goPage('users')"
      >
        👥 用户管理
      </view>
      <view 
        class="menu-item" 
        :class="{ active: currentPage === 'disaster-type' }"
        @click="goPage('disaster-type')"
      >
        📊 灾害类型管理
      </view>
      <view 
        class="menu-item" 
        :class="{ active: currentPage === 'warning-notice' }"
        @click="goPage('warning-notice')"
      >
        🚨 灾害预警通知管理
      </view>
      <view 
        class="menu-item" 
        :class="{ active: currentPage === 'reports' }"
        @click="goPage('reports')"
      >
        📝 灾情上报管理
      </view>
      <view 
        class="menu-item" 
        :class="{ active: currentPage === 'support' }"
        @click="goPage('support')"
      >
        🤝 支援申请管理
      </view>
      <view 
        class="menu-item" 
        :class="{ active: currentPage === 'guides' }"
        @click="goPage('guides')"
      >
        📚 防灾指南管理
      </view>
      <view 
        class="menu-item" 
        :class="{ active: currentPage === 'emergency' }"
        @click="goPage('emergency')"
      >
        📢 应急指令管理
      </view>
      <!-- 新增：灾情与预警统计 -->
      <view 
        class="menu-item" 
        :class="{ active: currentPage === 'statistics' }"
        @click="goPage('statistics')"
      >
        📈 灾情与预警统计
      </view>
    </view>
    
    <!-- 右侧内容区 -->
    <view class="content">
      <view v-if="loading" class="loading-container">
        <text class="loading-text">加载中...</text>
      </view>
      
      <view v-else class="content-card">
        <tip-review v-if="currentPage === 'review'" />
        <user-manage v-if="currentPage === 'users'" />
        <disaster-type v-if="currentPage === 'disaster-type'" ref="disasterTypeRef"/>
        <warning-notice v-if="currentPage === 'warning-notice'" ref="warningNoticeRef" />
        <disaster-manage v-if="currentPage === 'reports'" />
        <support-apply v-if="currentPage === 'support'" />
        <guide-manage v-if="currentPage === 'guides'" ref="guideManageRef"/>
        <emergency-order v-if="currentPage === 'emergency'" />
        <!-- 新增：统计组件 -->
        <statistics-dashboard v-if="currentPage === 'statistics'" />
        <view v-if="!['review','users','disaster-type','warning-notice','reports','support','guides','emergency','statistics'].includes(currentPage)" class="empty-container">
          <text class="empty-text">请选择左侧菜单进入对应功能模块</text>
        </view>
      </view>
    </view>
  </view>
</template>

<script>
import TipReview from './tip-review.vue'
import UserManage from './user-manage.vue'
import DisasterType from './disaster-type.vue'
import WarningNotice from './warning-notice.vue'
import DisasterManage from './disaster-manage.vue'
import SupportApply from './support-apply.vue'
import GuideManage from './guide-manage.vue'
import EmergencyOrder from './emergency-order.vue'
import StatisticsDashboard from './statistics-dashboard.vue'

export default {
  components: {
    TipReview,
    UserManage,
    DisasterType,
    WarningNotice,
    DisasterManage,
    SupportApply,
    GuideManage,
    EmergencyOrder,
    StatisticsDashboard
  },
  data() {
    return {
      currentPage: 'review',
      loading: false
    }
  },
  methods: {
    goPage(page) {
      if (this.currentPage === page) return;
      
      this.loading = true;
      setTimeout(() => {
        this.currentPage = page;
        this.loading = false;

        // 自动加载逻辑（保留原有）
        const pageActionMap = {
          'disaster-type': { ref: 'disasterTypeRef', method: 'getDisasterTypeList' },
          'warning-notice': { ref: 'warningNoticeRef', method: ['getWarningList', 'getDisasterTypeList'] },
          'guides': { ref: 'guideManageRef', method: 'getGuideList' }
        };

        const action = pageActionMap[page];
        if (action) {
          this.$nextTick(() => {
            const component = this.$refs[action.ref];
            if (component) {
              if (Array.isArray(action.method)) {
                action.method.forEach(method => component[method]());
              } else {
                component[action.method]();
              }
            }
          });
        }
      }, 300);
    },
    getPageName(page) {
      const pageMap = {
        review: '风险提示审核',
        users: '用户管理',
        'disaster-type': '灾害类型管理',
        'warning-notice': '灾害预警通知管理',
        reports: '灾情上报管理',
        support: '支援申请管理',
        guides: '防灾指南管理',
        emergency: '应急指令管理',
        statistics: '灾情与预警统计'
      };
      return pageMap[page] || '功能模块';
    }
  },
  onShow() {
    if (this.currentPage) {
      this.loading = true;
      setTimeout(() => {
        this.loading = false;
      }, 200);
    }
  }
};
</script>

<style scoped>
/* 整体布局：flex 占满屏幕 */
.admin-layout {
  display: flex;
  height: 100vh;
  font-family: -apple-system, BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", Arial, sans-serif;
  background-color: #f5f7fa; /* 高级浅灰背景 */
}

/* 左侧菜单：重点加宽 + 高级深色风格 */
.sidebar {
  width: 380rpx; /* 文字能完整放下 */
  background: linear-gradient(180deg, #001529 0%, #002c55 100%); /* 深蓝渐变 */
  color: #fff;
  padding-top: 40rpx;
  box-shadow: 2rpx 0 16rpx rgba(0, 0, 0, 0.1);
  display: flex;
  flex-direction: column;
}

.sidebar-title {
  font-size: 36rpx;
  font-weight: 600;
  text-align: center;
  padding: 30rpx 20rpx;
  margin-bottom: 40rpx;
  color: #fff;
  letter-spacing: 2rpx;
}

/* 菜单项：高级圆角 +  hover 动效 */
.menu-item {
  padding: 28rpx 30rpx;
  font-size: 28rpx;
  cursor: pointer;
  transition: all 0.3s ease;
  border-radius: 8rpx 0 0 8rpx; /* 贴合右侧卡片的圆角 */
  margin-bottom: 10rpx;
}

.menu-item.active {
  background-color: #1890ff; /* 蓝色激活态 */
  font-weight: 500;
  box-shadow: inset 0 0 8rpx rgba(0, 0, 0, 0.1);
}

.menu-item:not(.active):hover {
  background-color: rgba(255, 255, 255, 0.1); /*  hover 半透明 */
  padding-left: 35rpx; /* 轻微右移动效 */
}

/* 右侧内容区：加 padding，避免贴边 */
.content {
  flex: 1;
  padding: 30rpx;
  overflow-y: auto;
}

/* 内容卡片：白色背景 + 大圆角 + 大阴影（高级感） */
.content-card {
  background: #ffffff;
  border-radius: 20rpx;
  box-shadow: 0 8rpx 24rpx rgba(0, 0, 0, 0.08);
  min-height: calc(100vh - 60rpx);
  padding: 20rpx;
}

/* 加载样式 */
.loading-container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100%;
}

.loading-text {
  font-size: 32rpx;
  color: #666;
  padding: 40rpx;
  background: rgba(255, 255, 255, 0.8);
  border-radius: 12rpx;
  box-shadow: 0 4rpx 12rpx rgba(0, 0, 0, 0.05);
}

/* 空状态 */
.empty-container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100%;
  color: #999;
  font-size: 30rpx;
  padding: 100rpx;
}
</style>