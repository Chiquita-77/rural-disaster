<template>
  <view class="order-container">
    <view class="header">应急指令管理</view>

    <!-- 发布指令按钮 -->
    <button class="publish-btn" @click="openPublishModal">📢 发布新指令</button>

    <!-- 筛选栏 -->
    <view class="filter">
      <view class="filter-item" @click="changeStatus(null)">全部</view>
      <view class="filter-item" @click="changeStatus(1)">生效中</view>
      <view class="filter-item" @click="changeStatus(0)">未生效</view>
      <view class="filter-item" @click="changeStatus(2)">已失效</view>
    </view>

    <!-- 加载中 -->
    <view v-if="loading" class="loading">加载中...</view>

    <!-- 空数据 -->
    <view v-else-if="orderList.length === 0" class="empty">暂无应急指令</view>

    <!-- 指令列表 -->
    <view v-else class="order-list">
      <view v-for="item in orderList" :key="item.orderId" class="order-card">
        <view class="card-header">
          <text class="title">{{ item.title }}</text>
          <text class="status" :class="getStatusClass(item.status)">
            {{ getStatusText(item.status) }}
          </text>
        </view>
        <text class="content">{{ item.content }}</text>
        <view class="info">
          <text>发布人：{{ item.publisherName }}</text>
          <text>发布时间：{{ formatTime(item.publishTime) }}</text>
          <text>适用范围：{{ item.scopeType === '0' ? '全村' : '指定村庄：' + item.villageIds }}</text>
        </view>
        <!-- 新增：接收统计行 -->
        <view class="stats-row">
          <text class="stats-item">总接收：{{ item.totalReceive || 0 }}</text>
          <text class="stats-item read">已读：{{ item.readCount || 0 }}</text>
          <text class="stats-item unread" @click="viewUnreadDetail(item)">
            未读：{{ item.unreadCount || 0 }} 👈
          </text>
        </view>
        <view class="actions">
          <button v-if="item.status === 0" @click="updateStatus(item.orderId, 1)" class="btn enable">启用</button>
          <button v-if="item.status === 1" @click="updateStatus(item.orderId, 2)" class="btn disable">失效</button>
          <button @click="viewDetail(item)" class="btn detail">详情</button>
        </view>
      </view>
    </view>

    <!-- 发布指令弹窗 -->
    <uni-popup ref="publishModal" type="center" background-color="rgba(0,0,0,0.5)">
      <view class="modal-content">
        <view class="modal-header">
          <text class="modal-title">发布应急指令</text>
          <text class="close" @click="closePublishModal">×</text>
        </view>
        <view class="form">
          <view class="form-item">
            <text class="label">指令标题 *</text>
            <input v-model="form.title" placeholder="请输入指令标题" class="input" />
          </view>
          <view class="form-item">
            <text class="label">指令内容 *</text>
            <textarea v-model="form.content" placeholder="请输入指令详细内容" class="textarea" />
          </view>
          <view class="form-item">
            <text class="label">适用范围 *</text>
            <radio-group v-model="form.scopeType" class="radio-group">
              <label class="radio">
                <radio value="0" /> 全村
              </label>
              <label class="radio">
                <radio value="1" /> 指定村庄
              </label>
            </radio-group>
          </view>
          <view class="form-item" v-if="form.scopeType === '1'">
            <text class="label">村庄ID（逗号分隔）*</text>
            <input v-model="form.villageIds" placeholder="例如：1,2,3" class="input" />
          </view>
          <view class="form-item">
            <text class="label">发布人名称 *</text>
            <input v-model="form.publisherName" placeholder="请输入你的姓名" class="input" />
            <input v-model="form.publisherId" type="hidden" value="1" /> <!-- 实际从登录态取 -->
          </view>
        </view>
        <view class="modal-footer">
          <button @click="closePublishModal" class="btn cancel">取消</button>
          <button @click="submitPublish" class="btn confirm">发布</button>
        </view>
      </view>
    </uni-popup>

    <!-- 指令详情弹窗 -->
    <uni-popup ref="detailModal" type="center" background-color="rgba(0,0,0,0.5)">
      <view class="detail-content">
        <view class="detail-header">
          <text class="detail-title">{{ currentOrder.title }}</text>
          <text class="close" @click="closeDetailModal">×</text>
        </view>
        <view class="detail-body">
          <text class="detail-label">发布人：</text>
          <text class="detail-value">{{ currentOrder.publisherName }}</text>
          <text class="detail-label">发布时间：</text>
          <text class="detail-value">{{ formatTime(currentOrder.publishTime) }}</text>
          <text class="detail-label">适用范围：</text>
          <text class="detail-value">{{ currentOrder.scopeType === '0' ? '全村' : '指定村庄：' + currentOrder.villageIds }}</text>
          <text class="detail-label">状态：</text>
          <text class="detail-value" :class="getStatusClass(currentOrder.status)">
            {{ getStatusText(currentOrder.status) }}
          </text>
          <text class="detail-label">指令内容：</text>
          <text class="detail-content-text">{{ currentOrder.content }}</text>
        </view>
      </view>
    </uni-popup>

    <!-- 新增：未读详情弹窗 -->
    <uni-popup ref="unreadModal" type="center" background-color="rgba(0,0,0,0.5)">
      <view class="unread-content">
        <view class="unread-header">
          <text class="unread-title">未读详情</text>
          <text class="close" @click="closeUnreadModal">×</text>
        </view>
        <view class="unread-filter">
          <text class="filter-label">按村庄筛选：</text>
          <input v-model="unreadVillageId" placeholder="输入村庄ID" class="filter-input" />
          <button @click="loadUnreadDetail" class="filter-btn">查询</button>
        </view>
        <!-- 未读列表空状态 -->
        <view v-if="unreadList.length === 0 && !loading" class="empty-unread">暂无未读用户</view>
        <!-- 未读列表 -->
        <view v-else class="unread-list">
          <view v-for="item in unreadList" :key="item.recordId" class="unread-item">
            <text class="unread-user">用户ID：{{ item.receive_user_id }}</text>
            <text class="unread-village">村庄：{{ item.village_name || '未知' }}</text>
            <text class="unread-status">未读</text>
          </view>
        </view>
        <view class="unread-footer">
          <button @click="closeUnreadModal" class="btn cancel">关闭</button>
          <button @click="pushReminder" class="btn reminder">二次推送提醒</button>
        </view>
      </view>
    </uni-popup>
  </view>
</template>

<script>
import { get, post } from '@/utils/request'
import uniPopup from '@dcloudio/uni-ui/lib/uni-popup/uni-popup.vue'

export default {
  components: { uniPopup },
  data() {
    return {
      loading: false,
      orderList: [],
      currentStatus: null, // 筛选状态
      // 发布表单
      form: {
        title: '',
        content: '',
        scopeType: '0', // 0=全村 1=指定村庄
        villageIds: '',
        publisherId: 1, // 管理员ID，实际从登录态取
        publisherName: ''
      },
      currentOrder: {}, // 当前查看的指令
      // 新增：未读详情相关
      currentOrderId: null,
      unreadVillageId: '',
      unreadList: []
    }
  },
  async mounted() {
    await this.loadOrderList()
  },
  methods: {
    // 加载指令列表
    async loadOrderList() {
      this.loading = true
      try {
        const params = {
          pageNum: 1,
          pageSize: 100, // 管理员端默认查全部
          status: this.currentStatus
        }
        const res = await get('/admin/emergency/order/list', params)
        this.orderList = res.data.records || []
        // 加载接收统计数据
        await this.loadReceiveStats()
      } catch (err) {
        console.error('加载指令列表失败：', err)
        uni.showToast({ title: '加载失败', icon: 'none' })
      } finally {
        this.loading = false
      }
    },
    // 新增：加载接收统计数据
    async loadReceiveStats() {
      try {
        const res = await get('/admin/emergency/order/receive/stats')
        if (res.code === 200) {
          // 把统计数据合并到orderList中
          const statsMap = {}
          res.data.forEach(stat => {
            statsMap[stat.order_id] = stat
          })
          this.orderList = this.orderList.map(item => {
            const stat = statsMap[item.orderId] || {}
            return {
              ...item,
              totalReceive: stat.total_receive || 0,
              readCount: stat.read_count || 0,
              unreadCount: stat.unread_count || 0
            }
          })
        }
      } catch (err) {
        console.error('加载接收统计失败：', err)
      }
    },
    // 切换筛选状态
    changeStatus(status) {
      this.currentStatus = status
      this.loadOrderList()
    },
    // 格式化时间
    formatTime(timeStr) {
      if (!timeStr) return '未知时间'
      return timeStr.replace('T', ' ').substring(0, 16)
    },
    // 获取状态文本
    getStatusText(status) {
      const map = {
        0: '未生效',
        1: '生效中',
        2: '已失效'
      }
      return map[status] || '未知'
    },
    // 获取状态样式类
    getStatusClass(status) {
      const map = {
        0: 'status-pending',
        1: 'status-active',
        2: 'status-inactive'
      }
      return map[status] || ''
    },
    // 打开发布弹窗
    openPublishModal() {
      // 重置表单
      this.form = {
        title: '',
        content: '',
        scopeType: '0',
        villageIds: '',
        publisherId: 1,
        publisherName: ''
      }
      this.$refs.publishModal.open()
    },
    // 关闭发布弹窗
    closePublishModal() {
      this.$refs.publishModal.close()
    },
    // 提交发布
    async submitPublish() {
      // 表单校验
      if (!this.form.title.trim()) {
        return uni.showToast({ title: '请输入指令标题', icon: 'none' })
      }
      if (!this.form.content.trim()) {
        return uni.showToast({ title: '请输入指令内容', icon: 'none' })
      }
      if (!this.form.publisherName.trim()) {
        return uni.showToast({ title: '请输入发布人名称', icon: 'none' })
      }
      if (this.form.scopeType === '1' && !this.form.villageIds.trim()) {
        return uni.showToast({ title: '请输入指定村庄ID', icon: 'none' })
      }

      try {
        uni.showLoading({ title: '发布中...' })
        const res = await post('/admin/emergency/order/publish', this.form)
        if (res.code === 200) {
          uni.showToast({ title: '发布成功', icon: 'success' })
          this.closePublishModal()
          this.loadOrderList() // 刷新列表
        } else {
          uni.showToast({ title: res.msg || '发布失败', icon: 'none' })
        }
      } catch (err) {
        console.error('发布指令失败：', err)
        uni.showToast({ title: '发布失败', icon: 'none' })
      } finally {
        uni.hideLoading()
      }
    },
    // 更新指令状态
    async updateStatus(orderId, status) {
      const tip = status === 1 ? '确定启用该指令？' : '确定标记为失效？'
      uni.showModal({
        title: '确认操作',
        content: tip,
        success: async (res) => {
          if (res.confirm) {
            try {
              uni.showLoading({ title: '处理中...' })
              const res = await post('/admin/emergency/order/status', {
                orderId,
                status
              })
              if (res.code === 200) {
                uni.showToast({ title: '操作成功', icon: 'success' })
                this.loadOrderList()
              } else {
                uni.showToast({ title: res.msg || '操作失败', icon: 'none' })
              }
            } catch (err) {
              console.error('更新状态失败：', err)
              uni.showToast({ title: '操作失败', icon: 'none' })
            } finally {
              uni.hideLoading()
            }
          }
        }
      })
    },
    // 查看详情
    viewDetail(order) {
      this.currentOrder = order
      this.$refs.detailModal.open()
    },
    // 关闭详情弹窗
    closeDetailModal() {
      this.$refs.detailModal.close()
    },
    // 新增：查看未读详情
    viewUnreadDetail(order) {
      this.currentOrderId = order.orderId
      this.unreadVillageId = ''
      this.unreadList = []
      this.$refs.unreadModal.open()
      this.loadUnreadDetail()
    },
    // 新增：加载未读详情
    async loadUnreadDetail() {
      this.loading = true
      try {
        const params = {
          orderId: this.currentOrderId,
          villageId: this.unreadVillageId || null
        }
        const res = await get('/admin/emergency/order/unread/detail', params)
        if (res.code === 200) {
          this.unreadList = res.data
        } else {
          uni.showToast({ title: res.msg || '加载未读详情失败', icon: 'none' })
        }
      } catch (err) {
        console.error('加载未读详情失败：', err)
        uni.showToast({ title: '加载失败', icon: 'none' })
      } finally {
        this.loading = false
      }
    },
    // 新增：二次推送提醒
    pushReminder() {
      uni.showModal({
        title: '二次推送',
        content: '确定对未读用户发送短信提醒？',
        success: (res) => {
          if (res.confirm) {
            // 这里可对接实际短信接口，当前模拟
            uni.showToast({ title: '提醒已发送', icon: 'success' })
            this.closeUnreadModal()
          }
        }
      })
    },
    // 新增：关闭未读弹窗
    closeUnreadModal() {
      this.$refs.unreadModal.close()
    }
  }
}
</script>

<style scoped>
.order-container {
  padding: 20rpx;
  background: #f5f5f5;
  min-height: 100vh;
}
.header {
  font-size: 36rpx;
  font-weight: bold;
  margin-bottom: 20rpx;
}
.publish-btn {
  background: #1890ff;
  color: white;
  border: none;
  padding: 16rpx 32rpx;
  border-radius: 8rpx;
  font-size: 28rpx;
  margin-bottom: 20rpx;
}
.filter {
  display: flex;
  gap: 10rpx;
  margin-bottom: 20rpx;
}
.filter-item {
  padding: 10rpx 20rpx;
  background: white;
  border-radius: 8rpx;
  font-size: 26rpx;
}
.loading, .empty {
  text-align: center;
  padding: 100rpx 0;
  color: #999;
}
.order-list {
  display: flex;
  flex-direction: column;
  gap: 20rpx;
}
.order-card {
  background: white;
  padding: 30rpx;
  border-radius: 16rpx;
  box-shadow: 0 2rpx 8rpx rgba(0,0,0,0.05);
}
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10rpx;
}
.title {
  font-size: 32rpx;
  font-weight: bold;
}
.status {
  padding: 4rpx 12rpx;
  border-radius: 4rpx;
  font-size: 24rpx;
}
.status-pending {
  background: #fff7e6;
  color: #faad14;
}
.status-active {
  background: #e6fffb;
  color: #13c2c2;
}
.status-inactive {
  background: #f5f5f5;
  color: #8c8c8c;
}
.content {
  font-size: 28rpx;
  color: #666;
  line-height: 1.6;
  margin: 10rpx 0;
}
.info {
  display: flex;
  flex-wrap: wrap;
  gap: 20rpx;
  font-size: 24rpx;
  color: #999;
  margin: 10rpx 0;
}
/* 新增：统计行样式 */
.stats-row {
  display: flex;
  gap: 20rpx;
  padding: 10rpx 0;
  margin: 10rpx 0;
  border-top: 1rpx solid #f0f0f0;
  border-bottom: 1rpx solid #f0f0f0;
}
.stats-item {
  font-size: 26rpx;
}
.stats-item.read {
  color: #52c41a;
}
.stats-item.unread {
  color: #ff4d4f;
  font-weight: bold;
}
.actions {
  display: flex;
  gap: 10rpx;
  margin-top: 20rpx;
}
.btn {
  flex: 1;
  padding: 10rpx 0;
  border: none;
  border-radius: 8rpx;
  font-size: 26rpx;
}
.enable {
  background: #52c41a;
  color: white;
}
.disable {
  background: #ff4d4f;
  color: white;
}
.detail {
  background: #1890ff;
  color: white;
}

/* 发布弹窗样式 */
.modal-content {
  width: 700rpx;
  background: white;
  border-radius: 16rpx;
  padding: 30rpx;
}
.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20rpx;
}
.modal-title {
  font-size: 32rpx;
  font-weight: bold;
}
.close {
  font-size: 36rpx;
  color: #999;
}
.form {
  margin-bottom: 30rpx;
}
.form-item {
  margin-bottom: 20rpx;
}
.label {
  display: block;
  font-size: 28rpx;
  margin-bottom: 8rpx;
  color: #333;
}
.input {
  width: 100%;
  padding: 12rpx;
  border: 1rpx solid #ddd;
  border-radius: 8rpx;
  font-size: 28rpx;
}
.textarea {
  width: 100%;
  height: 200rpx;
  padding: 12rpx;
  border: 1rpx solid #ddd;
  border-radius: 8rpx;
  font-size: 28rpx;
  resize: none;
}
.radio-group {
  display: flex;
  gap: 30rpx;
}
.radio {
  font-size: 28rpx;
}
.modal-footer {
  display: flex;
  gap: 20rpx;
}
.cancel {
  flex: 1;
  background: #f5f5f5;
  color: #333;
}
.confirm {
  flex: 1;
  background: #1890ff;
  color: white;
}

/* 详情弹窗样式 */
.detail-content {
  width: 700rpx;
  background: white;
  border-radius: 16rpx;
  padding: 30rpx;
}
.detail-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 30rpx;
}
.detail-title {
  font-size: 32rpx;
  font-weight: bold;
}
.detail-body {
  display: flex;
  flex-direction: column;
  gap: 20rpx;
}
.detail-label {
  font-size: 28rpx;
  font-weight: bold;
  color: #333;
}
.detail-value {
  font-size: 28rpx;
  color: #666;
  margin-left: 10rpx;
}
.detail-content-text {
  font-size: 28rpx;
  color: #666;
  line-height: 1.6;
  margin-top: 10rpx;
}

/* 新增：未读详情弹窗样式 */
.unread-content {
  width: 700rpx;
  background: white;
  border-radius: 16rpx;
  padding: 30rpx;
  max-height: 80vh;
  overflow-y: auto;
}
.unread-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20rpx;
}
.unread-title {
  font-size: 32rpx;
  font-weight: bold;
}
.unread-filter {
  display: flex;
  align-items: center;
  gap: 10rpx;
  margin-bottom: 20rpx;
  padding-bottom: 10rpx;
  border-bottom: 1rpx solid #f0f0f0;
}
.filter-label {
  font-size: 26rpx;
  color: #333;
}
.filter-input {
  flex: 1;
  padding: 8rpx 12rpx;
  border: 1rpx solid #ddd;
  border-radius: 8rpx;
  font-size: 26rpx;
}
.filter-btn {
  padding: 8rpx 20rpx;
  background: #1890ff;
  color: white;
  border: none;
  border-radius: 8rpx;
  font-size: 24rpx;
}
.empty-unread {
  text-align: center;
  padding: 50rpx 0;
  color: #999;
  font-size: 26rpx;
}
.unread-list {
  display: flex;
  flex-direction: column;
  gap: 15rpx;
  margin-bottom: 20rpx;
}
.unread-item {
  padding: 15rpx;
  background: #f8f8f8;
  border-radius: 8rpx;
  display: flex;
  flex-direction: column;
  gap: 5rpx;
}
.unread-user {
  font-size: 26rpx;
  color: #333;
}
.unread-village {
  font-size: 24rpx;
  color: #666;
}
.unread-status {
  font-size: 22rpx;
  color: #ff4d4f;
  margin-top: 5rpx;
}
.unread-footer {
  display: flex;
  gap: 20rpx;
  margin-top: 10rpx;
}
.reminder {
  flex: 1;
  background: #faad14;
  color: white;
}
</style>