<template>
  <view class="manage-container">
    <view class="header">灾情上报管理</view>
    
    <!-- 加载中 -->
    <view v-if="loading" class="loading">
      <text>加载灾情数据中...</text>
    </view>

    <!-- 空数据 -->
    <view v-else-if="reportList.length === 0" class="empty">
      <text>暂无待处理的灾情上报</text>
    </view>

    <!-- 灾情列表 -->
    <view v-else class="list">
      <view v-for="report in reportList" :key="report.reportId" class="report-card">
        <!-- 基础信息 -->
        <view class="info">
          <text class="title">{{ report.title }}</text>
          <text class="location">📍 {{ report.location }}</text>
          <text class="time">上报时间：{{ formatTime(report.createTime) }}</text>
          <text class="status pending">待处理</text>
        </view>

        <!-- 灾情描述 -->
        <view class="content">
          <text class="label">灾情描述：</text>
          <text class="desc">{{ report.content }}</text>
        </view>

        <!-- 图片预览（有图片才显示） -->
        <view v-if="report.imageList && report.imageList.length > 0" class="image-list">
          <text class="label">现场图片：</text>
          <view class="images">
            <image 
              v-for="(img, index) in report.imageList" 
              :key="index" 
              :src="img" 
              mode="aspectFill" 
              class="preview"
              @click="previewImage(img, report.imageList)"
            />
          </view>
        </view>

        <!-- 处理按钮 -->
        <view class="action">
          <button @click="openHandleModal(report.reportId)" class="handle-btn">处理</button>
        </view>
      </view>
    </view>

    <!-- 处理弹窗（easycom自动引入uni-popup，无需手动import） -->
    <uni-popup ref="handleModal" type="center" background-color="rgba(0,0,0,0.5)">
      <view class="modal-content">
        <view class="modal-header">
          <text class="modal-title">填写处理结果</text>
          <text class="close" @click="closeModal">×</text>
        </view>
        <textarea 
          v-model="handleResult" 
          placeholder="请详细填写灾情处理情况..." 
          class="textarea"
        ></textarea>
        <view class="modal-footer">
          <button @click="closeModal" class="cancel-btn">取消</button>
          <button @click="submitHandle" class="confirm-btn">确认处理</button>
        </view>
      </view>
    </uni-popup>
  </view>
</template>

<script>
import { get, post } from '@/utils/request'

// 核心修改1：删除手动引入uni-popup的代码
// import uniPopup from '@/components/uni-popup/uni-popup.vue'

export default {
  // 核心修改2：删除components里的uniPopup注册
  // components: { uniPopup },
  data() {
    return {
      loading: false,
      reportList: [],
      handleResult: '',
      currentReportId: null
    }
  },
  async mounted() {
    // 页面加载时获取待处理灾情列表
    await this.loadReports()
  },
  methods: {
    /**
     * 加载待处理灾情列表
     */
    async loadReports() {
      this.loading = true
      try {
        const res = await get('/report/admin/list')
        this.reportList = res.data || []
        
        // 补充：解析图片JSON（如果后端没解析的话）
        this.reportList.forEach(report => {
          if (report.images && !report.imageList) {
            try {
              report.imageList = JSON.parse(report.images)
            } catch (e) {
              report.imageList = []
            }
          }
        })
      } catch (err) {
        console.error('加载灾情列表失败：', err)
        uni.showToast({ title: '加载失败，请重试', icon: 'none' })
      } finally {
        this.loading = false
      }
    },

    /**
     * 格式化时间（ISO格式转成友好显示）
     */
    formatTime(timeStr) {
      if (!timeStr) return '未知时间'
      const date = new Date(timeStr)
      return `${date.getFullYear()}-${(date.getMonth()+1).toString().padStart(2, '0')}-${date.getDate().toString().padStart(2, '0')} ${date.getHours().toString().padStart(2, '0')}:${date.getMinutes().toString().padStart(2, '0')}`
    },

    /**
     * 预览图片
     */
    previewImage(current, urls) {
      uni.previewImage({
        current,
        urls
      })
    },

    /**
     * 打开处理弹窗
     */
    openHandleModal(id) {
      this.currentReportId = id
      this.handleResult = '' // 清空输入框
      this.$refs.handleModal.open() // 打开弹窗
    },

    /**
     * 关闭处理弹窗
     */
    closeModal() {
      this.$refs.handleModal.close()
    },

    /**
     * 提交处理结果
     */
    async submitHandle() {
      // 表单校验
      if (!this.handleResult.trim()) {
        uni.showToast({ title: '处理结果不能为空', icon: 'none' })
        return
      }

      try {
        uni.showLoading({ title: '处理中...' })
        // 调用后端处理接口
        await post(`/report/admin/${this.currentReportId}/handle`, { 
          result: this.handleResult 
        })
        uni.showToast({ title: '处理成功', icon: 'success' })
        this.closeModal() // 关闭弹窗
        await this.loadReports() // 刷新列表（该条上报会从待处理列表消失）
      } catch (err) {
        console.error('处理灾情失败：', err)
        uni.showToast({ title: '处理失败，请重试', icon: 'none' })
      } finally {
        uni.hideLoading()
      }
    }
  }
}
</script>

<style scoped>
/* 整体容器 */
.manage-container { 
  padding: 20rpx; 
  background-color: #f5f5f5;
  min-height: 100vh;
}

/* 标题 */
.header { 
  font-size: 36rpx; 
  font-weight: bold;
  margin-bottom: 30rpx; 
  color: #333; 
}

/* 加载/空数据提示 */
.loading, .empty {
  text-align: center;
  padding: 100rpx 0;
  color: #999;
  font-size: 28rpx;
}

/* 灾情卡片列表 */
.list {
  gap: 20rpx;
}

/* 单个灾情卡片 */
.report-card {
  background: #fff;
  padding: 30rpx;
  border-radius: 16rpx;
  margin-bottom: 20rpx;
  box-shadow: 0 2rpx 8rpx rgba(0,0,0,0.05);
}

/* 基础信息区域 */
.info {
  margin-bottom: 20rpx;
}
.title {
  font-weight: bold;
  display: block;
  font-size: 32rpx;
  color: #333;
  margin-bottom: 8rpx;
}
.location {
  font-size: 28rpx;
  color: #666;
  display: block;
  margin-bottom: 8rpx;
}
.time {
  font-size: 26rpx;
  color: #999;
  display: block;
  margin-bottom: 8rpx;
}
.status.pending {
  background: #fff7e6;
  color: #fa8c16;
  padding: 4rpx 12rpx;
  border-radius: 20rpx;
  font-size: 24rpx;
  display: inline-block;
}

/* 灾情描述 */
.content {
  margin-bottom: 20rpx;
}
.label {
  font-weight: bold;
  font-size: 28rpx;
  color: #333;
}
.desc {
  font-size: 28rpx;
  color: #666;
  line-height: 1.6;
  margin-top: 8rpx;
  display: block;
}

/* 图片区域 */
.image-list {
  margin-bottom: 20rpx;
}
.images {
  display: flex;
  flex-wrap: wrap;
  gap: 20rpx;
  margin-top: 10rpx;
}
.preview {
  width: 160rpx;
  height: 160rpx;
  border-radius: 12rpx;
}

/* 操作按钮 */
.action {
  text-align: right;
}
.handle-btn {
  background: #1890ff;
  color: #fff;
  border: none;
  border-radius: 50rpx;
  padding: 16rpx 40rpx;
  font-size: 28rpx;
}

/* 弹窗样式 */
.modal-content {
  width: 650rpx;
  background: #fff;
  border-radius: 16rpx;
  padding: 30rpx;
}
.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20rpx;
}
.modal-title {
  font-size: 32rpx;
  font-weight: bold;
  color: #333;
}
.close {
  font-size: 36rpx;
  color: #999;
  width: 60rpx;
  height: 60rpx;
  text-align: center;
  line-height: 60rpx;
}
.textarea {
  width: 100%;
  height: 200rpx;
  border: 1rpx solid #ddd;
  border-radius: 12rpx;
  padding: 20rpx;
  font-size: 28rpx;
  resize: none;
}
.modal-footer {
  display: flex;
  justify-content: space-between;
  margin-top: 30rpx;
  gap: 20rpx;
}
.cancel-btn {
  flex: 1;
  background: #f5f5f5;
  color: #333;
  border: none;
  border-radius: 50rpx;
  padding: 16rpx;
  font-size: 28rpx;
}
.confirm-btn {
  flex: 1;
  background: #1890ff;
  color: #fff;
  border: none;
  border-radius: 50rpx;
  padding: 16rpx;
  font-size: 28rpx;
}
</style>