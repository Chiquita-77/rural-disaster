<template>
  <view class="user-container">
    <view class="header">用户管理</view>
    
    <view class="user-list">
      <view v-for="user in userList" :key="user.userId" class="user-card">
        <view class="info">
          <text class="name">{{ user.username }}</text>
          <text class="phone">{{ user.phone }}</text>
          <text class="role">{{ getRoleText(user.role) }}</text>
          <text v-if="user.villageId" class="village">村庄：{{ user.villageId }}</text>
        </view>
        <switch 
          :checked="user.status === 1" 
          @change="toggleStatus(user.userId, $event)"
          color="#1890ff"
        />
      </view>
    </view>
  </view>
</template>

<script>
import { get, post } from '@/utils/request'

export default {
  data() {
    return {
      userList: []
    }
  },
  async mounted() {
    await this.loadUsers()
  },
  methods: {
    async loadUsers() {
      try {
        // 修正：添加 /user 前缀，和后端路径对齐
        const res = await get('/user/admin/user/list')
        this.userList = res.data || []
        
        // 保留你的mock逻辑（仅补充村庄ID显示，不修改）
        this.userList.forEach(u => {
          u.villageName = u.villageId ? 'XX村' : ''
        })
      } catch (err) {
        console.error('加载用户列表失败：', err)
        uni.showToast({ title: '加载用户列表失败', icon: 'none' })
      }
    },
    // 适配数字role：1=村民，2=信息员，3=乡镇管理员
    getRoleText(role) {
      const map = {
        1: '村民',
        2: '信息员',
        3: '乡镇'
      }
      return map[role] || role
    },
    async toggleStatus(userId, e) {
      uni.showLoading({ title: '处理中...' })
      try {
        // 修正：添加 /user 前缀，和后端路径对齐
        await post(`/user/admin/${userId}/toggle`)
        // 更新本地状态
        const user = this.userList.find(u => u.userId === userId)
        if (user) {
          user.status = e.detail.value ? 1 : 0
        }
        uni.showToast({ title: e.detail.value ? '已启用' : '已禁用', icon: 'none' })
      } catch (err) {
        uni.showToast({ title: '操作失败', icon: 'none' })
        // 回滚状态
        const user = this.userList.find(u => u.userId === userId)
        if (user) {
          user.status = e.detail.value ? 0 : 1
        }
      } finally {
        uni.hideLoading()
      }
    }
  }
}
</script>

<style scoped>
.user-container { padding: 20rpx; }
.header { font-size: 36rpx; margin-bottom: 40rpx; color: #333; }
.user-card {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: white;
  padding: 30rpx;
  border-radius: 16rpx;
  margin-bottom: 20rpx;
  box-shadow: 0 2rpx 8rpx rgba(0,0,0,0.05);
}
.info { flex: 1; }
.name { font-weight: bold; display: block; font-size: 32rpx; }
.phone { color: #666; font-size: 28rpx; margin: 8rpx 0; }
.role { background: #e6f7ff; color: #1890ff; padding: 4rpx 12rpx; border-radius: 20rpx; font-size: 24rpx; }
.village { color: #999; font-size: 26rpx; margin-top: 8rpx; }
</style>