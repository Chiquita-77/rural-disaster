<template>
  <view class="disaster-type-container">
    <!-- 页面标题 -->
    <view class="page-header">
      <text class="title">灾害类型管理</text>
    </view>

    <!-- 操作栏 -->
    <view class="action-bar">
      <button class="add-btn" @click="openAddModal">➕ 添加新灾害类型</button>
    </view>

    <!-- 列表区域 -->
    <view v-if="loading" class="loading">
      <text>加载中...</text>
    </view>

    <view v-else-if="typeList.length === 0" class="empty">
      <text>暂无灾害类型，点击"添加新灾害类型"创建</text>
    </view>

    <view v-else class="type-list">
      <view v-for="item in typeList" :key="item.id" class="type-card">
        <view class="card-header">
          <text class="type-name">{{ item.disasterName }}</text>
          <text class="status-tag" :class="item.sortNum === 1 ? 'active' : 'inactive'">
            {{ item.sortNum === 1 ? '启用' : '禁用' }}
          </text>
        </view>

        <view class="card-body">
          <text class="desc-label">类型说明：</text>
          <text class="desc-content">{{ item.disasterHarm || '无' }}</text>
          <text class="sort-label">排序号：</text>
          <text class="sort-content">{{ item.sortNum }}</text>
        </view>

        <view class="card-footer">
          <button 
            v-if="item.sortNum === 0" 
            @click="updateStatus(item.id, 1)" 
            class="btn enable-btn"
          >
            启用
          </button>
          <button 
            v-if="item.sortNum === 1" 
            @click="updateStatus(item.id, 0)" 
            class="btn disable-btn"
          >
            禁用
          </button>
          <button @click="openEditModal(item)" class="btn edit-btn">编辑</button>
        </view>
      </view>
    </view>

    <!-- 添加/编辑弹窗 -->
    <uni-popup ref="typeModal" type="center" maskClick="false">
      <view class="modal-wrap">
        <view class="modal-header">
          <text class="modal-title">{{ isEdit ? '编辑灾害类型' : '添加灾害类型' }}</text>
          <text class="close-icon" @click="closeModal">×</text>
        </view>

        <view class="modal-form">
          <view class="form-item">
            <text class="form-label">类型名称 *</text>
            <input 
              v-model="form.disasterName" 
              placeholder="请输入灾害类型名称（如：暴雨、台风）" 
              class="form-input"
            />
          </view>

          <view class="form-item">
            <text class="form-label">类型说明</text>
            <textarea 
              v-model="form.disasterHarm" 
              placeholder="请输入灾害类型说明（选填）" 
              class="form-textarea"
            />
          </view>

          <view class="form-item">
            <text class="form-label">排序号</text>
            <input 
              v-model.number="form.sortNum" 
              type="number" 
              placeholder="数字越小越靠前，默认1" 
              class="form-input"
            />
          </view>

          <view class="form-item">
            <text class="form-label">状态</text>
            <view class="radio-group">
              <label class="radio-item">
                <radio v-model="form.status" :value="1" /> 启用
              </label>
              <label class="radio-item">
                <radio v-model="form.status" :value="0" /> 禁用
              </label>
            </view>
          </view>
        </view>

        <view class="modal-footer">
          <button @click="closeModal" class="btn cancel-btn">取消</button>
          <button @click="submitForm" class="btn confirm-btn">确认保存</button>
        </view>
      </view>
    </uni-popup>
  </view>
</template>

<script>
import uniPopup from '@dcloudio/uni-ui/lib/uni-popup/uni-popup.vue'
import { get, post } from '@/utils/request'

export default {
  components: {
    uniPopup
  },
  data() {
    return {
      loading: false,
      typeList: [],
      isEdit: false,
      form: {
        id: '',
        disasterName: '',
        disasterHarm: '',
        sortNum: 1,
        status: 1
      }
    }
  },
  onLoad() {
    this.getDisasterTypeList()
  },
  methods: {
    // 获取灾害类型列表
    async getDisasterTypeList() {
      this.loading = true
      try {
        const res = await get('/admin/disaster/type/list')
        if (res.code === 200) {
          this.typeList = res.data || []
        } else {
          uni.showToast({ title: res.msg || '获取列表失败', icon: 'none' })
        }
      } catch (err) {
        console.error('获取灾害类型列表失败：', err)
        uni.showToast({ title: '网络异常，获取失败', icon: 'none' })
      } finally {
        this.loading = false
      }
    },

    // 打开添加弹窗
    openAddModal() {
      this.isEdit = false
      this.form = {
        id: '',
        disasterName: '',
        disasterHarm: '',
        sortNum: 1,
        status: 1
      }
      this.$refs.typeModal.open()
    },

    // 打开编辑弹窗
    openEditModal(item) {
      this.isEdit = true
      this.form = {
        id: item.id,
        disasterName: item.disasterName,
        disasterHarm: item.disasterHarm || '',
        sortNum: item.sortNum || 1,
        status: item.sortNum || 1
      }
      this.$refs.typeModal.open()
    },

    // 关闭弹窗
    closeModal() {
      this.$refs.typeModal.close()
    },

    // 提交表单（新增/编辑）
    async submitForm() {
      if (!this.form.disasterName.trim()) {
        return uni.showToast({ title: '请输入灾害类型名称', icon: 'none' })
      }

      try {
        uni.showLoading({ title: '保存中...' })
        const res = await post('/admin/disaster/type/save', this.form)
        if (res.code === 200) {
          uni.showToast({ title: this.isEdit ? '编辑成功' : '添加成功', icon: 'success' })
          this.closeModal()
          this.getDisasterTypeList()
        } else {
          uni.showToast({ title: res.msg || '保存失败', icon: 'none' })
        }
      } catch (err) {
        console.error('保存灾害类型失败：', err)
        uni.showToast({ title: '网络异常，保存失败', icon: 'none' })
      } finally {
        uni.hideLoading()
      }
    },

    // 更新状态（启用/禁用）
    async updateStatus(id, status) {
      const tipText = status === 1 ? '确定启用该类型吗？' : '确定禁用该类型吗？'
      uni.showModal({
        title: '确认操作',
        content: tipText,
        success: async (res) => {
          if (res.confirm) {
            try {
              const res = await post('/admin/disaster/type/status', { id, status })
              if (res.code === 200) {
                uni.showToast({ 
                  title: status === 1 ? '启用成功' : '禁用成功', 
                  icon: 'success' 
                })
                this.getDisasterTypeList()
              } else {
                uni.showToast({ title: res.msg || '操作失败', icon: 'none' })
              }
            } catch (err) {
              console.error('更新状态失败：', err)
              uni.showToast({ title: '网络异常，操作失败', icon: 'none' })
            }
          }
        }
      })
    }
  }
}
</script>

<style scoped>
.disaster-type-container {
  width: 100%;
  height: 100%;
  background-color: #f5f7fa;
  padding: 20rpx;
}

.page-header {
  margin-bottom: 20rpx;
}

.title {
  font-size: 36rpx;
  font-weight: bold;
  color: #1f2937;
}

.action-bar {
  margin-bottom: 20rpx;
}

.add-btn {
  background-color: #1677ff;
  color: #fff;
  border: none;
  border-radius: 8rpx;
  padding: 12rpx 24rpx;
  font-size: 28rpx;
}

.loading, .empty {
  text-align: center;
  padding: 100rpx 0;
  font-size: 28rpx;
  color: #666;
}

.type-list {
  display: flex;
  flex-direction: column;
  gap: 20rpx;
}

.type-card {
  background-color: #fff;
  border-radius: 12rpx;
  padding: 30rpx;
  box-shadow: 0 2rpx 8rpx rgba(0,0,0,0.06);
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20rpx;
}

.type-name {
  font-size: 32rpx;
  font-weight: 600;
  color: #1f2937;
}

.status-tag {
  font-size: 24rpx;
  padding: 4rpx 12rpx;
  border-radius: 20rpx;
}

.status-tag.active {
  background-color: #e6f4ff;
  color: #1677ff;
}

.status-tag.inactive {
  background-color: #f5f5f5;
  color: #999;
}

.card-body {
  display: flex;
  flex-direction: column;
  gap: 12rpx;
  margin-bottom: 20rpx;
}

.desc-label, .sort-label {
  font-size: 26rpx;
  color: #666;
}

.desc-content, .sort-content {
  font-size: 26rpx;
  color: #333;
  margin-left: 10rpx;
}

.card-footer {
  display: flex;
  gap: 16rpx;
}

.btn {
  flex: 1;
  border: none;
  border-radius: 8rpx;
  padding: 12rpx 0;
  font-size: 26rpx;
}

.enable-btn {
  background-color: #52c41a;
  color: #fff;
}

.disable-btn {
  background-color: #ff4d4f;
  color: #fff;
}

.edit-btn {
  background-color: #1677ff;
  color: #fff;
}

/* 弹窗样式 */
.modal-wrap {
  width: 680rpx;
  background-color: #fff;
  border-radius: 16rpx;
  padding: 30rpx;
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 30rpx;
}

.modal-title {
  font-size: 32rpx;
  font-weight: bold;
  color: #1f2937;
}

.close-icon {
  font-size: 36rpx;
  color: #999;
  cursor: pointer;
}

.modal-form {
  margin-bottom: 30rpx;
}

.form-item {
  margin-bottom: 24rpx;
}

.form-label {
  display: block;
  font-size: 28rpx;
  color: #333;
  margin-bottom: 8rpx;
}

.form-input, .form-textarea {
  width: 100%;
  padding: 12rpx 16rpx;
  border: 1rpx solid #d9d9d9;
  border-radius: 8rpx;
  font-size: 26rpx;
  color: #333;
}

.form-textarea {
  min-height: 120rpx;
  resize: none;
}

.radio-group {
  display: flex;
  gap: 40rpx;
  padding: 8rpx 0;
}

.radio-item {
  font-size: 26rpx;
  display: flex;
  align-items: center;
  gap: 8rpx;
}

.modal-footer {
  display: flex;
  gap: 20rpx;
}

.cancel-btn {
  flex: 1;
  background-color: #f5f5f5;
  color: #666;
}

.confirm-btn {
  flex: 1;
  background-color: #1677ff;
  color: #fff;
}
</style>