<template>
  <view class="review-container">
    <view class="header">风险提示审核</view>
    
    <view v-if="list.length === 0" class="empty">暂无待审核的风险提示</view>
    
    <view v-else class="tip-list">
      <view v-for="item in list" :key="item.tip_id" class="tip-card">
        <view class="card-header">
          <text class="title">{{ item.title }}</text>
          <text class="village">村庄：{{ item.village_name }}</text>
        </view>
        <text class="content">{{ item.content }}</text>
        <text class="time">提交时间：{{ formatDate(item.create_time) }}</text>
        
        <view class="actions">
          <button class="btn pass" @click="handleReview(item.tip_id, 1)">✅ 通过</button>
          <button class="btn reject" @click="showRejectModal(item.tip_id)">❌ 驳回</button>
        </view>
      </view>
    </view>

    <!-- 驳回弹窗 -->
    <uni-popup ref="rejectPopup" type="dialog">
      <view class="popup-content">
        <text class="popup-title">请输入驳回原因</text>
        <textarea v-model="rejectReason" placeholder="请说明理由..." class="reason-input" />
        <view class="popup-buttons">
          <button @click="closePopup" class="btn cancel">取消</button>
          <button @click="confirmReject" class="btn confirm">确定驳回</button>
        </view>
      </view>
    </uni-popup>
  </view>
</template>

<script>
import { get, post } from '@/utils/request'
import uniPopup from '@dcloudio/uni-ui/lib/uni-popup/uni-popup.vue'

export default {
  components: { uniPopup },
  data() {
    return {
      list: [],
      currentTipId: null,
      rejectReason: ''
    }
  },
  async mounted() {
    await this.loadList()
  },
  methods: {
    async loadList() {
      try {
        const res = await get('/tip/review/list')
        this.list = res.data || []
        // 已删除 mock 村庄名称的代码，直接使用后端返回的 village_name
      } catch (err) {
        console.error('加载列表失败：', err)
        uni.showToast({ title: '加载列表失败', icon: 'none' })
      }
    },
    formatDate(t) {
      return t?.replace('T', ' ').substring(0, 16) || ''
    },
    async handleReview(tipId, status) {
      if (!tipId) {
        uni.showToast({ title: 'tipId 不能为空', icon: 'none' })
        return
      }
      try {
        uni.showLoading({ title: '处理中...' })
        const res = await post(`/tip/${tipId}/review`, { status })
        if (res.code === 200) {
          uni.showToast({ title: '操作成功', icon: 'success' })
          this.loadList()
        } else {
          uni.showToast({ title: res.msg || '操作失败', icon: 'none' })
        }
      } catch (err) {
        console.error('审核失败：', err)
        uni.showToast({ title: '网络或接口异常', icon: 'none' })
      } finally {
        uni.hideLoading()
      }
    },
    showRejectModal(tipId) {
      this.currentTipId = tipId
      this.rejectReason = ''
      this.$refs.rejectPopup.open()
    },
    closePopup() {
      this.$refs.rejectPopup.close()
    },
    async confirmReject() {
      if (!this.rejectReason.trim()) {
        uni.showToast({ title: '请输入驳回原因', icon: 'none' })
        return
      }
      try {
        uni.showLoading({ title: '处理中...' })
        const res = await post(`/tip/${this.currentTipId}/review`, {
          status: -1,
          comment: this.rejectReason
        })
        if (res.code === 200) {
          uni.showToast({ title: '已驳回', icon: 'success' })
          this.closePopup()
          this.loadList()
        } else {
          uni.showToast({ title: res.msg || '驳回失败', icon: 'none' })
        }
      } catch (err) {
        console.error('驳回失败：', err)
        uni.showToast({ title: '网络或接口异常', icon: 'none' })
      } finally {
        uni.hideLoading()
      }
    }
  }
}
</script>

<style scoped>
.review-container { padding: 20rpx; }
.header { font-size: 36rpx; margin-bottom: 40rpx; color: #333; }
.empty { text-align: center; padding: 100rpx 0; color: #999; }

.tip-card {
  background: white;
  border-radius: 16rpx;
  padding: 30rpx;
  margin-bottom: 30rpx;
  box-shadow: 0 2rpx 12rpx rgba(0,0,0,0.05);
}
.card-header { display: flex; justify-content: space-between; margin-bottom: 20rpx; }
.title { font-weight: bold; font-size: 32rpx; }
.village { color: #1890ff; font-size: 28rpx; }
.content { display: block; margin: 20rpx 0; line-height: 1.5; }
.time { color: #999; font-size: 24rpx; }

.actions { display: flex; justify-content: flex-end; margin-top: 30rpx; }
.btn {
  width: 160rpx;
  height: 60rpx;
  border-radius: 8rpx;
  font-size: 28rpx;
  margin-left: 20rpx;
}
.pass { background: #52c41a; color: white; }
.reject { background: #f5222d; color: white; }

/* 弹窗样式 */
.popup-content { padding: 40rpx; }
.popup-title { display: block; text-align: center; font-size: 32rpx; margin-bottom: 30rpx; }
.reason-input { 
  width: 100%; height: 200rpx; 
  border: 1px solid #ddd; border-radius: 12rpx; 
  padding: 20rpx; margin-bottom: 40rpx; 
}
.popup-buttons { display: flex; justify-content: space-around; }
.cancel { background: #ccc; }
.confirm { background: #f5222d; color: white; }
</style>