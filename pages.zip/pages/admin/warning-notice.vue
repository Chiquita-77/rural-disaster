<template>
  <view class="warning-notice-container">
    <!-- 页面标题 -->
    <view class="page-header">
      <text class="title">灾害预警通知管理</text>
    </view>

    <!-- 筛选栏（修改为启用状态筛选） -->
    <view class="filter-bar">
      <view class="filter-item">
        <text class="filter-label">启用状态：</text>
        <picker @change="handleStatusChange" :value="statusIndex" :range="statusOptions" range-key="label">
          <view class="picker-text">{{ statusOptions[statusIndex].label }}</view>
        </picker>
      </view>
      <!-- 移除发布新预警按钮 -->
    </view>

    <!-- 列表区域 -->
    <view v-if="loading" class="loading">
      <text>加载中...</text>
    </view>

    <view v-else-if="warningList.length === 0" class="empty">
      <text>暂无预警通知</text>
    </view>

    <view v-else class="warning-list">
      <view v-for="item in warningList" :key="item.warningId" class="warning-card">
        <view class="card-header">
          <text class="warning-title">{{ item.title }}</text>
          <!-- 修改状态标签文字和样式 -->
          <text class="status-tag" :class="item.isPushed === 1 ? 'enabled' : 'disabled'">
            {{ item.isPushed === 1 ? '已启用' : '已禁用' }}
          </text>
        </view>

        <view class="card-body">
          <view class="info-row">
            <text class="label">灾害类型：</text>
            <text class="value">{{ disasterTypeMap[item.disasterTypeId] || '未知' }}</text>
          </view>
          <view class="info-row">
            <text class="label">目标村庄：</text>
            <text class="value">{{ item.targetVillageIds || '无' }}</text>
          </view>
          <view class="info-row">
            <text class="label">发布人：</text>
            <text class="value">{{ item.publisherName || '未知' }}</text>
          </view>
          <view class="info-row">
            <text class="label">发布类型：</text>
            <text class="value">{{ item.submitterType === 'info_user' ? '信息员发布' : '管理员发布' }}</text>
          </view>
          <view class="info-row">
            <text class="label">发布时间：</text>
            <text class="value">{{ formatTime(item.publishTime) }}</text>
          </view>
          <view class="info-row" v-if="item.isPushed === 1">
            <text class="label">启用时间：</text>
            <text class="value">{{ formatTime(item.pushTime) }}</text>
          </view>
          <view class="info-row">
            <text class="label">已读/未读：</text>
            <text class="value">{{ item.readCount }}/{{ item.unreadCount }}</text>
          </view>
        </view>

        <view class="card-footer">
          <!-- 核心：启用/禁用按钮（根据当前状态切换） -->
          <button 
            @click="toggleStatus(item.warningId, item.isPushed)" 
            class="btn" 
            :class="item.isPushed === 1 ? 'disable-btn' : 'enable-btn'"
          >
            {{ item.isPushed === 1 ? '禁用' : '启用' }}
          </button>
          <button @click="viewStat(item.warningId)" class="btn stat-btn">接收统计</button>
          <button @click="deleteWarning(item.warningId)" class="btn delete-btn">删除</button>
        </view>
      </view>
    </view>

    <!-- 只保留接收统计弹窗（移除发布/编辑弹窗） -->
    <uni-popup ref="statModal" type="center" maskClick="false">
      <view class="stat-modal-wrap">
        <view class="modal-header">
          <text class="modal-title">接收统计详情</text>
          <text class="close-icon" @click="closeStatModal">×</text>
        </view>

        <view class="stat-content" v-if="statLoading">
          <text class="loading-text">加载中...</text>
        </view>

        <view class="stat-content" v-else>
          <view class="stat-item">
            <text class="stat-label">总接收人数：</text>
            <text class="stat-value">{{ statData.totalCount || 0 }}</text>
          </view>
          <view class="stat-item">
            <text class="stat-label">已读人数：</text>
            <text class="stat-value">{{ statData.readCount || 0 }}</text>
          </view>
          <view class="stat-item">
            <text class="stat-label">未读人数：</text>
            <text class="stat-value">{{ statData.unreadCount || 0 }}</text>
          </view>
          <!-- 移除二次推送按钮 -->
        </view>
      </view>
    </uni-popup>
  </view>
</template>

<script>
import uniPopup from '@dcloudio/uni-ui/lib/uni-popup/uni-popup.vue'
import { get, post } from '@/utils/request'

export default {
  components: {
    uniPopup
  },
  data() {
    return {
      loading: false,
      warningList: [],
      disasterTypeList: [], // 灾害类型列表
      disasterTypeMap: {},  // 灾害类型ID→名称映射
      statusIndex: 0,
      // 修改筛选选项文字（推送→启用）
      statusOptions: [
        { label: '全部', value: null },
        { label: '已禁用', value: 0 },
        { label: '已启用', value: 1 }
      ],
      // 统计弹窗相关
      statLoading: false,
      statData: {},
      currentWarningId: ''
    }
  },
  onLoad() {
    this.getWarningList()
    this.getDisasterTypeList()
  },
  methods: {
    // 格式化时间
    formatTime(time) {
      if (!time) return '无'
      const date = new Date(time)
      return `${date.getFullYear()}-${(date.getMonth()+1).toString().padStart(2, '0')}-${date.getDate().toString().padStart(2, '0')} ${date.getHours().toString().padStart(2, '0')}:${date.getMinutes().toString().padStart(2, '0')}`
    },

    // 1. 获取预警列表
    async getWarningList() {
      this.loading = true
      try {
        const isPushed = this.statusOptions[this.statusIndex].value
        const res = await get('/admin/warning/list', { isPushed })
        if (res.code === 200) {
          this.warningList = res.data || []
        } else {
          uni.showToast({ title: res.msg || '获取预警列表失败', icon: 'none' })
        }
      } catch (err) {
        console.error('获取预警列表失败：', err)
        uni.showToast({ title: '网络异常，获取失败', icon: 'none' })
      } finally {
        this.loading = false
      }
    },

    // 2. 获取灾害类型列表
    async getDisasterTypeList() {
      try {
        const res = await get('/admin/disaster/type/list')
        if (res.code === 200) {
          this.disasterTypeList = res.data || []
          // 构建ID→名称映射
          this.disasterTypeList.forEach(item => {
            this.disasterTypeMap[item.id] = item.disasterName
          })
        }
      } catch (err) {
        console.error('获取灾害类型列表失败：', err)
      }
    },

    // 3. 筛选状态变化
    handleStatusChange(e) {
      this.statusIndex = e.detail.value
      this.getWarningList()
    },

    // 4. 核心：启用/禁用预警
    async toggleStatus(warningId, currentStatus) {
      const newStatus = currentStatus === 1 ? 0 : 1
      const title = newStatus === 1 ? '启用' : '禁用'
      
      uni.showModal({
        title: `确认${title}`,
        content: `确定要${title}这条预警通知吗？`,
        success: async (res) => {
          if (res.confirm) {
            try {
              uni.showLoading({ title: `${title}中...` })
              // 调用后端启用/禁用接口
              const res = await post(`/admin/warning/toggle-status/${warningId}`, {
                status: newStatus
              })
              if (res.code === 200) {
                uni.showToast({ title: `${title}成功`, icon: 'success' })
                this.getWarningList() // 刷新列表
              } else {
                uni.showToast({ title: res.msg || `${title}失败`, icon: 'none' })
              }
            } catch (err) {
              console.error(`${title}预警失败：`, err)
              uni.showToast({ title: `网络异常，${title}失败`, icon: 'none' })
            } finally {
              uni.hideLoading()
            }
          }
        }
      })
    },

    // 5. 查看接收统计
    async viewStat(warningId) {
      this.currentWarningId = warningId
      this.statLoading = true
      this.$refs.statModal.open()
      try {
        const res = await get(`/admin/warning/stat/${warningId}`)
        if (res.code === 200) {
          this.statData = res.data || {}
        } else {
          uni.showToast({ title: res.msg || '获取统计失败', icon: 'none' })
        }
      } catch (err) {
        console.error('获取统计失败：', err)
        uni.showToast({ title: '网络异常，获取失败', icon: 'none' })
      } finally {
        this.statLoading = false
      }
    },

    // 6. 关闭统计弹窗
    closeStatModal() {
      this.$refs.statModal.close()
      this.statData = {}
    },

    // 7. 删除预警
    async deleteWarning(warningId) {
      uni.showModal({
        title: '确认删除',
        content: '确定要删除这条预警通知吗？删除后不可恢复！',
        success: async (res) => {
          if (res.confirm) {
            try {
              uni.showLoading({ title: '删除中...' })
              const res = await post(`/admin/warning/delete/${warningId}`)
              if (res.code === 200) {
                uni.showToast({ title: '删除成功', icon: 'success' })
                this.getWarningList()
              } else {
                uni.showToast({ title: res.msg || '删除失败', icon: 'none' })
              }
            } catch (err) {
              console.error('删除预警失败：', err)
              uni.showToast({ title: '网络异常，删除失败', icon: 'none' })
            } finally {
              uni.hideLoading()
            }
          }
        }
      })
    }
  }
}
</script>

<style scoped>
.warning-notice-container {
  width: 100%;
  height: 100%;
  background-color: #f5f7fa;
  padding: 20rpx;
  box-sizing: border-box;
}

/* 页面标题 */
.page-header {
  margin-bottom: 20rpx;
}
.title {
  font-size: 36rpx;
  font-weight: bold;
  color: #1f2937;
}

/* 筛选栏 */
.filter-bar {
  display: flex;
  justify-content: flex-start; /* 移除右侧发布按钮后左对齐 */
  align-items: center;
  margin-bottom: 20rpx;
  padding: 16rpx;
  background-color: #fff;
  border-radius: 8rpx;
}
.filter-item {
  display: flex;
  align-items: center;
}
.filter-label {
  font-size: 28rpx;
  color: #333;
  margin-right: 12rpx;
}
.picker-text {
  font-size: 26rpx;
  color: #666;
  padding: 8rpx 12rpx;
  border: 1rpx solid #d9d9d9;
  border-radius: 6rpx;
  width: 180rpx;
  text-align: center;
}

/* 列表样式 */
.loading, .empty {
  text-align: center;
  padding: 100rpx 0;
  font-size: 28rpx;
  color: #666;
}

.warning-list {
  display: flex;
  flex-direction: column;
  gap: 20rpx;
}

.warning-card {
  background-color: #fff;
  border-radius: 12rpx;
  padding: 30rpx;
  box-shadow: 0 2rpx 8rpx rgba(0,0,0,0.06);
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20rpx;
  padding-bottom: 10rpx;
  border-bottom: 1rpx solid #f0f0f0;
}

.warning-title {
  font-size: 32rpx;
  font-weight: 600;
  color: #1f2937;
  flex: 1;
}

/* 修改状态标签样式（启用/禁用） */
.status-tag {
  font-size: 24rpx;
  padding: 4rpx 12rpx;
  border-radius: 20rpx;
}
.status-tag.enabled {
  background-color: #e6f4ff;
  color: #1677ff;
}
.status-tag.disabled {
  background-color: #fff2f0;
  color: #ff4d4f;
}

.card-body {
  margin-bottom: 20rpx;
}

.info-row {
  display: flex;
  margin-bottom: 12rpx;
  font-size: 26rpx;
}
.label {
  color: #666;
  min-width: 120rpx;
}
.value {
  color: #333;
  flex: 1;
  word-break: break-all;
}

.card-footer {
  display: flex;
  gap: 12rpx;
}

.btn {
  flex: 1;
  border: none;
  border-radius: 8rpx;
  padding: 12rpx 0;
  font-size: 26rpx;
}
/* 新增启用/禁用按钮样式 */
.enable-btn {
  background-color: #52c41a;
  color: #fff;
}
.disable-btn {
  background-color: #ff4d4f;
  color: #fff;
}
.stat-btn {
  background-color: #1890ff;
  color: #fff;
}
.delete-btn {
  background-color: #8c8c8c;
  color: #fff;
}

/* 统计弹窗样式 */
.stat-modal-wrap {
  width: 500rpx;
  background-color: #fff;
  border-radius: 16rpx;
  padding: 30rpx;
  box-sizing: border-box;
}
.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 30rpx;
}
.modal-title {
  font-size: 32rpx;
  font-weight: bold;
  color: #1f2937;
}
.close-icon {
  font-size: 36rpx;
  color: #999;
  cursor: pointer;
}
.stat-content {
  padding: 20rpx 0;
}
.loading-text {
  text-align: center;
  font-size: 28rpx;
  color: #666;
}
.stat-item {
  display: flex;
  justify-content: space-between;
  padding: 16rpx 0;
  border-bottom: 1rpx solid #f0f0f0;
  font-size: 30rpx;
}
.stat-label {
  color: #333;
  font-weight: 500;
}
.stat-value {
  color: #1677ff;
  font-weight: bold;
}
</style>