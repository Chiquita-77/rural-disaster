<template>
  <view class="guide-manage-container">
    <!-- 页面标题 -->
    <view class="page-header">
      <text class="title">防灾指南管理</text>
    </view>

    <!-- 操作栏 -->
    <view class="action-bar">
      <button class="add-btn" @click="openAddModal">➕ 添加新防灾指南</button>
    </view>

    <!-- 列表区域 -->
    <view v-if="loading" class="loading">
      <text>加载中...</text>
    </view>

    <view v-else-if="guideList.length === 0" class="empty">
      <text>暂无防灾指南，点击"添加新防灾指南"创建</text>
    </view>

    <view v-else class="guide-list">
      <view v-for="item in guideList" :key="item.id" class="guide-card">
        <view class="card-header">
          <text class="guide-title">{{ item.title }}</text>
          <text class="status-tag" :class="item.sortNum === 1 ? 'active' : 'inactive'">
            {{ item.sortNum === 1 ? '启用' : '禁用' }}
          </text>
        </view>

        <view class="card-body">
          <view class="info-row">
            <text class="label">指南分类：</text>
            <text class="value">{{ item.category || '无' }}</text>
          </view>
          <view class="info-row">
            <text class="label">排序号：</text>
            <text class="value">{{ item.sortNum }}</text>
          </view>
        </view>

        <view class="card-footer">
          <button 
            v-if="item.sortNum === 0" 
            @click="updateStatus(item.id, 1)" 
            class="btn enable-btn"
          >
            启用
          </button>
          <button 
            v-if="item.sortNum === 1" 
            @click="updateStatus(item.id, 0)" 
            class="btn disable-btn"
          >
            禁用
          </button>
          <button @click="openEditModal(item)" class="btn edit-btn">编辑</button>
        </view>
      </view>
    </view>

    <!-- 添加/编辑弹窗 -->
    <uni-popup ref="guideModal" type="center" maskClick="false">
      <view class="modal-wrap">
        <view class="modal-header">
          <text class="modal-title">{{ isEdit ? '编辑防灾指南' : '添加防灾指南' }}</text>
          <text class="close-icon" @click="closeModal">×</text>
        </view>

        <view class="modal-form">
          <view class="form-item">
            <text class="form-label">指南标题 *</text>
            <input 
              v-model="form.title" 
              placeholder="请输入防灾指南标题（如：暴雨天气避险指南）" 
              class="form-input"
            />
          </view>

          <view class="form-item">
            <text class="form-label">指南分类 *</text>
            <input 
              v-model="form.category" 
              placeholder="请输入指南分类（如：暴雨/滑坡/洪水）" 
              class="form-input"
            />
          </view>

          <view class="form-item">
            <text class="form-label">封面图</text>
            <input 
              v-model="form.coverImage" 
              placeholder="请输入封面图URL（选填）" 
              class="form-input"
            />
          </view>

          <view class="form-item">
            <text class="form-label">指南内容</text>
            <textarea 
              v-model="form.content" 
              placeholder="请输入详细的防灾指南内容" 
              class="form-textarea large"
            />
          </view>

          <view class="form-item">
            <text class="form-label">排序号</text>
            <input 
              v-model.number="form.sortNum" 
              type="number" 
              placeholder="数字越小越靠前，默认1" 
              class="form-input"
            />
          </view>

          <view class="form-item">
            <text class="form-label">状态</text>
            <view class="radio-group">
              <label class="radio-item">
                <radio v-model="form.status" :value="1" /> 启用
              </label>
              <label class="radio-item">
                <radio v-model="form.status" :value="0" /> 禁用
              </label>
            </view>
          </view>
        </view>

        <view class="modal-footer">
          <button @click="closeModal" class="btn cancel-btn">取消</button>
          <button @click="submitForm" class="btn confirm-btn">确认保存</button>
        </view>
      </view>
    </uni-popup>
  </view>
</template>

<script>
import uniPopup from '@dcloudio/uni-ui/lib/uni-popup/uni-popup.vue'
import { get, post } from '@/utils/request'

export default {
  components: {
    uniPopup
  },
  data() {
    return {
      loading: false,
      guideList: [],        // 防灾指南列表
      isEdit: false,
      form: {
        id: '',
        title: '',          // 对应后端title
        category: '',       // 对应后端category
        coverImage: '',     // 对应后端coverImage
        content: '',        // 对应后端content
        sortNum: 1,
        status: 1
      }
    }
  },
  onLoad() {
    this.getGuideList()
  },
  methods: {
    // 1. 获取防灾指南列表（对接后端/guide/list接口）
    async getGuideList() {
      this.loading = true
      try {
        // 传空category获取所有指南
        const res = await get('/guide/list', { category: '' })
        if (res.code === 200) {
          this.guideList = res.data || []
        } else {
          uni.showToast({ title: res.msg || '获取指南列表失败', icon: 'none' })
        }
      } catch (err) {
        console.error('获取防灾指南列表失败：', err)
        uni.showToast({ title: '网络异常，获取失败', icon: 'none' })
      } finally {
        this.loading = false
      }
    },

    // 2. 打开添加弹窗
    openAddModal() {
      this.isEdit = false
      this.form = {
        id: '',
        title: '',
        category: '',
        coverImage: '',
        content: '',
        sortNum: 1,
        status: 1
      }
      this.$refs.guideModal.open()
    },

    // 3. 打开编辑弹窗
    openEditModal(item) {
      this.isEdit = true
      this.form = {
        id: item.id,
        title: item.title,
        category: item.category || '',
        coverImage: item.coverImage || '',
        content: item.content || '',
        sortNum: item.sortNum || 1,
        status: item.sortNum || 1 // 临时用sortNum存状态
      }
      this.$refs.guideModal.open()
    },

    // 4. 关闭弹窗
    closeModal() {
      this.$refs.guideModal.close()
    },

    // 5. 提交表单（新增/编辑，对接后端/admin/guide/save接口）
    async submitForm() {
      // 表单校验
      if (!this.form.title.trim()) {
        return uni.showToast({ title: '请输入指南标题', icon: 'none' })
      }
      if (!this.form.category.trim()) {
        return uni.showToast({ title: '请输入指南分类', icon: 'none' })
      }

      try {
        uni.showLoading({ title: '保存中...' })
        const res = await post('/admin/guide/save', this.form)
        if (res.code === 200) {
          uni.showToast({ title: this.isEdit ? '编辑成功' : '添加成功', icon: 'success' })
          this.closeModal()
          this.getGuideList() // 刷新列表
        } else {
          uni.showToast({ title: res.msg || '保存失败', icon: 'none' })
        }
      } catch (err) {
        console.error('保存防灾指南失败：', err)
        uni.showToast({ title: '网络异常，保存失败', icon: 'none' })
      } finally {
        uni.hideLoading()
      }
    },

    // 6. 更新状态（启用/禁用，对接后端/admin/guide/status接口）
    async updateStatus(id, status) {
      const tipText = status === 1 ? '确定启用该指南吗？' : '确定禁用该指南吗？'
      uni.showModal({
        title: '确认操作',
        content: tipText,
        success: async (res) => {
          if (res.confirm) {
            try {
              const res = await post('/admin/guide/status', { id, status })
              if (res.code === 200) {
                uni.showToast({ 
                  title: status === 1 ? '启用成功' : '禁用成功', 
                  icon: 'success' 
                })
                this.getGuideList() // 刷新列表
              } else {
                uni.showToast({ title: res.msg || '操作失败', icon: 'none' })
              }
            } catch (err) {
              console.error('更新指南状态失败：', err)
              uni.showToast({ title: '网络异常，操作失败', icon: 'none' })
            }
          }
        }
      })
    }
  }
}
</script>

<style scoped>
.guide-manage-container {
  width: 100%;
  height: 100%;
  background-color: #f5f7fa;
  padding: 20rpx;
  box-sizing: border-box;
}

/* 页面标题 */
.page-header {
  margin-bottom: 20rpx;
}
.title {
  font-size: 36rpx;
  font-weight: bold;
  color: #1f2937;
}

/* 操作栏 */
.action-bar {
  margin-bottom: 20rpx;
}
.add-btn {
  background-color: #1677ff;
  color: #fff;
  border: none;
  border-radius: 8rpx;
  padding: 12rpx 24rpx;
  font-size: 28rpx;
}

/* 列表样式 */
.loading, .empty {
  text-align: center;
  padding: 100rpx 0;
  font-size: 28rpx;
  color: #666;
}

.guide-list {
  display: flex;
  flex-direction: column;
  gap: 20rpx;
}

.guide-card {
  background-color: #fff;
  border-radius: 12rpx;
  padding: 30rpx;
  box-shadow: 0 2rpx 8rpx rgba(0,0,0,0.06);
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20rpx;
  padding-bottom: 10rpx;
  border-bottom: 1rpx solid #f0f0f0;
}

.guide-title {
  font-size: 32rpx;
  font-weight: 600;
  color: #1f2937;
  flex: 1;
}

.status-tag {
  font-size: 24rpx;
  padding: 4rpx 12rpx;
  border-radius: 20rpx;
}
.status-tag.active {
  background-color: #e6f4ff;
  color: #1677ff;
}
.status-tag.inactive {
  background-color: #f5f5f5;
  color: #999;
}

.card-body {
  margin-bottom: 20rpx;
}

.info-row {
  display: flex;
  margin-bottom: 12rpx;
  font-size: 26rpx;
}
.label {
  color: #666;
  min-width: 120rpx;
}
.value {
  color: #333;
  flex: 1;
  word-break: break-all;
}

.card-footer {
  display: flex;
  gap: 16rpx;
}

.btn {
  flex: 1;
  border: none;
  border-radius: 8rpx;
  padding: 12rpx 0;
  font-size: 26rpx;
}
.enable-btn {
  background-color: #52c41a;
  color: #fff;
}
.disable-btn {
  background-color: #ff4d4f;
  color: #fff;
}
.edit-btn {
  background-color: #1677ff;
  color: #fff;
}

/* 弹窗样式 */
.modal-wrap {
  width: 680rpx;
  background-color: #fff;
  border-radius: 16rpx;
  padding: 30rpx;
  box-sizing: border-box;
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 30rpx;
}
.modal-title {
  font-size: 32rpx;
  font-weight: bold;
  color: #1f2937;
}
.close-icon {
  font-size: 36rpx;
  color: #999;
  cursor: pointer;
}

.modal-form {
  margin-bottom: 30rpx;
}

.form-item {
  margin-bottom: 24rpx;
}
.form-label {
  display: block;
  font-size: 28rpx;
  color: #333;
  margin-bottom: 8rpx;
}
.form-input, .form-textarea {
  width: 100%;
  padding: 12rpx 16rpx;
  border: 1rpx solid #d9d9d9;
  border-radius: 8rpx;
  font-size: 26rpx;
  color: #333;
  box-sizing: border-box;
}
.form-textarea {
  min-height: 120rpx;
  resize: none;
}
.form-textarea.large {
  min-height: 200rpx;
}

.radio-group {
  display: flex;
  gap: 40rpx;
  padding: 8rpx 0;
}
.radio-item {
  font-size: 26rpx;
  display: flex;
  align-items: center;
  gap: 8rpx;
}

.modal-footer {
  display: flex;
  gap: 20rpx;
}
.cancel-btn {
  flex: 1;
  background-color: #f5f5f5;
  color: #666;
}
.confirm-btn {
  flex: 1;
  background-color: #1677ff;
  color: #fff;
}
</style>