<template>
  <view class="support-container">
    <view class="header">支援申请管理</view>
    
    <!-- 加载中 -->
    <view v-if="loading" class="loading">
      <text>加载申请数据中...</text>
    </view>

    <!-- 空数据 -->
    <view v-else-if="requestList.length === 0" class="empty">
      <text>暂无待审批的支援申请</text>
    </view>

    <!-- 申请列表 -->
    <view v-else class="list">
      <!-- 修复：key和字段用下划线（联表Map返回的是下划线） -->
      <view v-for="req in requestList" :key="req.apply_id" class="request-card">
        <!-- 基础信息 -->
        <view class="info">
          <text class="title">{{ req.title }}</text>
          <!-- 修复：显示村庄名称，兜底显示village_id -->
          <text class="village">申请村庄：{{ req.village_name || req.village_id || '未知村庄' }}</text>
          <text class="time">申请时间：{{ formatTime(req.submit_time) }}</text>
        </view>

        <!-- 申请内容 -->
        <view class="content">
          <text class="label">申请说明：</text>
          <text class="desc">{{ req.detail }}</text>
        </view>

        <!-- 操作按钮（仅待审核的申请显示） -->
        <view class="action" v-if="req.status === 0">
          <!-- 修复：传递apply_id -->
          <button @click="openApproveModal(req.apply_id, 1)" class="approve-btn">批准</button>
          <button @click="openApproveModal(req.apply_id, 2)" class="reject-btn">拒绝</button>
        </view>
        <!-- 已审核的显示状态 -->
        <view class="status" v-else>
          <text class="status-text" :class="req.status === 1 ? 'success' : 'fail'">
            {{ req.status === 1 ? '已批准' : '已拒绝' }}
          </text>
          <text class="audit-desc" v-if="req.dispatch_detail">
            审批意见：{{ req.dispatch_detail }}
          </text>
        </view>
      </view>
    </view>

    <!-- 审批弹窗（使用uni-popup，和灾情模块统一） -->
    <uni-popup ref="approveModal" type="center" background-color="rgba(0,0,0,0.5)">
      <view class="modal-content">
        <view class="modal-header">
          <text class="modal-title">{{ modalTitle }}</text>
          <text class="close" @click="closeModal">×</text>
        </view>
        <textarea 
          v-model="approvalResult" 
          placeholder="请填写审批意见（必填）..." 
          class="textarea"
        ></textarea>
        <view class="modal-footer">
          <button @click="closeModal" class="cancel-btn">取消</button>
          <button @click="submitApproval" class="confirm-btn">确认</button>
        </view>
      </view>
    </uni-popup>
  </view>
</template>

<script>
import { get, post } from '@/utils/request'
import uniPopup from '@dcloudio/uni-ui/lib/uni-popup/uni-popup.vue' // 修复：引入弹窗组件

export default {
  components: { uniPopup }, // 修复：注册弹窗组件
  data() {
    return {
      loading: false,
      requestList: [],
      currentRequestId: null,
      currentDecision: 1, // 1=批准 2=拒绝
      approvalResult: ''
    }
  },
  computed: {
    modalTitle() {
      return this.currentDecision === 1 ? '批准支援申请' : '拒绝支援申请'
    }
  },
  async mounted() {
    await this.loadRequests()
  },
  methods: {
    /**
     * 加载待审批申请列表（联表返回村庄名称）
     */
    async loadRequests() {
      this.loading = true
      try {
        // 修复：去掉 status=0 传参，直接请求 /help/admin/list（无参）
        const res = await get('/help/admin/list')
        this.requestList = res.data || []
      } catch (err) {
        console.error('加载申请列表失败：', err)
        uni.showToast({ title: '加载失败，请重试', icon: 'none' })
      } finally {
        this.loading = false
      }
    },

    /**
     * 格式化时间（适配下划线字段 submit_time）
     */
    formatTime(timeStr) {
      if (!timeStr) return '未知时间'
      // 兼容后端返回的时间格式（含T的情况）
      if (timeStr.includes('T')) {
        timeStr = timeStr.replace('T', ' ')
      }
      const date = new Date(timeStr)
      return `${date.getFullYear()}-${(date.getMonth()+1).toString().padStart(2, '0')}-${date.getDate().toString().padStart(2, '0')} ${date.getHours().toString().padStart(2, '0')}:${date.getMinutes().toString().padStart(2, '0')}`
    },

    /**
     * 打开审批弹窗
     */
    openApproveModal(id, decision) {
      this.currentRequestId = id
      this.currentDecision = decision
      this.approvalResult = ''
      this.$refs.approveModal.open()
    },

    /**
     * 关闭弹窗
     */
    closeModal() {
      this.$refs.approveModal.close()
    },

    /**
     * 提交审批结果（适配后端 /help/approve 接口）
     */
    async submitApproval() {
      // 表单校验
      if (!this.approvalResult.trim()) {
        uni.showToast({ title: '请填写审批意见', icon: 'none' })
        return
      }

      try {
        uni.showLoading({ title: '处理中...' })
        // 调用后端的 /help/approve 接口，参数对齐
        await post('/help/approve', {
          applyId: this.currentRequestId,
          approverId: 1, // 这里替换成实际的管理员ID（比如从登录信息里取）
          status: this.currentDecision,
          dispatchDetail: this.approvalResult.trim()
        })
        uni.showToast({ title: this.modalTitle + '成功', icon: 'success' })
        this.closeModal()
        await this.loadRequests() // 刷新列表
      } catch (err) {
        console.error('审批失败：', err)
        uni.showToast({ title: '操作失败，请重试', icon: 'none' })
      } finally {
        uni.hideLoading()
      }
    }
  }
}
</script>

<style scoped>
/* 整体容器 */
.support-container { 
  padding: 20rpx; 
  background-color: #f5f5f5;
  min-height: 100vh;
}

/* 标题 */
.header { 
  font-size: 36rpx; 
  font-weight: bold;
  margin-bottom: 30rpx; 
  color: #333; 
}

/* 加载/空数据提示 */
.loading, .empty {
  text-align: center;
  padding: 100rpx 0;
  color: #999;
  font-size: 28rpx;
}

/* 申请卡片列表 */
.list {
  gap: 20rpx;
}

/* 单个申请卡片 */
.request-card {
  background: #fff;
  padding: 30rpx;
  border-radius: 16rpx;
  margin-bottom: 20rpx;
  box-shadow: 0 2rpx 8rpx rgba(0,0,0,0.05);
}

/* 基础信息 */
.info { margin-bottom: 20rpx; }
.title { 
  font-weight: bold; 
  display: block; 
  font-size: 32rpx; 
  color: #333;
  margin-bottom: 8rpx;
}
.village, .time { 
  color: #666; 
  font-size: 28rpx; 
  display: block;
  margin-bottom: 4rpx;
}

/* 申请内容 */
.content { 
  margin: 20rpx 0; 
}
.label {
  font-weight: bold;
  font-size: 28rpx;
  color: #333;
}
.desc {
  font-size: 28rpx;
  color: #666;
  line-height: 1.6;
  margin-top: 8rpx;
  display: block;
}

/* 操作按钮 */
.action { 
  margin-top: 30rpx; 
  display: flex; 
  justify-content: space-between; 
  gap: 20rpx;
}
.approve-btn { 
  flex: 1;
  background: #52c41a; 
  color: white; 
  border: none;
  padding: 16rpx 0; 
  border-radius: 50rpx; 
  font-size: 28rpx;
}
.reject-btn { 
  flex: 1;
  background: #ff4d4f; 
  color: white; 
  border: none;
  padding: 16rpx 0; 
  border-radius: 50rpx; 
  font-size: 28rpx;
}

/* 已审核状态 */
.status {
  margin-top: 30rpx;
  padding: 10rpx;
  border-radius: 8rpx;
  background: #f5f5f5;
}
.status-text.success {
  color: #52c41a;
  font-size: 28rpx;
  font-weight: bold;
}
.status-text.fail {
  color: #ff4d4f;
  font-size: 28rpx;
  font-weight: bold;
}
.audit-desc {
  display: block;
  margin-top: 8rpx;
  font-size: 26rpx;
  color: #666;
}

/* 弹窗样式 */
.modal-content {
  width: 650rpx;
  background: #fff;
  border-radius: 16rpx;
  padding: 30rpx;
}
.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20rpx;
}
.modal-title {
  font-size: 32rpx;
  font-weight: bold;
  color: #333;
}
.close {
  font-size: 36rpx;
  color: #999;
  width: 60rpx;
  height: 60rpx;
  text-align: center;
  line-height: 60rpx;
}
.textarea {
  width: 100%;
  height: 200rpx;
  border: 1rpx solid #ddd;
  border-radius: 12rpx;
  padding: 20rpx;
  font-size: 28rpx;
  resize: none;
}
.modal-footer {
  display: flex;
  justify-content: space-between;
  margin-top: 30rpx;
  gap: 20rpx;
}
.cancel-btn {
  flex: 1;
  background: #f5f5f5;
  color: #333;
  border: none;
  border-radius: 50rpx;
  padding: 16rpx;
  font-size: 28rpx;
}
.confirm-btn {
  flex: 1;
  background: #1890ff;
  color: #fff;
  border: none;
  border-radius: 50rpx;
  padding: 16rpx;
  font-size: 28rpx;
}
</style>