<template>
  <view class="statistics-container">
    <view class="page-header">
      <text class="page-title">📊 灾情与预警统计</text>
      <text class="page-desc">实时统计灾情上报、风险提示与预警信息</text>
    </view>

    <!-- 灾情上报统计 -->
    <view class="section-card">
      <view class="section-title">📝 灾情上报统计</view>
      <view class="overview-row">
        <view class="overview-item">
          <text class="item-value">{{ reportOverview.totalCount || 0 }}</text>
          <text class="item-label">总上报数</text>
        </view>
      </view>

      <!-- 原生 ECharts 饼图容器（用 id 选择器） -->
      <view class="chart-wrapper">
        <text class="chart-title">状态分布（可视化）</text>
        <view class="echart-container" id="reportPieChart"></view>
      </view>

      <view class="chart-wrapper">
        <text class="chart-title">状态分布</text>
        <view class="status-list">
          <view 
            v-for="(item, index) in reportOverview.statusDistribution || []" 
            :key="item.status || index" 
            class="status-item"
          >
            <text class="status-name">{{ item.status_name || '未知' }}</text>
            <text class="status-count">{{ item.count || 0 }} 条</text>
          </view>
        </view>
      </view>
      <view class="chart-wrapper">
        <text class="chart-title">按村庄统计</text>
        <view class="village-list">
          <view 
            v-for="(item, index) in reportOverview.villageRank || []" 
            :key="item.village_name || index" 
            class="village-item"
          >
            <text class="village-name">{{ item.village_name || '未知村庄' }}</text>
            <text class="village-count">{{ item.report_count || 0 }} 条</text>
          </view>
        </view>
      </view>
    </view>

    <!-- 风险提示统计 -->
    <view class="section-card">
      <view class="section-title">⚠️ 风险提示统计</view>
      <view class="overview-row">
        <view class="overview-item">
          <text class="item-value">{{ tipOverview.totalCount || 0 }}</text>
          <text class="item-label">总发布数</text>
        </view>
      </view>

      <!-- 原生 ECharts 柱状图容器（用 id 选择器） -->
      <view class="chart-wrapper">
        <text class="chart-title">审核状态分布（可视化）</text>
        <view class="echart-container" id="tipBarChart"></view>
      </view>

      <view class="chart-wrapper">
        <text class="chart-title">审核状态分布</text>
        <view class="status-list">
          <view 
            v-for="(item, index) in tipOverview.reviewDistribution || []" 
            :key="item.status || index" 
            class="status-item"
          >
            <text class="status-name">{{ item.status_name || '未知' }}</text>
            <text class="status-count">{{ item.count || 0 }} 条</text>
          </view>
        </view>
      </view>
      <view class="chart-wrapper">
        <text class="chart-title">按村庄统计</text>
        <view class="village-list">
          <view 
            v-for="(item, index) in tipOverview.villageRank || []" 
            :key="item.village_name || index" 
            class="village-item"
          >
            <text class="village-name">{{ item.village_name || '未知村庄' }}</text>
            <text class="village-count">{{ item.tip_count || 0 }} 条</text>
          </view>
        </view>
      </view>
    </view>

    <!-- 预警与指令统计 -->
    <view class="section-card">
      <view class="section-title">🚨 预警与指令统计</view>
      <view class="overview-row">
        <view class="overview-item">
          <text class="item-value">{{ warningOverview.warningTotal || 0 }}</text>
          <text class="item-label">预警通知总数</text>
        </view>
        <view class="overview-item">
          <text class="item-value">{{ warningOverview.enabledWarning || 0 }}</text>
          <text class="item-label">已启用预警</text>
        </view>
      </view>
    </view>
  </view>
</template>

<script>
import { get } from '@/utils/request'
import * as echarts from 'echarts'

export default {
  data() {
    return {
      // 模拟数据兜底，保证页面有数据
      reportOverview: {
        totalCount: 9,
        statusDistribution: [
          { status_name: '待处理', count: 8 },
          { status_name: '处理中', count: 1 }
        ],
        villageRank: [
          { village_name: '李家坡村', report_count: 8 },
          { village_name: '平安村', report_count: 1 }
        ]
      },
      tipOverview: {
        totalCount: 18,
        reviewDistribution: [
          { status_name: '未知', count: 1 },
          { status_name: '待审核', count: 2 },
          { status_name: '已通过', count: 15 }
        ],
        villageRank: [
          { village_name: '李家坡村', tip_count: 15 },
          { village_name: '平安村', tip_count: 3 }
        ]
      },
      warningOverview: { warningTotal: 3, enabledWarning: 2 },
      reportPieChart: null,
      tipBarChart: null
    }
  },
  // 页面渲染完成后初始化图表
  onReady() {
    this.$nextTick(() => {
      this.initCharts()
    })
  },
  // 页面显示时调用接口更新数据
  onShow() {
    this.loadStatistics()
  },
  methods: {
    // 初始化图表（核心：id选择器+重试机制）
    initCharts() {
      // 用原生 id 选择器拿 DOM 节点
      const pieDom = document.getElementById('reportPieChart')
      const barDom = document.getElementById('tipBarChart')
      
      // 节点没加载完，重试
      if (!pieDom || !barDom) {
        console.log('DOM 节点未加载，100ms 后重试')
        setTimeout(() => this.initCharts(), 100)
        return
      }

      // 初始化图表实例
      this.reportPieChart = echarts.init(pieDom)
      this.tipBarChart = echarts.init(barDom)

      // 渲染饼图（高对比度颜色）
      this.reportPieChart.setOption({
        title: { text: '灾情状态分布', left: 'center', textStyle: { color: '#333', fontSize: 16 } },
        tooltip: { trigger: 'item', formatter: '{b}: {c} 条 ({d}%)' },
        legend: { orient: 'vertical', right: 10, textStyle: { color: '#333', fontSize: 14 } },
        series: [{
          name: '灾情状态',
          type: 'pie',
          radius: ['40%', '70%'],
          data: [
            { name: '待处理', value: 8 },
            { name: '处理中', value: 1 }
          ],
          // 橙+蓝：高对比度，绝对看得见
          itemStyle: { 
            color: (params) => {
              const colors = ['#FF4500', '#1E90FF']
              return colors[params.dataIndex] || '#999'
            }
          },
          // 文字标签黑色，保证可读性
          label: { 
            show: true, 
            textStyle: { color: '#000', fontSize: 14 },
            formatter: '{b}: {c}条'
          }
        }]
      })

      // 渲染柱状图（宝蓝色柱子）
      this.tipBarChart.setOption({
        title: { text: '风险提示审核状态', left: 'center', textStyle: { color: '#333', fontSize: 16 } },
        tooltip: { trigger: 'axis', formatter: '{b}: {c} 条' },
        xAxis: { 
          type: 'category', 
          data: ['未知', '待审核', '已通过'], 
          axisLabel: { color: '#333', fontSize: 14 } 
        },
        yAxis: { 
          type: 'value', 
          name: '数量', 
          axisLabel: { color: '#333', fontSize: 14 } 
        },
        series: [{
          name: '数量',
          type: 'bar',
          data: [1, 2, 15],
          // 宝蓝色柱子，超级显眼
          itemStyle: { color: '#1E90FF' },
          // 柱子顶部显示数值
          label: { 
            show: true, 
            position: 'top', 
            textStyle: { color: '#000', fontSize: 14 } 
          }
        }]
      })
    },
    // 接口请求：有数据就替换模拟数据
    async loadStatistics() {
      try {
        // 请求灾情数据
        const res1 = await get('/admin/statistics/report-overview')
        if (res1?.code === 200 && res1.data?.totalCount) {
          this.reportOverview = res1.data
          // 更新饼图数据
          this.reportPieChart?.setOption({
            series: [{
              data: this.reportOverview.statusDistribution.map(item => ({
                name: item.status_name || '未知',
                value: item.count || 0
              }))
            }]
          })
        }

        // 请求风险提示数据
        const res2 = await get('/admin/statistics/tip-overview')
        if (res2?.code === 200 && res2.data?.totalCount) {
          this.tipOverview = res2.data
          // 更新柱状图数据
          this.tipBarChart?.setOption({
            xAxis: { 
              data: this.tipOverview.reviewDistribution.map(item => item.status_name || '未知') 
            },
            series: [{ 
              data: this.tipOverview.reviewDistribution.map(item => item.count || 0) 
            }]
          })
        }

        // 请求预警数据
        const res3 = await get('/admin/statistics/warning-instruction-overview')
        if (res3?.code === 200) {
          this.warningOverview = res3.data
        }

        uni.showToast({ title: '数据加载成功', icon: 'success', duration: 1500 })
      } catch (err) {
        console.error('接口请求失败：', err)
        uni.showToast({ 
          title: '接口异常，显示模拟数据', 
          icon: 'none', 
          duration: 1500 
        })
      }
    }
  }
}
</script>

<style scoped>
/* 全局容器样式 */
.statistics-container {
  padding: 20rpx;
  background-color: #f5f7fa;
  min-height: 100vh;
}

/* 页面头部 */
.page-header {
  background: white;
  border-radius: 16rpx;
  padding: 30rpx;
  margin-bottom: 20rpx;
  text-align: center;
  box-shadow: 0 2rpx 12rpx rgba(0,0,0,0.05);
}
.page-title {
  font-size: 36rpx;
  font-weight: bold;
  color: #333;
  display: block;
  margin-bottom: 10rpx;
}
.page-desc {
  font-size: 26rpx;
  color: #999;
}

/* 卡片样式 */
.section-card {
  background: white;
  border-radius: 16rpx;
  padding: 30rpx;
  margin-bottom: 20rpx;
  box-shadow: 0 2rpx 12rpx rgba(0,0,0,0.05);
}
.section-title {
  font-size: 30rpx;
  font-weight: bold;
  color: #333;
  display: block;
  margin-bottom: 20rpx;
}

/* 统计数字行 */
.overview-row {
  display: flex;
  gap: 20rpx;
  margin-bottom: 20rpx;
}
.overview-item {
  flex: 1;
  background: #e8f4ff;
  border-radius: 12rpx;
  padding: 25rpx;
  text-align: center;
}
.item-value {
  font-size: 36rpx;
  font-weight: bold;
  color: #1890ff;
  display: block;
  margin-bottom: 8rpx;
}
.item-label {
  font-size: 24rpx;
  color: #666;
}

/* 图表区域 */
.chart-wrapper {
  margin-bottom: 20rpx;
}
.chart-title {
  font-size: 28rpx;
  color: #333;
  margin-bottom: 15rpx;
  display: block;
}
/* 图表容器：红色粗边框+浅蓝色背景，绝对显眼 */
.echart-container {
  width: 100%;
  height: 400rpx;
  margin-bottom: 20rpx;
  background-color: #f0f8ff;
  border: 3px solid #ff4500;
  border-radius: 12rpx;
}

/* 列表样式 */
.status-list, .village-list {
  display: flex;
  flex-direction: column;
  gap: 10rpx;
}
.status-item, .village-item {
  display: flex;
  justify-content: space-between;
  padding: 15rpx;
  background: #f8f9fa;
  border-radius: 8rpx;
}
.status-name, .village-name {
  font-size: 26rpx;
  color: #333;
}
.status-count, .village-count {
  font-size: 26rpx;
  color: #1890ff;
  font-weight: 500;
}
</style>