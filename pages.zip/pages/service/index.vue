<template>
  <view class="service-container">
    <!-- 未登录状态 -->
    <view v-if="!isLogin" class="unlogin-section">
      <view class="unlogin-icon">👤</view>
      <view class="unlogin-text">请先到「我的」页面登录</view>
      <view class="unlogin-desc">登录后可使用完整的服务功能</view>
      <button class="go-login-btn" @click="goMine">立即登录</button>
    </view>

    <!-- 已登录状态：按角色分栏 -->
    <view v-else class="service-content">
      <!-- 角色标签 -->
      <view class="role-tag" :class="getRoleClass(userInfo.role)">
        {{ getRoleText(userInfo.role) }}服务中心
      </view>

      <!-- 村民版服务（核心修改区） -->
      <view v-if="userInfo.role === 1" class="service-list">
        <view class="service-section">
          <text class="section-title">📝 核心上报</text>
          <view class="section-content">
            <view class="service-item" @click="goPage('/pages/report/form')">
              <text class="item-icon">📑</text>
              <text class="item-text">灾情上报</text>
            </view>
            <!-- 新增：历史灾情（查看自己上报的记录） -->
            <view class="service-item" @click="goPage('/pages/report/history-list')">
              <text class="item-icon">📜</text>
              <text class="item-text">历史灾情</text>
            </view>
          </view>
        </view>

        <view class="service-section">
          <text class="section-title">📚 信息查看</text>
          <view class="section-content">
            <view class="service-item" @click="goPage('/pages/warning/list')">
              <text class="item-icon">📢</text>
              <text class="item-text">预警通知</text>
            </view>
            <view class="service-item" @click="goPage('/pages/warning/instruction-list')">
              <text class="item-icon">🚨</text>
              <text class="item-text">应急指令</text>
            </view>
            <view class="service-item" @click="goPage('/pages/tip/list')">
              <text class="item-icon">⚠️</text>
              <text class="item-text">风险提示</text>
            </view>
            <view class="service-item" @click="goPage('/pages/guide/list')">
              <text class="item-icon">📖</text>
              <text class="item-text">防灾指南</text>
            </view>
            <!-- 修正：灾害类型科普跳转路径 -->
            <view class="service-item" @click="goPage('/pages/guide/disaster-type-list')">
              <text class="item-icon">ℹ️</text>
              <text class="item-text">灾害类型科普</text>
            </view>
          </view>
        </view>
      </view>

      <!-- 信息员版服务（保留原有所有功能，无修改） -->
      <view v-if="userInfo.role === 2" class="service-list">
        <view class="service-section">
          <text class="section-title">📢 发布管理</text>
          <view class="section-content">
            <view class="service-item" @click="goPage('/pages/tip/publish')">
              <text class="item-icon">📝</text>
              <text class="item-text">发布风险提示</text>
            </view>
            <view class="service-item" @click="goPage('/pages/warning/publish')">
              <text class="item-icon">📢</text>
              <text class="item-text">发布预警通知</text>
            </view>
          </view>
        </view>

        <view class="service-section">
          <text class="section-title">✅ 核实处理</text>
          <view class="section-content">
            <view class="service-item" @click="goPage('/pages/report/list')">
              <text class="item-icon">🔍</text>
              <text class="item-text">核实灾情上报</text>
            </view>
          </view>
        </view>
		
		 <!-- 新增：应急指令接收模块 -->
		  <view class="service-section">
		    <text class="section-title">🚨 应急指令</text>
		    <view class="section-content">
		      <view class="service-item" @click="goPage('/pages/warning/instruction-list')">
		        <text class="item-icon">📋</text>
		        <text class="item-text">接收应急指令</text>
		      </view>
		    </view>
		  </view>

        <view class="service-section">
          <text class="section-title">🆘 支援申请</text>
          <view class="section-content">
            <view class="service-item" @click="goPage('/pages/village/help-form')">
              <text class="item-icon">📞</text>
              <text class="item-text">请求上级支援</text>
            </view>
            <view class="service-item" @click="goPage('/pages/village/help-detail')">
              <text class="item-icon">📜</text>
              <text class="item-text">支援申请记录</text>
            </view>
          </view>
        </view>

        <view class="service-section">
          <text class="section-title">📊 数据查看</text>
          <view class="section-content">
            <view class="service-item" @click="goPage('/pages/village/list')">
              <text class="item-icon">📈</text>
              <text class="item-text">信息员工作台</text>
            </view>
          </view>
        </view>
      </view>

      <!-- 管理员版服务（保留原有所有功能，无修改） -->
      <view v-if="userInfo.role === 3" class="service-list">
        <view class="service-section">
          <text class="section-title">🖥️ 后台管理</text>
          <view class="section-content">
            <view class="service-item" @click="goPage('/pages/admin/index')">
              <text class="item-icon">⚙️</text>
              <text class="item-text">乡镇管理后台</text>
            </view>
          </view>
        </view>

        <view class="service-section">
          <text class="section-title">📋 指令管理</text>
          <view class="section-content">
            <view class="service-item" @click="goPage('/pages/warning/instruction-list')">
              <text class="item-icon">🚨</text>
              <text class="item-text">应急指令管理</text>
            </view>
          </view>
        </view>
      </view>
    </view>
  </view>
</template>

<script>
export default {
  data() {
    return {
      isLogin: false,    // 是否登录
      userInfo: {}       // 用户信息
    }
  },
  onShow() {
    // 刷新登录状态和角色信息
    this.checkLoginStatus()
    // 监听登录成功事件
    uni.$on('loginSuccess', () => {
      this.checkLoginStatus()
    })
  },
  onUnload() {
    // 移除事件监听，避免内存泄漏
    uni.$off('loginSuccess')
  },
  methods: {
    /** 检查登录状态 */
    checkLoginStatus() {
      const userInfo = uni.getStorageSync('userInfo') || {}
      this.isLogin = !!userInfo.userId
      this.userInfo = userInfo
    },

    /** 跳转到我的页面登录 */
    goMine() {
      uni.switchTab({ url: '/pages/mine/index' })
    },

    /** 通用页面跳转（新增：路径校验提示） */
    goPage(url) {
      // 简单校验路径，避免跳转错误
      if (!url || !url.startsWith('/pages/')) {
        uni.showToast({ title: '页面路径错误', icon: 'none' })
        return
      }
      uni.navigateTo({ url })
    },

    /** 获取角色文本 */
    getRoleText(role) {
      const roleMap = {
        1: '村民',
        2: '信息员',
        3: '乡镇管理员'
      }
      return roleMap[role] || '未知'
    },

    /** 获取角色样式类 */
    getRoleClass(role) {
      const classMap = {
        1: 'role-villager',
        2: 'role-informer',
        3: 'role-admin'
      }
      return classMap[role] || ''
    }
  }
}
</script>

<style scoped>
.service-container {
  padding: 20rpx;
  background-color: #f8f8f8;
  min-height: 100vh;
}

/* 未登录样式 */
.unlogin-section {
  text-align: center;
  padding-top: 150rpx;
}
.unlogin-icon {
  font-size: 100rpx;
  margin-bottom: 30rpx;
}
.unlogin-text {
  font-size: 32rpx;
  color: #333;
  margin-bottom: 10rpx;
}
.unlogin-desc {
  font-size: 26rpx;
  color: #999;
  margin-bottom: 40rpx;
}
.go-login-btn {
  background: #1890ff;
  color: white;
  padding: 20rpx 60rpx;
  border-radius: 8rpx;
  font-size: 28rpx;
}

/* 已登录样式 */
.role-tag {
  font-size: 32rpx;
  font-weight: bold;
  text-align: center;
  padding: 20rpx;
  border-radius: 16rpx;
  margin-bottom: 30rpx;
  color: white;
}
.role-villager {
  background-color: #52c41a;
}
.role-informer {
  background-color: #1890ff;
}
.role-admin {
  background-color: #ff4d4f;
}
.service-list {
  gap: 20rpx;
}
.service-section {
  background: white;
  border-radius: 16rpx;
  margin-bottom: 20rpx;
  box-shadow: 0 2rpx 8rpx rgba(0,0,0,0.05);
}
.section-title {
  font-size: 28rpx;
  font-weight: bold;
  color: #333;
  padding: 20rpx 30rpx;
  border-bottom: 1rpx solid #f0f0f0;
}
.section-content {
  display: flex;
  flex-wrap: wrap;
  padding: 20rpx;
  gap: 20rpx;
}
.service-item {
  width: calc(50% - 10rpx);
  background: #f8f8f8;
  border-radius: 12rpx;
  padding: 30rpx 20rpx;
  text-align: center;
  transition: transform 0.2s;
}
.service-item:active {
  transform: scale(0.98);
}
.item-icon {
  font-size: 48rpx;
  display: block;
  margin-bottom: 10rpx;
}
.item-text {
  font-size: 26rpx;
  color: #333;
}
</style>