<template>
  <view class="container">
    <input 
      v-model="formData.title" 
      placeholder="标题（如：村口危桥，请绕行）" 
      class="input" 
      maxlength="50"
    />
    <textarea 
      v-model="formData.content" 
      placeholder="详细描述风险情况" 
      class="textarea" 
      maxlength="500"
    />
    
    <!-- 增加加载状态，防止重复点击 -->
    <button 
      class="submit-btn" 
      @click="submit" 
      :loading="submitting"
      :disabled="submitting"
    >
      {{ submitting ? '发布中...' : '发布风险提示' }}
    </button>
  </view>
</template>

<script>
import { post } from '@/utils/request'

export default {
  data() {
    return {
      formData: {
        title: '',
        content: '',
        villageId: 101 // 临时写死，后续从路由获取
      },
      submitting: false // 新增：提交状态，防止重复点击
    }
  },
  onLoad(options) {
    // 修正：确保villageId是数字类型（后端表字段是BIGINT）
    this.formData.villageId = options.villageId ? Number(options.villageId) : 101
  },
  methods: {
    async submit() {
      // 1. 基础校验
      if (!this.formData.title.trim()) {
        uni.showToast({ title: '请输入标题', icon: 'none' }); return;
      }
      if (!this.formData.content.trim()) {
        uni.showToast({ title: '请输入内容', icon: 'none' }); return;
      }

      // 2. 标记提交状态，防止重复点击
      this.submitting = true

      try {
        // 3. 调用后端接口
        const res = await post('/tip/publish', this.formData)
        
        // 4. 正确判断响应（后端Result对象：code=200为成功）
        if (res && res.code === 200) {
          uni.showToast({ title: '发布成功', icon: 'success' })
          setTimeout(() => uni.navigateBack(), 1000)
        } else {
          // 后端返回失败（如code=500）
          uni.showToast({ title: res?.msg || '发布失败', icon: 'none' })
        }
      } catch (err) {
        // 5. 捕获网络错误/接口404/500等异常
        console.error('发布风险提示失败：', err)
        uni.showToast({ title: '网络异常，请重试', icon: 'none' })
      } finally {
        // 6. 无论成功/失败，都重置提交状态
        this.submitting = false
      }
    }
  }
}
</script>

<style scoped>
/* 样式复用 warning/publish.vue，优化体验 */
.container { 
  padding: 30rpx;
  background-color: #f8f9fa;
  min-height: 100vh;
}
.input { 
  border: 1px solid #ddd; 
  padding: 20rpx; 
  margin-bottom: 30rpx; 
  border-radius: 8rpx;
  font-size: 28rpx;
  height: 80rpx; /* 增加高度，输入更舒适 */
  box-sizing: border-box;
}
.textarea { 
  border: 1px solid #ddd; 
  padding: 20rpx; 
  height: 200rpx; 
  margin-bottom: 50rpx; 
  border-radius: 8rpx;
  font-size: 28rpx;
  line-height: 1.5; /* 行高优化 */
  box-sizing: border-box;
}
.submit-btn {
  background: #e64340;
  color: white;
  border: none;
  height: 80rpx;
  border-radius: 12rpx;
  font-size: 32rpx;
  width: 100%; /* 占满宽度，点击更方便 */
}
/* 禁用状态样式 */
.submit-btn:disabled {
  background: #ccc;
  color: #999;
}
</style>