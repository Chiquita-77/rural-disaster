<template>
  <!-- 根标签必须闭合，这是核心修复点 -->
  <view class="tip-list">
    <!-- 空数据 -->
    <view v-if="list.length === 0 && !loading" class="empty">暂无风险提示</view>
    <!-- 加载中 -->
    <view v-if="loading" class="empty">加载中...</view>
    <!-- 风险提示列表（核心：村民能看到所有信息员发布的） -->
    <view v-else class="tip-items">
      <view v-for="item in list" :key="item.tipId" class="tip-item">
        <text class="title">{{ item.title }}</text>
        <text class="time">发布时间：{{ formatTime(item.createTime) }}</text>
        <text class="content">{{ item.content }}</text>
      </view>
    </view>
  </view>
</template>

<script>
import { get } from '@/utils/request'
import { getCurrentVillageId } from '@/utils/auth'

export default {
  props: ['villageId'],
  data() {
    return {
      list: [],
      loading: false
    }
  },
  mounted() {
    this.loadTips()
  },
  methods: {
    async loadTips() {
      this.loading = true
      try {
        // 核心修复1：强制使用101（数据库匹配值），兜底避免villageId为空/错误
        const targetVillageId = this.villageId || getCurrentVillageId() || 101
        const params = {
          villageId:101 // 确保必传villageId，且值为101
        }
        // 调用村民端风险提示接口
        const res = await get('/tip/list', params)
        
        if (res.code === 200) {
          this.list = res.data || []
        } else {
          uni.showToast({ title: res.msg || '加载失败', icon: 'none' })
        }
      } catch (err) {
        console.error('加载风险提示失败：', err)
        // 新增：打印具体请求参数，方便排查
        console.error('请求参数：', { villageId: this.villageId || getCurrentVillageId() || 101 })
        uni.showToast({ title: '网络异常，加载失败', icon: 'none' })
      } finally {
        this.loading = false
      }
    },
    formatTime(time) {
      if (!time) return '未知时间'
      return time.includes('T') 
        ? time.replace('T', ' ').substring(0, 16) 
        : time.substring(0, 16)
    }
  }
}
</script>

<style scoped>
.tip-list {
  background: #fff;
  border-radius: 12rpx;
  padding: 20rpx;
  min-height: calc(100vh - 40rpx);
}
.empty {
  text-align: center;
  padding: 80rpx 0;
  color: #999;
  font-size: 28rpx;
}
.tip-items {
  width: 100%;
}
.tip-item {
  padding: 20rpx 0;
  border-bottom: 1px solid #f0f0f0;
}
.tip-item:last-child {
  border-bottom: none;
}
.title {
  font-size: 32rpx;
  font-weight: bold;
  color: #333;
  display: block;
  margin-bottom: 10rpx;
}
.time {
  font-size: 24rpx;
  color: #999;
  display: block;
  margin-bottom: 10rpx;
}
.content {
  font-size: 28rpx;
  color: #666;
  line-height: 1.5;
}
</style>