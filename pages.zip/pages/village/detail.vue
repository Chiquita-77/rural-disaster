<template>
  <view class="village-detail">
    <!-- 顶部返回栏 -->
    <view class="top-bar">
      <button class="back-btn" @click="goBack">← 返回</button>
      <text class="detail-title">村庄详情</text>
    </view>

    <!-- 村庄基础信息卡片 -->
    <view class="info-card">
      <view class="info-item">
        <text class="label">村庄名称：</text>
        <text class="value">{{ villageInfo.villageName || villageName }}</text>
      </view>
      <view class="info-item">
        <text class="label">所属区域：</text>
        <text class="value">{{ villageInfo.province || 'XX省' }}-{{ villageInfo.city || 'XX市' }}-{{ villageInfo.district || 'XX区/县' }}</text>
      </view>
      <view class="info-item">
        <text class="label">详细地址：</text>
        <text class="value">{{ villageInfo.address || '暂无' }}</text>
      </view>
      <view class="info-item">
        <text class="label">联系人：</text>
        <text class="value">{{ villageInfo.contactPerson || '暂无' }}</text>
      </view>
      <view class="info-item">
        <text class="label">联系电话：</text>
        <text class="value">{{ villageInfo.phone || '暂无' }}</text>
      </view>
    </view>

    <!-- 快捷功能入口 -->
    <view class="func-card">
      <text class="func-title">快捷操作</text>
      <view class="func-list">
        <view class="func-item" @click="goWarningList">
          <text class="func-icon">📢</text>
          <text class="func-text">预警通知</text>
        </view>
        <view class="func-item" @click="goTipList">
          <text class="func-icon">⚠️</text>
          <text class="func-text">风险提示</text>
        </view>
        <view class="func-item" @click="goReportForm">
          <text class="func-icon">📝</text>
          <text class="func-text">灾情上报</text>
        </view>
        <view class="func-item" @click="goShelterList">
          <text class="func-icon">🏠</text>
          <text class="func-text">避难所</text>
        </view>
      </view>
    </view>

    <!-- 村庄预警统计 -->
    <view class="stats-card">
      <text class="stats-title">预警统计</text>
      <view class="stats-grid">
        <view class="stats-item">
          <text class="stats-num">{{ warningStats.urgent }}</text>
          <text class="stats-desc">紧急预警</text>
        </view>
        <view class="stats-item">
          <text class="stats-num">{{ warningStats.serious }}</text>
          <text class="stats-desc">严重预警</text>
        </view>
        <view class="stats-item">
          <text class="stats-num">{{ warningStats.total }}</text>
          <text class="stats-desc">累计预警</text>
        </view>
      </view>
    </view>
  </view>
</template>

<script>
import { get } from '@/utils/request'

export default {
  data() {
    return {
      villageId: '',
      villageName: '',
      villageInfo: {},
      warningStats: { urgent: 0, serious: 0, total: 0 }
    }
  },
  async onLoad(options) {
    this.villageId = options.villageId || 1
    this.villageName = options.villageName || `第${this.villageId}村`
    this.loadVillageInfo()
    this.loadWarningStats()
  },
  methods: {
    async loadVillageInfo() {
      try {
        const res = await get('/village/getById', { villageId: this.villageId })
        this.villageInfo = res.data || {}
      } catch (err) {
        console.error('加载村庄信息失败：', err)
      }
    },

    async loadWarningStats() {
      try {
        const res = await get('/warning/stats', { villageId: this.villageId })
        this.warningStats = res.data || { urgent: 0, serious: 0, total: 0 }
      } catch (err) {
        console.error('加载预警统计失败：', err)
      }
    },

    /**
     * 核心修改：返回对应角色的首页
     * 请替换下面的「角色首页路径」为你项目里的真实路径！！！
     */
    goBack() {
      // 1. 获取当前登录用户的角色（从本地缓存获取，根据你项目实际修改）
      const userRole = uni.getStorageSync('userRole') || 'villager'
    
      // 2. 根据角色用 switchTab 跳转到对应 tabbar 首页
      switch (userRole) {
        case 'villager': // 村民端
          uni.switchTab({ url: '/pages/index/index' }) // 必须是 tabBar 页面
          break
        case 'village_admin': // 村级管理员端
          uni.switchTab({ url: '/pages/village/list' })
          break
        case 'town_admin': // 乡镇管理员端
          uni.switchTab({ url: '/pages/admin/index' })
          break
        default: // 兜底
          uni.switchTab({ url: '/pages/villager/index' })
      }
    },

    goWarningList() {
      uni.navigateTo({
        url: `/pages/village/list?villageId=${this.villageId}&villageName=${this.villageName}&activeTab=warning`
      })
    },

    goTipList() {
      uni.navigateTo({
        url: `/pages/village/list?villageId=${this.villageId}&villageName=${this.villageName}&activeTab=tip`
      })
    },

    goReportForm() {
      uni.navigateTo({
        url: `/pages/report/form?villageId=${this.villageId}&villageName=${this.villageName}`
      })
    },

    goShelterList() {
      uni.navigateTo({
        url: `/pages/shelter/list?villageId=${this.villageId}`
      })
    }
  }
}
</script>

<style scoped>
.village-detail {
  padding: 20rpx;
  background-color: #f5f5f5;
  min-height: 100vh;
}
.top-bar {
  display: flex;
  align-items: center;
  margin-bottom: 30rpx;
}
.back-btn {
  background: transparent;
  border: none;
  font-size: 28rpx;
  color: #333;
  padding: 0;
  margin-right: 20rpx;
}
.detail-title {
  font-size: 36rpx;
  font-weight: 700;
  color: #333;
  flex: 1;
  text-align: center;
  margin-right: 60rpx;
}
.info-card {
  background: #fff;
  border-radius: 20rpx;
  padding: 30rpx;
  margin-bottom: 30rpx;
  box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.05);
}
.info-item {
  display: flex;
  margin-bottom: 20rpx;
  font-size: 28rpx;
}
.info-item:last-child {
  margin-bottom: 0;
}
.label {
  color: #666;
  width: 120rpx;
}
.value {
  color: #333;
  flex: 1;
}
.func-card {
  background: #fff;
  border-radius: 20rpx;
  padding: 30rpx;
  margin-bottom: 30rpx;
  box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.05);
}
.func-title {
  font-size: 32rpx;
  font-weight: 700;
  color: #333;
  margin-bottom: 20rpx;
  display: block;
}
.func-list {
  display: flex;
  flex-wrap: wrap;
  gap: 20rpx;
}
.func-item {
  width: calc(25% - 15rpx);
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 20rpx 0;
}
.func-icon {
  font-size: 40rpx;
  margin-bottom: 10rpx;
}
.func-text {
  font-size: 24rpx;
  color: #666;
}
.stats-card {
  background: #fff;
  border-radius: 20rpx;
  padding: 30rpx;
  box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.05);
}
.stats-title {
  font-size: 32rpx;
  font-weight: 700;
  color: #333;
  margin-bottom: 20rpx;
  display: block;
}
.stats-grid {
  display: flex;
  justify-content: space-around;
}
.stats-item {
  text-align: center;
}
.stats-num {
  font-size: 48rpx;
  font-weight: 700;
  color: #e64340;
  display: block;
}
.stats-desc {
  font-size: 24rpx;
  color: #666;
  margin-top: 10rpx;
}
</style>