<template>
  <view class="form-container">
    <view class="page-header">
      <button class="back-btn" @click="goBack">← 返回</button>
      <text class="page-title">提交请求支援</text>
    </view>

    <form class="help-form">
      <!-- 申请标题 -->
      <view class="form-item">
        <text class="form-label">申请标题 <text class="required">*</text></text>
        <input 
          v-model="form.title" 
          class="form-input" 
          placeholder="请输入支援申请标题（如：暴雨灾害物资支援）"
        />
      </view>

      <!-- 申请详情 -->
      <view class="form-item">
        <text class="form-label">申请详情 <text class="required">*</text></text>
        <textarea 
          v-model="form.detail" 
          class="form-textarea" 
          placeholder="请详细描述灾情情况、所需支援（人员/物资）、数量等"
          rows="5"
        />
      </view>

      <!-- 提交按钮 -->
      <button class="submit-btn" @click="submitForm" :disabled="!isValid">提交申请</button>
    </form>
  </view>
</template>

<script>
import { post } from '@/utils/request'
import { getUserInfo } from '@/utils/auth'

export default {
  data() {
    return {
      villageId: '',
      form: {
        title: '',
        detail: '',
        applicantId: 0,
        villageId: 0,
        status: 0
      }
    }
  },
  onLoad(options) {
    // 从页面参数获取村庄ID（服务页传递过来的）
    this.villageId = Number(options.villageId) || 1
    this.form.applicantId = getUserInfo().id || 1
    this.form.villageId = this.villageId
  },
  computed: {
    isValid() {
      return this.form.title.trim() && this.form.detail.trim()
    }
  },
  methods: {
    // 返回服务页（直接跳转到服务页，不是返回上一页）
    goBack() {
      uni.redirectTo({
        url: '/pages/village/service' // 替换为你的服务页实际路径
      })
    },

    async submitForm() {
      if (!this.form.title || !this.form.detail) {
        return uni.showToast({ title: '请填写必填项', icon: 'none' })
      }
      try {
        // 提交申请到后端
        const res = await post('/help/submit', {
          villageId: this.villageId,
          applicantId: this.form.applicantId,
          title: this.form.title,
          detail: this.form.detail,
          status: 0
        })
        // 提交成功提示
        uni.showToast({ title: '提交成功', icon: 'success', duration: 1500 })
        // 核心逻辑：提交成功后跳转到详情页，并传递villageId
        setTimeout(() => {
          uni.redirectTo({
            url: `/pages/village/help-detail?villageId=${this.villageId}`
          })
        }, 1500)
      } catch (err) {
        console.error('提交失败：', err)
        uni.showToast({ title: '提交失败', icon: 'none' })
      }
    }
  }
}
</script>

<style scoped>
.form-container {
  background-color: #f5f5f5;
  min-height: 100vh;
}
.page-header {
  display: flex;
  align-items: center;
  padding: 20rpx 30rpx;
  background: #fff;
  box-shadow: 0 2rpx 10rpx rgba(0,0,0,0.05);
}
.back-btn {
  background: none;
  border: none;
  font-size: 28rpx;
  color: #007aff;
  padding: 10rpx;
}
.page-title {
  font-size: 32rpx;
  font-weight: 700;
  color: #333;
  margin-left: 20rpx;
}
.help-form {
  padding: 30rpx;
}
.form-item {
  background: #fff;
  border-radius: 16rpx;
  padding: 25rpx;
  margin-bottom: 20rpx;
  box-shadow: 0 2rpx 8rpx rgba(0,0,0,0.03);
}
.form-label {
  display: block;
  font-size: 28rpx;
  color: #333;
  margin-bottom: 15rpx;
}
.required {
  color: #ff3b30;
}
.form-input, .form-textarea {
  width: 100%;
  font-size: 28rpx;
  color: #666;
  border: none;
  outline: none;
}
.form-textarea {
  resize: none;
  padding-top: 10rpx;
}
.submit-btn {
  width: 100%;
  height: 80rpx;
  background: #007aff;
  color: #fff;
  border: none;
  border-radius: 40rpx;
  font-size: 32rpx;
  font-weight: 500;
  margin-top: 20rpx;
}
.submit-btn:disabled {
  background: #ccc;
  color: #fff;
}
</style>