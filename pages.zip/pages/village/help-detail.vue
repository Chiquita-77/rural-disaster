<template>
  <view class="detail-container">
    <!-- 页面标题栏 -->
    <view class="page-header">
      <button class="back-btn" @click="goBackToService">← 返回</button>
      <text class="page-title">请求支援详情</text>
      <view class="empty-btn"></view>
    </view>

    <!-- 加载状态 -->
    <view v-if="loading" class="loading">加载详情中...</view>

    <!-- 详情内容区 -->
    <view v-else class="detail-content">
      <!-- 无数据提示 -->
      <view v-if="isEmpty" class="empty-container">
        <text class="empty-text">暂无支援申请数据</text>
        <button class="create-btn" @click="goCreateHelp">+ 发起新的支援申请</button>
      </view>

      <!-- 有数据时显示 -->
      <view v-else>
        <!-- 支援申请基础信息卡片 -->
        <view class="base-card">
          <view class="base-item">
            <text class="label">申请村庄：</text>
            <text class="value">{{ villageName }}</text>
          </view>
          <view class="base-item">
            <text class="label">申请人ID：</text>
            <text class="value">{{ helpInfo.applicantId || '暂未填写' }}</text>
          </view>
          <view class="base-item">
            <text class="label">申请时间：</text>
            <text class="value">{{ formatTime(helpInfo.submitTime) }}</text>
          </view>
          <view class="base-item">
            <text class="label">申请状态：</text>
            <view class="status-tag" :class="getStatusClass(helpInfo.status)">
              {{ getStatusText(helpInfo.status) }}
            </view>
          </view>
        </view>

        <!-- 申请详情 -->
        <view class="detail-card">
          <text class="card-title">申请标题</text>
          <text class="detail-text">{{ helpInfo.title || '暂无标题' }}</text>
        </view>

        <view class="detail-card">
          <text class="card-title">申请事由</text>
          <text class="detail-text">{{ helpInfo.detail || '暂无申请详情' }}</text>
        </view>

        <!-- 审核信息（有审核记录时显示） -->
        <view v-if="helpInfo.status !== 0" class="audit-card">
          <text class="card-title">审核信息</text>
          <view class="audit-item">
            <text class="label">审核人ID：</text>
            <text class="value">{{ helpInfo.approverId || '未知' }}</text>
          </view>
          <view class="audit-item">
            <text class="label">审核时间：</text>
            <text class="value">{{ formatTime(helpInfo.handleTime) }}</text>
          </view>
          <view class="audit-item">
            <text class="label">审核备注：</text>
            <text class="value">{{ helpInfo.dispatchDetail || '无' }}</text>
          </view>
        </view>
      </view>
    </view>
  </view>
</template>

<script>
import { get } from '@/utils/request'

export default {
  data() {
    return {
      loading: true,
      villageId: '',
      villageName: '',
      helpInfo: {}, // 支援申请详情数据
      isEmpty: false // 是否无数据
    }
  },
  async onLoad(options) {
    // 获取从提交页传递的村庄ID
    this.villageId = Number(options.villageId) || 1
    this.villageName = `第${this.villageId}村`
    // 加载详情数据
    await this.loadHelpDetail()
  },
  methods: {
    // 核心逻辑：返回服务页（不是返回上一页）
    goBackToService() {
      uni.switchTab({
        url: '/pages/service/index' // 替换为你的服务页实际路径
      })
    },

    // 加载支援申请详情
    async loadHelpDetail() {
      try {
        // 调用后端接口获取最新的申请详情
        const res = await get('/help/list', { villageId: this.villageId })
        if (res.code === 200 && res.data.length > 0) {
          // 取最新的一条申请数据
          this.helpInfo = res.data[0]
          this.isEmpty = false
        } else {
          this.isEmpty = true
        }
      } catch (err) {
        uni.showToast({ title: '加载详情失败', icon: 'none' })
        console.error('加载支援详情异常：', err)
        this.isEmpty = true
      } finally {
        this.loading = false
      }
    },

    // 跳转到提交申请页
    goCreateHelp() {
      uni.redirectTo({
        url: `/pages/village/help-form?villageId=${this.villageId}`
      })
    },

    // 状态样式
    getStatusClass(status) {
      switch (status) {
        case 0: return 'pending';
        case 1: return 'passed';
        case 2: return 'rejected';
        default: return 'pending';
      }
    },

    // 状态文字
    getStatusText(status) {
      const statusMap = { 0: '待审核', 1: '已通过', 2: '已驳回' }
      return statusMap[status] || '未知状态'
    },

    // 时间格式化
    formatTime(t) {
      if (!t) return '未知时间'
      return t.includes('T') ? t.replace('T', ' ').substring(0, 16) : t.substring(0, 16)
    }
  }
}
</script>

<style scoped>
/* 页面整体样式 */
.detail-container {
  background-color: #f5f5f5;
  min-height: 100vh;
}

/* 标题栏 */
.page-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 20rpx 30rpx;
  background-color: #fff;
  box-shadow: 0 2rpx 10rpx rgba(0,0,0,0.05);
}
.back-btn {
  background: none;
  border: none;
  font-size: 28rpx;
  color: #007aff;
  padding: 10rpx;
}
.page-title {
  font-size: 32rpx;
  font-weight: 700;
  color: #333;
}
.empty-btn {
  width: 80rpx;
}

/* 加载状态 */
.loading {
  text-align: center;
  padding: 100rpx 0;
  font-size: 28rpx;
  color: #999;
}

/* 详情内容区 */
.detail-content {
  padding: 20rpx 30rpx;
}

/* 基础信息卡片 */
.base-card {
  background: #fff;
  border-radius: 20rpx;
  padding: 30rpx;
  margin-bottom: 20rpx;
  box-shadow: 0 2rpx 10rpx rgba(0,0,0,0.05);
}
.base-item {
  display: flex;
  align-items: center;
  margin-bottom: 20rpx;
  font-size: 28rpx;
}
.base-item:last-child {
  margin-bottom: 0;
}
.label {
  color: #666;
  width: 180rpx;
  flex-shrink: 0;
}
.value {
  color: #333;
  flex: 1;
}
.status-tag {
  padding: 6rpx 20rpx;
  border-radius: 20rpx;
  font-size: 24rpx;
  color: #fff;
  font-weight: 500;
}
.status-tag.pending { background: #ffcc00; }
.status-tag.passed { background: #34c759; }
.status-tag.rejected { background: #ff3b30; }

/* 详情卡片 */
.detail-card, .audit-card {
  background: #fff;
  border-radius: 20rpx;
  padding: 30rpx;
  margin-bottom: 20rpx;
  box-shadow: 0 2rpx 10rpx rgba(0,0,0,0.05);
}
.card-title {
  display: block;
  font-size: 30rpx;
  font-weight: 700;
  color: #333;
  margin-bottom: 20rpx;
  padding-left: 10rpx;
  border-left: 4rpx solid #007aff;
}
.detail-text {
  font-size: 28rpx;
  color: #666;
  line-height: 1.8;
}

/* 审核信息 */
.audit-item {
  display: flex;
  margin-bottom: 15rpx;
  font-size: 28rpx;
}
.audit-item:last-child {
  margin-bottom: 0;
}

/* 无数据样式 */
.empty-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 100rpx 0;
}
.empty-text {
  font-size: 28rpx;
  color: #999;
  margin-bottom: 30rpx;
}
.create-btn {
  background: #007aff;
  color: #fff;
  border: none;
  border-radius: 30rpx;
  padding: 15rpx 40rpx;
  font-size: 28rpx;
}
</style>