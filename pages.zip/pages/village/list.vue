<template>
  <view class="container">
    <!-- 顶部导航：村庄名称 + 功能按钮组 -->
    <view class="header">
      <text class="village-name">{{ villageName }}</text>
      <view class="header-btns">
        <button class="report-btn" @click="goReport">上报灾情</button>
        <button class="verify-btn" @click="goReportList">核实灾情</button>
        <button class="publish-btn" @click="goPublish">发布预警</button>
        <button class="tip-btn" @click="goPublishTip">发布风险提示</button>
      </view>
    </view>

    <!-- 统计卡片 -->
    <view class="stats-card">
      <view class="stats-item">
        <text class="icon">🔴</text>
        <text class="label">紧急：{{ stats.urgentCount }}条</text>
      </view>
      <view class="stats-item">
        <text class="icon">🟠</text>
        <text class="label">严重：{{ stats.seriousCount }}条</text>
      </view>
      <view class="stats-item">
        <text class="icon">🟢</text>
        <text class="label">今日新增：{{ stats.todayAddCount }}条</text>
      </view>
    </view>

    <!-- 防灾避险指南卡片 -->
    <view class="card" @click="goGuide">
      <text class="card-title">📘 防灾避险指南</text>
      <text class="card-desc">学习应急知识，提高自救能力</text>
    </view>

    <!-- Tab 切换栏：请求支援 -->
    <view class="tabs">
      <view 
        v-for="tab in tabs" 
        :key="tab.key"
        :class="{ active: currentTab === tab.key }"
        @click="switchTab(tab.key)"
      >
        {{ tab.label }}
      </view>
    </view>

    <!-- 内容区 -->
    <view class="content">
      <!-- 加载状态 -->
      <view v-if="loading" class="loading">加载中...</view>

      <!-- 预警通知 Tab -->
      <view v-else-if="currentTab === 'warning'">
        <view v-if="warningList.length === 0" class="empty-container">
          <text class="empty-text">暂无生效预警信息</text>
        </view>
        <view v-else class="warning-list">
          <view
            v-for="item in warningList"
            :key="item.warningId"
            class="warning-card"
            @click="goDetail(item)"
          >
            <view class="tag-group">
              <view class="level-tag" :class="`level-${item.level}`">
                {{ getLevelText(item.level) }}
              </view>
              <view class="status-tag" :class="item.status === 1 ? 'status-valid' : 'status-invalid'">
                {{ item.status === 1 ? '生效中' : '已解除' }}
              </view>
            </view>
            <text class="warning-title">{{ item.title }}</text>
            <text class="publish-time">{{ formatTime(item.publishTime) }}</text>
          </view>
        </view>
      </view>

      <!-- 风险提示 Tab -->
      <view v-else-if="currentTab === 'tip'">
        <tip-list :village-id="villageId" ref="tipListRef" />
        <button 
          class="float-btn publish-tip-btn" 
          @click="goPublishTip"
        >+ 发布风险提示</button>
      </view>

      <!-- 请求支援 Tab -->
      <view v-else-if="currentTab === 'report'">
        <!-- 加载中 -->
        <view v-if="helpLoading" class="loading">加载支援记录中...</view>
        
        <!-- 无记录 -->
        <view v-else-if="helpList.length === 0" class="empty-container">
          <text class="empty-text">暂无请求支援记录</text>
        </view>
        
        <!-- 支援记录列表 -->
        <view v-else class="help-list">
          <view
            v-for="item in helpList"
            :key="item.applyId"
            class="help-card"
          >
            <view class="help-header">
              <text class="help-title">{{ item.title }}</text>
              <view class="audit-tag" :class="getAuditClass(item.status)">
                {{ getAuditText(item.status) }}
              </view>
            </view>
            <text class="help-content">{{ item.detail }}</text>
            <view class="help-footer">
              <text class="create-time">申请时间：{{ formatTime(item.submitTime) }}</text>
              <text v-if="item.handleTime" class="audit-time">审核时间：{{ formatTime(item.handleTime) }}</text>
            </view>
            <text v-if="item.dispatchDetail" class="audit-comment">审核备注：{{ item.dispatchDetail }}</text>
          </view>
        </view>

        <!-- 核心修改：仅保留「请求支援」圆形按钮，点击跳转help-detail页面 -->
        <button 
          class="float-btn help-btn" 
          @click="goToHelpDetail"
        >📞 请求支援</button>
      </view>
    </view>
  </view>
</template>

<script>
import { get, post } from '@/utils/request'
import { getUserInfo } from '@/utils/auth'
import TipList from '@/pages/tip/list.vue'

export default {
  components: { TipList },
  data() {
    return {
      userInfo: {},
      villageId: '',
      villageName: '',
      warningList: [],
      helpList: [],
      stats: { urgentCount: 0, seriousCount: 0, todayAddCount: 0 },
      currentTab: 'warning',
      loading: false,
      helpLoading: false,
      tabs: [
        { key: 'warning', label: '预警通知' },
        { key: 'tip', label: '风险提示' },
        { key: 'report', label: '请求支援' }
      ]
    }
  },
  async onLoad(options) {
    this.userInfo = getUserInfo()
    this.villageId = Number(options.villageId) || Number(this.userInfo.villageId) || 1
    this.villageName = options.villageName || `第${this.villageId}村`
    this.currentTab = options.activeTab || 'warning'
    
    if (!this.villageId) {
      uni.showToast({ title: '村庄信息缺失', icon: 'none' })
      uni.navigateBack()
      return
    }
    
    await this.loadWarnings()
    if (this.currentTab === 'report') {
      await this.loadHelpList()
    }
  },
  onPullDownRefresh() {
    if (this.currentTab === 'warning') {
      this.loadWarnings().finally(() => uni.stopPullDownRefresh())
    } else if (this.currentTab === 'report') {
      this.loadHelpList().finally(() => uni.stopPullDownRefresh())
    } else {
      uni.stopPullDownRefresh()
    }
  },
  computed: {
    isVillageAdmin() {
      return this.userInfo.role === 2
    }
  },
  methods: {
    async loadWarnings() {
      this.loading = true
      try {
        const res = await get('/warning/list', {
          villageId: this.villageId,
          status: 1,
          pageNum: 1,
          pageSize: 20
        })
        const pageData = res?.data || {}
        this.warningList = Array.isArray(pageData.records) ? pageData.records : []
        
        this.stats = {
          urgentCount: this.warningList.filter(i => i.level === 1).length,
          seriousCount: this.warningList.filter(i => i.level === 2).length,
          todayAddCount: 0
        }
      } catch (err) {
        uni.showToast({ title: '预警加载失败', icon: 'none', duration: 2000 })
        console.error('预警加载异常：', err)
        this.warningList = []
      } finally {
        this.loading = false
      }
    },

    async loadHelpList() {
      this.helpLoading = true
      try {
        const res = await get('/help/list', {
          villageId: this.villageId
        })
        this.helpList = res.code === 200 ? (Array.isArray(res.data) ? res.data : []) : []
      } catch (err) {
        uni.showToast({ title: '支援记录加载失败', icon: 'none' })
        console.error('支援记录加载异常：', err)
        this.helpList = []
      } finally {
        this.helpLoading = false
      }
    },

    // 新增：点击圆形按钮跳转help-detail页面
    goToHelpDetail() {
      // 跳转至village目录下的help-detail页面，传递村庄ID
      uni.navigateTo({
        url: `/pages/village/help-form?villageId=${this.villageId}`
      })
    },

    getAuditClass(status) {
      switch (status) {
        case 0: return 'pending';
        case 1: return 'passed';
        case 2: return 'rejected';
        default: return 'pending';
      }
    },

    getAuditText(status) {
      const statusMap = { 0: '待审核', 1: '已通过', 2: '已驳回' }
      return statusMap[status] || '待审核'
    },

    switchTab(tabKey) {
      this.currentTab = tabKey
      this.refreshTabData()
    },
    refreshTabData() {
      if (this.currentTab === 'tip' && this.$refs.tipListRef) {
        this.$refs.tipListRef.loadTips()
      }
      if (this.currentTab === 'report') {
        this.loadHelpList()
      }
    },
    goPublish() {
      uni.navigateTo({
        url: `/pages/auth/village-verify?villageId=${this.villageId}&villageName=${this.villageName}`
      })
    },
    goReport() {
      uni.navigateTo({
        url: `/pages/report/form?villageId=${this.villageId}&villageName=${this.villageName}`
      })
    },
    goGuide() {
      uni.navigateTo({ url: '/pages/guide/list' })
    },
    goReportList() {
      uni.navigateTo({
        url: `/pages/report/list?villageId=${this.villageId}`
      })
    },
    goDetail(item) {
      uni.navigateTo({
        url: `/pages/warning/detail?id=${item.warningId}&villageId=${this.villageId}`
      })
    },
    goPublishTip() {
      uni.navigateTo({
        url: `/pages/tip/publish?villageId=${this.villageId}`,
        events: {
          refreshTip: () => this.refreshTabData()
        }
      })
    },
    getLevelText(level) {
      const levelMap = { 1: '紧急', 2: '严重', 3: '较重', 4: '一般' }
      return levelMap[level] || '未知'
    },
    formatTime(t) {
      if (!t) return '未知时间'
      return t.includes('T') ? t.replace('T', ' ').substring(0, 16) : t.substring(0, 16)
    }
  }
}
</script>

<style scoped>
.container {
  padding: 20rpx;
  background-color: #f5f5f5;
  min-height: 100vh;
}
.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 30rpx;
  padding: 10rpx 0;
  flex-wrap: wrap;
}
.header-btns {
  display: flex;
  gap: 10rpx;
  flex-wrap: wrap;
}
.village-name {
  font-size: 36rpx;
  font-weight: 700;
  color: #333;
  width: 100%;
  margin-bottom: 15rpx;
}
.report-btn {
  background-color: #007aff;
  color: #fff;
  width: 180rpx;
  height: 60rpx;
  font-size: 28rpx;
  border-radius: 30rpx;
  border: none;
}
.verify-btn {
  background-color: #5856d6;
  color: #fff;
  width: 180rpx;
  height: 60rpx;
  font-size: 28rpx;
  border-radius: 30rpx;
  border: none;
}
.publish-btn {
  background-color: #e64340;
  color: #fff;
  width: 180rpx;
  height: 60rpx;
  font-size: 28rpx;
  border-radius: 30rpx;
  border: none;
}
.tip-btn {
  background-color: #ff9500;
  color: #fff;
  width: 180rpx;
  height: 60rpx;
  font-size: 28rpx;
  border-radius: 30rpx;
  border: none;
}
.stats-card {
  background: #fff;
  border-radius: 20rpx;
  padding: 30rpx;
  margin-bottom: 30rpx;
  display: flex;
  justify-content: space-between;
}
.stats-item {
  display: flex;
  align-items: center;
  font-size: 26rpx;
  color: #666;
}
.icon {
  margin-right: 8rpx;
}
.card {
  background: #fff;
  border-radius: 20rpx;
  padding: 30rpx;
  margin-bottom: 30rpx;
  box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.05);
}
.card-title {
  display: block;
  font-size: 32rpx;
  font-weight: 700;
  color: #333;
  margin-bottom: 10rpx;
}
.card-desc {
  font-size: 26rpx;
  color: #666;
}
.tabs {
  display: flex;
  background: white;
  border-bottom: 1px solid #eee;
  margin-bottom: 20rpx;
}
.tabs > view {
  flex: 1;
  text-align: center;
  padding: 20rpx 0;
  font-size: 30rpx;
  color: #666;
  position: relative;
}
.tabs .active {
  color: #e64340;
  font-weight: bold;
}
.tabs .active::after {
  content: '';
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 60rpx;
  height: 4rpx;
  background-color: #e64340;
  border-radius: 2rpx;
}
.content {
  padding-bottom: 120rpx;
}
.loading {
  text-align: center;
  padding: 80rpx 0;
  color: #999;
  font-size: 28rpx;
}
.empty-container {
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 100rpx 0;
}
.empty-text {
  font-size: 28rpx;
  color: #999;
}
.warning-list {
  display: flex;
  flex-direction: column;
  gap: 20rpx;
}
.warning-card {
  background-color: #fff;
  border-radius: 20rpx;
  padding: 30rpx;
  box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.05);
}
.tag-group {
  display: flex;
  gap: 10rpx;
  margin-bottom: 20rpx;
}
.level-tag {
  padding: 4rpx 16rpx;
  border-radius: 16rpx;
  font-size: 22rpx;
  color: #fff;
  font-weight: 500;
}
.level-1 { background-color: #ff3b30; }
.level-2 { background-color: #ff9500; }
.level-3 { background-color: #ffcc00; }
.level-4 { background-color: #34c759; }
.status-tag {
  padding: 4rpx 16rpx;
  border-radius: 16rpx;
  font-size: 22rpx;
  font-weight: 500;
}
.status-valid { color: #34c759; background-color: #e8f5e9; }
.status-invalid { color: #999; background-color: #f5f5f5; }
.warning-title {
  display: block;
  font-size: 32rpx;
  font-weight: 700;
  color: #333;
  margin-bottom: 16rpx;
  line-height: 1.4;
}
.publish-time {
  font-size: 24rpx;
  color: #999;
}

/* 悬浮圆形按钮：统一为请求支援样式，位置向上移到100rpx */
.float-btn {
  position: fixed;
  bottom: 100rpx;
  right: 30rpx;
  width: 100rpx;
  height: 100rpx;
  border-radius: 50%;
  color: white;
  font-size: 22rpx;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 4rpx 12rpx rgba(0,0,0,0.2);
  border: none;
  line-height: 1.2;
}
.publish-tip-btn { background: #e64340; }
.help-btn { background: #007aff; }

.help-list {
  display: flex;
  flex-direction: column;
  gap: 20rpx;
}
.help-card {
  background: #fff;
  border-radius: 20rpx;
  padding: 30rpx;
  box-shadow: 0 2rpx 10rpx rgba(0,0,0,0.05);
}
.help-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 15rpx;
}
.help-title {
  font-size: 32rpx;
  font-weight: 700;
  color: #333;
}
.audit-tag {
  padding: 4rpx 16rpx;
  border-radius: 16rpx;
  font-size: 22rpx;
  font-weight: 500;
}
.audit-tag.pending {
  background: #ffcc00;
  color: #fff;
}
.audit-tag.passed {
  background: #34c759;
  color: #fff;
}
.audit-tag.rejected {
  background: #ff3b30;
  color: #fff;
}
.help-content {
  font-size: 28rpx;
  color: #666;
  line-height: 1.5;
  margin-bottom: 15rpx;
  display: block;
}
.help-footer {
  display: flex;
  justify-content: space-between;
  font-size: 24rpx;
  color: #999;
  margin-bottom: 10rpx;
}
.audit-comment {
  font-size: 24rpx;
  color: #666;
  padding-top: 10rpx;
  border-top: 1px solid #f0f0f0;
}

@media (max-width: 750rpx) {
  .header-btns {
    justify-content: flex-start;
  }
  .report-btn, .verify-btn, .publish-btn, .tip-btn {
    width: 160rpx;
    font-size: 26rpx;
  }
  .float-btn {
    width: 80rpx;
    height: 80rpx;
    font-size: 20rpx;
  }
}
</style>