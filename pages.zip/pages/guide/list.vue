<template>
  <view class="guide-list">
    <!-- 顶部导航 -->
    <view class="header-bar">
      <text class="title">防灾指南</text>
    </view>

    <!-- 分类筛选 -->
    <view class="category-filter">
      <scroll-view scroll-x class="filter-scroll">
        <view 
          class="filter-item" 
          :class="{ active: selectedCategory === item }"
          v-for="item in categoryList" 
          :key="item"
          @click="selectCategory(item)"
        >
          <text>{{ item }}</text>
        </view>
      </scroll-view>
    </view>

    <!-- 指南列表 -->
    <view class="guide-card-list">
      <view 
        class="guide-card" 
        v-for="item in guideList" 
        :key="item.id"
        @click="goDetail(item.id)"
      >
        <!-- 封面图（本地图片） -->
        <view class="card-cover">
          <image :src="item.coverImage" mode="aspectFill" lazy-load></image>
        </view>
        <!-- 指南信息 -->
        <view class="card-info">
          <text class="guide-title">{{ item.title }}</text>
          <text class="guide-category">{{ item.category }}</text>
        </view>
      </view>
    </view>

    <!-- 空数据提示 -->
    <view v-if="guideList.length === 0" class="empty-tip">
      <text>暂无相关防灾指南</text>
    </view>
  </view>
</template>

<script>
import { get } from '@/utils/request'

export default {
  data() {
    return {
      guideList: [], // 防灾指南列表
      categoryList: ['全部', '暴雨', '山体滑坡', '洪水', '地震'], // 分类列表
      selectedCategory: '全部' // 当前选中分类
    }
  },
  onLoad() {
    this.loadGuideList()
  },
  methods: {
    /** 加载防灾指南列表（支持分类筛选） */
    async loadGuideList() {
      try {
        // 构建请求参数：全部则不传category，否则传对应分类
        const params = this.selectedCategory === '全部' 
          ? {} 
          : { category: this.selectedCategory }
        
        const res = await get('/guide/list', params)
        if (res.code === 200 && res.data) {
          this.guideList = res.data
        }
      } catch (err) {
        console.error('加载防灾指南列表失败：', err)
        uni.showToast({ title: '加载失败', icon: 'none' })
      }
    },

    /** 选择分类 */
    selectCategory(category) {
      this.selectedCategory = category
      this.loadGuideList() // 重新加载列表
    },

    /** 跳转到详情页 */
    goDetail(id) {
      uni.navigateTo({
        url: `/pages/guide/detail?id=${id}`
      })
    }
  }
}
</script>

<style scoped>
.guide-list {
  background-color: #f8f8f8;
  min-height: 100vh;
  padding-bottom: 20rpx;
}

/* 顶部导航 */
.header-bar {
  background: white;
  padding: 30rpx;
  text-align: center;
  box-shadow: 0 2rpx 8rpx rgba(0,0,0,0.05);
  margin-bottom: 20rpx;
}
.title {
  font-size: 32rpx;
  font-weight: bold;
  color: #333;
}

/* 分类筛选 */
.category-filter {
  background: white;
  padding: 10rpx 20rpx;
  margin-bottom: 20rpx;
  box-shadow: 0 2rpx 8rpx rgba(0,0,0,0.05);
}
.filter-scroll {
  white-space: nowrap;
  padding: 10rpx 0;
}
.filter-item {
  display: inline-block;
  padding: 10rpx 20rpx;
  margin-right: 20rpx;
  background: #f8f8f8;
  border-radius: 20rpx;
  font-size: 26rpx;
  color: #666;
}
.filter-item.active {
  background: #1890ff;
  color: white;
}

/* 指南列表 */
.guide-card-list {
  padding: 0 20rpx;
  display: flex;
  flex-wrap: wrap;
  gap: 20rpx;
}
.guide-card {
  width: calc(50% - 10rpx);
  background: white;
  border-radius: 16rpx;
  overflow: hidden;
  box-shadow: 0 2rpx 8rpx rgba(0,0,0,0.05);
  transition: transform 0.2s;
}
.guide-card:active {
  transform: scale(0.98);
}

/* 封面图 */
.card-cover {
  width: 100%;
  height: 200rpx;
}
.card-cover image {
  width: 100%;
  height: 100%;
}

/* 卡片信息 */
.card-info {
  padding: 20rpx;
}
.guide-title {
  font-size: 28rpx;
  font-weight: bold;
  color: #333;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  margin-bottom: 8rpx;
}
.guide-category {
  font-size: 24rpx;
  color: #999;
}

/* 空数据提示 */
.empty-tip {
  text-align: center;
  padding: 100rpx 0;
  color: #999;
  font-size: 28rpx;
}
</style>