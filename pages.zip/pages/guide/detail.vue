<template>
  <view class="guide-detail">
    <!-- 顶部返回 + 标题 -->
    <view class="header-bar">
      <text class="back-icon" @click="goBack">←</text>
      <text class="detail-title">{{ guideInfo.title }}</text>
    </view>

    <!-- 封面图（本地图片） -->
    <view class="detail-cover" v-if="guideInfo.coverImage">
      <image :src="guideInfo.coverImage" mode="widthFix"></image>
    </view>

    <!-- 分类标签 -->
    <view class="category-tag" v-if="guideInfo.category">
      <text>{{ guideInfo.category }}</text>
    </view>

    <!-- 指南内容（Markdown渲染） -->
    <scroll-view class="content-scroll" scroll-y>
      <view class="guide-content">
        <rich-text :nodes="renderContent(guideInfo.content)"></rich-text>
      </view>
    </scroll-view>
  </view>
</template>

<script>
import { get } from '@/utils/request'

export default {
  data() {
    return {
      guideInfo: {} // 防灾指南详情
    }
  },
  onLoad(options) {
    if (!options.id) {
      uni.showToast({ title: '参数错误', icon: 'none' })
      uni.navigateBack()
      return
    }
    this.loadGuideDetail(options.id)
  },
  methods: {
    /** 加载防灾指南详情 */
    async loadGuideDetail(id) {
      try {
        const res = await get(`/guide/${id}`)
        if (res.code === 200 && res.data) {
          this.guideInfo = res.data
        } else {
          uni.showToast({ title: '获取详情失败', icon: 'none' })
          uni.navigateBack()
        }
      } catch (err) {
        console.error('加载防灾指南详情失败：', err)
        uni.showToast({ title: '网络异常', icon: 'none' })
        uni.navigateBack()
      }
    },

    /** 渲染Markdown格式内容为富文本 */
    renderContent(content) {
      if (!content) return ''
      // 简单处理Markdown换行和标题（适配后端的Markdown格式）
      let html = content
        // 替换### 标题为h3
        .replace(/### (.*?)\n/g, '<h3 style="font-size:30rpx;font-weight:bold;margin:20rpx 0;">$1</h3>')
        // 替换1. 列表为有序列表
        .replace(/(\d+)\. (.*?)\n/g, '<li style="font-size:28rpx;line-height:1.6;margin:10rpx 0;">$2</li>')
        // 普通换行替换为br
        .replace(/\n/g, '<br/>')
      // 包裹容器样式
      return `<div style="padding:20rpx;color:#666;line-height:1.8;">${html}</div>`
    },

    /** 返回上一页 */
    goBack() {
      uni.navigateBack()
    }
  }
}
</script>

<style scoped>
.guide-detail {
  background-color: #f8f8f8;
  min-height: 100vh;
}

/* 顶部导航 */
.header-bar {
  background: white;
  padding: 30rpx;
  display: flex;
  align-items: center;
  box-shadow: 0 2rpx 8rpx rgba(0,0,0,0.05);
  position: sticky;
  top: 0;
  z-index: 99;
}
.back-icon {
  font-size: 32rpx;
  color: #333;
  margin-right: 20rpx;
}
.detail-title {
  font-size: 30rpx;
  font-weight: bold;
  color: #333;
  flex: 1;
  display: -webkit-box;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

/* 封面图 */
.detail-cover {
  width: 100%;
}
.detail-cover image {
  width: 100%;
}

/* 分类标签 */
.category-tag {
  background: #1890ff;
  color: white;
  padding: 10rpx 20rpx;
  border-radius: 20rpx;
  margin: 20rpx;
  display: inline-block;
  font-size: 24rpx;
}

/* 内容滚动容器 */
.content-scroll {
  height: calc(100vh - 200rpx);
  padding: 0 20rpx 20rpx;
}

/* 指南内容 */
.guide-content {
  background: white;
  border-radius: 16rpx;
  padding: 10rpx;
  box-shadow: 0 2rpx 8rpx rgba(0,0,0,0.05);
}
</style>