<template>
  <view class="disaster-type-detail">
    <!-- 顶部Banner -->
    <view class="detail-banner" :style="{ backgroundColor: bannerColor }">
      <text class="banner-icon">{{ typeIcon }}</text>
      <text class="banner-title">{{ disasterType.disasterName }}</text>
      <text class="banner-subtitle">{{ disasterType.warningLevel }}级预警：{{ getLevelText(disasterType.warningLevel) }}</text>
    </view>

    <!-- 详情内容 -->
    <scroll-view class="content-scroll" scroll-y>
      <!-- 预警级别说明 -->
      <view class="content-section">
        <view class="section-title">
          <text class="title-icon">📌</text>
          <text class="title-text">预警级别说明</text>
        </view>
        <view class="section-content">
          <text class="desc-text">{{ disasterType.warningLevelDesc }}</text>
        </view>
      </view>

      <!-- 灾害成因 -->
      <view class="content-section">
        <view class="section-title">
          <text class="title-icon">🌍</text>
          <text class="title-text">灾害成因</text>
        </view>
        <view class="section-content">
          <text class="desc-text">{{ disasterType.disasterCause }}</text>
        </view>
      </view>

      <!-- 主要危害 -->
      <view class="content-section">
        <view class="section-title">
          <text class="title-icon">⚠️</text>
          <text class="title-text">主要危害</text>
        </view>
        <view class="section-content">
          <text class="desc-text">{{ disasterType.disasterHarm }}</text>
        </view>
      </view>

      <!-- 应对要点 -->
      <view class="content-section">
        <view class="section-title">
          <text class="title-icon">🛡️</text>
          <text class="title-text">应对要点</text>
        </view>
        <view class="section-content">
          <text class="desc-text">{{ disasterType.responsePoints }}</text>
        </view>
      </view>

      <!-- 相关指南推荐 -->
      <view class="content-section">
        <view class="section-title">
          <text class="title-icon">📚</text>
          <text class="title-text">相关防灾指南</text>
        </view>
        <view class="section-content">
          <view class="guide-card" @click="goGuide">
            <text class="guide-text">《{{ disasterType.disasterName }}防灾避险指南》</text>
            <text class="guide-arrow">▶</text>
          </view>
        </view>
      </view>
    </scroll-view>
  </view>
</template>

<script>
import { get } from '@/utils/request'

export default {
  data() {
    return {
      disasterType: {}, // 灾害类型详情
      bannerColor: '#52c41a', // Banner背景色
      typeIcon: 'ℹ️' // 灾害图标
    }
  },
  onLoad(options) {
    if (!options.id) {
      uni.showToast({ title: '参数错误', icon: 'none' })
      uni.navigateBack()
      return
    }
    this.loadDisasterTypeDetail(options.id)
  },
  methods: {
    /** 加载灾害类型详情 */
    async loadDisasterTypeDetail(id) {
      try {
        const res = await get(`/guide/disaster-type/${id}`)
        if (res.code === 200 && res.data) {
          this.disasterType = res.data
          // 设置Banner样式
          this.bannerColor = this.getTypeColor(res.data.disasterName)
          this.typeIcon = this.getTypeIcon(res.data.disasterName)
        } else {
          uni.showToast({ title: '获取详情失败', icon: 'none' })
          uni.navigateBack()
        }
      } catch (err) {
        console.error('加载灾害类型详情失败：', err)
        uni.showToast({ title: '网络异常', icon: 'none' })
        uni.navigateBack()
      }
    },

    /** 根据灾害名称获取图标 */
    getTypeIcon(name) {
      const iconMap = {
        '暴雨': '🌧️',
        '山体滑坡': '🗻',
        '洪水': '🌊',
        '地震': '🌍'
      }
      return iconMap[name] || 'ℹ️'
    },

    /** 根据灾害名称获取主色调 */
    getTypeColor(name) {
      const colorMap = {
        '暴雨': '#1890ff',
        '山体滑坡': '#faad14',
        '洪水': '#40a9ff',
        '地震': '#722ed1'
      }
      return colorMap[name] || '#52c41a'
    },

    /** 根据预警级别数量获取文本 */
    getLevelText(level) {
      const levelMap = {
        4: '蓝/黄/橙/红'
      }
      return levelMap[level] || '多级预警'
    },

    /** 跳转到相关防灾指南（真正跳转） */
    async goGuide() {
      try {
        // 1. 根据当前灾害名称，查询对应分类的防灾指南
        const res = await get('/guide/list', {
          category: this.disasterType.disasterName
        })

        if (res.code === 200 && res.data && res.data.length > 0) {
          // 2. 取该分类下第一条指南的ID，跳转到详情页
          const guideId = res.data[0].id
          uni.navigateTo({
            url: `/pages/guide/detail?id=${guideId}`
          })
        } else {
          uni.showToast({ title: '暂无相关防灾指南', icon: 'none' })
        }
      } catch (err) {
        console.error('跳转防灾指南失败：', err)
        uni.showToast({ title: '网络异常', icon: 'none' })
      }
    }
  }
}
</script>

<style scoped>
.disaster-type-detail {
  background-color: #f8f8f8;
  min-height: 100vh;
}

/* 顶部Banner */
.detail-banner {
  padding: 40rpx 30rpx;
  text-align: center;
  color: white;
  border-radius: 0 0 20rpx 20rpx;
}
.banner-icon {
  font-size: 80rpx;
  display: block;
  margin-bottom: 10rpx;
}
.banner-title {
  font-size: 36rpx;
  font-weight: bold;
  display: block;
  margin-bottom: 8rpx;
}
.banner-subtitle {
  font-size: 26rpx;
  opacity: 0.9;
}

/* 滚动容器 */
.content-scroll {
  height: calc(100vh - 220rpx);
  padding: 20rpx;
}

/* 内容模块 */
.content-section {
  background: white;
  border-radius: 16rpx;
  padding: 30rpx;
  margin-bottom: 20rpx;
  box-shadow: 0 2rpx 8rpx rgba(0,0,0,0.05);
}
.section-title {
  display: flex;
  align-items: center;
  margin-bottom: 20rpx;
}
.title-icon {
  font-size: 32rpx;
  margin-right: 10rpx;
}
.title-text {
  font-size: 30rpx;
  font-weight: bold;
  color: #333;
}
.section-content {
  font-size: 28rpx;
  line-height: 1.6;
}
.desc-text {
  color: #666;
  white-space: pre-line; /* 保留换行符，适配后端的多行文本 */
}

/* 相关指南卡片 */
.guide-card {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 20rpx;
  background: #f8f8f8;
  border-radius: 12rpx;
}
.guide-text {
  font-size: 28rpx;
  color: #1890ff;
}
.guide-arrow {
  font-size: 24rpx;
  color: #999;
}
</style>