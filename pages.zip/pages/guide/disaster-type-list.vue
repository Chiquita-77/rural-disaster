<template>
  <view class="disaster-type-list">
    <!-- 顶部导航 -->
    <view class="header-bar">
      <text class="title">灾害类型科普</text>
    </view>

    <!-- 灾害类型列表 -->
    <view class="type-list">
      <view 
        class="type-card" 
        v-for="item in typeList" 
        :key="item.id"
        @click="goDetail(item.id)"
      >
        <!-- 灾害图标 + 主色调背景 -->
        <view class="card-icon" :style="{ backgroundColor: getTypeColor(item.disasterName) }">
          <text>{{ getTypeIcon(item.disasterName) }}</text>
        </view>
        <!-- 灾害信息 -->
        <view class="card-info">
          <text class="type-name">{{ item.disasterName }}</text>
          <text class="level-tag">
            {{ item.warningLevel }}级预警：{{ getLevelText(item.warningLevel) }}
          </text>
        </view>
        <!-- 箭头 -->
        <view class="card-arrow">▶</view>
      </view>
    </view>

    <!-- 空数据提示 -->
    <view v-if="typeList.length === 0" class="empty-tip">
      <text>暂无灾害类型科普数据</text>
    </view>
  </view>
</template>

<script>
import { get } from '@/utils/request'

export default {
  data() {
    return {
      typeList: [] // 灾害类型列表
    }
  },
  onLoad() {
    this.loadDisasterTypeList()
  },
  methods: {
    /** 加载灾害类型列表 */
    async loadDisasterTypeList() {
      try {
        const res = await get('/guide/disaster-type/list')
        if (res.code === 200 && res.data) {
          this.typeList = res.data
        }
      } catch (err) {
        console.error('加载灾害类型列表失败：', err)
        uni.showToast({ title: '加载失败', icon: 'none' })
      }
    },

    /** 跳转到详情页 */
    goDetail(id) {
      uni.navigateTo({
        url: `/pages/guide/disaster-type-detail?id=${id}`
      })
    },

    /** 根据灾害名称获取图标 */
    getTypeIcon(name) {
      const iconMap = {
        '暴雨': '🌧️',
        '山体滑坡': '🗻',
        '洪水': '🌊',
        '地震': '🌍'
      }
      return iconMap[name] || 'ℹ️'
    },

    /** 根据灾害名称获取主色调 */
    getTypeColor(name) {
      const colorMap = {
        '暴雨': '#1890ff',       // 蓝色
        '山体滑坡': '#faad14',    // 黄色
        '洪水': '#40a9ff',        // 浅蓝
        '地震': '#722ed1'         // 紫色
      }
      return colorMap[name] || '#52c41a' // 默认绿色
    },

    /** 根据预警级别数量获取文本 */
    getLevelText(level) {
      const levelMap = {
        4: '蓝/黄/橙/红'
      }
      return levelMap[level] || '多级预警'
    }
  }
}
</script>

<style scoped>
.disaster-type-list {
  background-color: #f8f8f8;
  min-height: 100vh;
  padding-bottom: 20rpx;
}

/* 顶部导航 */
.header-bar {
  background: white;
  padding: 30rpx;
  text-align: center;
  box-shadow: 0 2rpx 8rpx rgba(0,0,0,0.05);
  margin-bottom: 20rpx;
}
.title {
  font-size: 32rpx;
  font-weight: bold;
  color: #333;
}

/* 列表样式 */
.type-list {
  padding: 0 20rpx;
  gap: 20rpx;
}
.type-card {
  display: flex;
  align-items: center;
  background: white;
  border-radius: 16rpx;
  padding: 20rpx 30rpx;
  box-shadow: 0 2rpx 8rpx rgba(0,0,0,0.05);
  transition: transform 0.2s;
}
.type-card:active {
  transform: scale(0.98);
}

/* 卡片图标 */
.card-icon {
  width: 80rpx;
  height: 80rpx;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 20rpx;
}
.card-icon text {
  font-size: 40rpx;
}

/* 卡片信息 */
.card-info {
  flex: 1;
}
.type-name {
  font-size: 30rpx;
  font-weight: bold;
  color: #333;
  display: block;
  margin-bottom: 8rpx;
}
.level-tag {
  font-size: 24rpx;
  color: #666;
}

/* 卡片箭头 */
.card-arrow {
  font-size: 28rpx;
  color: #999;
}

/* 空数据提示 */
.empty-tip {
  text-align: center;
  padding: 100rpx 0;
  color: #999;
  font-size: 28rpx;
}
</style>