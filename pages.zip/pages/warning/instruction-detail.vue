<template>
  <view class="detail-container">
    <!-- 加载中状态 -->
    <view v-if="loading" class="loading">加载详情中...</view>
    
    <!-- 指令详情内容（加 v-if 保护，只有 instruction 存在且有数据时才渲染） -->
    <view v-else-if="instruction && Object.keys(instruction).length > 0" class="detail-content">
      <!-- 标题兜底 -->
      <view class="title">{{ instruction.title || '暂无标题' }}</view>
      
      <view class="info-bar">
        <text class="time">发布时间：{{ formatPublishTime }}</text>
        <!-- 暂时隐藏已读标签，避免报错 -->
        <!-- <text class="read-tag" v-if="isMarkedRead">✅ 已读</text> -->
      </view>
      
      <!-- 内容兜底 -->
      <view class="content">{{ instruction.content || '暂无内容' }}</view>
      
      <!-- 状态标签保护：只有 status 存在时才渲染 -->
      <view v-if="instruction.status !== undefined" class="status-tag" :class="getStatusClass(instruction.status)">
        {{ getStatusText(instruction.status) }}
      </view>
      
      <view class="back-btn" @click="goBack">
        <text>返回列表</text>
      </view>
    </view>

    <!-- 空状态页面：指令不存在/无权限/加载失败 -->
    <view v-else class="empty">
      <text class="empty-icon">📭</text>
      <text class="empty-text">暂无指令详情</text>
      <text class="empty-desc">该指令可能不存在或您无查看权限</text>
      <view class="empty-back-btn" @click="goBack">
        <text>返回列表</text>
      </view>
    </view>
  </view>
</template>

<script>
import { get } from '@/utils/request' // 暂时移除 post 导入，避免无用依赖

export default {
  // 页面生命周期：接收参数并加载详情
  async onLoad(options) {
    this.orderId = options.orderId;
    if (!this.orderId) {
      uni.showToast({ title: '指令ID不能为空', icon: 'none' });
      setTimeout(() => uni.navigateBack(), 1500);
      return;
    }
    await this.loadInstructionDetail();
  },
  
  data() {
    return {
      instruction: {},       // 指令详情数据
      loading: false,        // 加载状态
      isMarkedRead: false,   // 暂时保留，后续可恢复
      orderId: null          // 指令ID
    }
  },
  
  computed: {
    // 格式化发布时间（空值兜底）
    formatPublishTime() {
      if (!this.instruction.publishTime) return '未知时间';
      try {
        const date = new Date(this.instruction.publishTime);
        return `${date.getFullYear()}-${(date.getMonth()+1).toString().padStart(2, '0')}-${date.getDate().toString().padStart(2, '0')} ${date.getHours().toString().padStart(2, '0')}:${date.getMinutes().toString().padStart(2, '0')}`;
      } catch (e) {
        return '未知时间'; // 时间格式错误时兜底
      }
    }
  },
  
  methods: {
    // 1. 状态文本转换（空值兜底）
    getStatusText(status) {
      if (status === undefined || status === null) return '未知状态';
      const statusMap = {0: '未生效', 1: '生效中', 2: '已失效'};
      return statusMap[status] || '未知状态';
    },
    
    // 2. 状态样式类转换（空值兜底）
    getStatusClass(status) {
      if (status === undefined || status === null) return '';
      const classMap = {0: 'status-pending', 1: 'status-active', 2: 'status-inactive'};
      return classMap[status] || '';
    },
    
    // 3. 加载指令详情（核心方法，增加多重容错）
    async loadInstructionDetail() {
      this.loading = true;
      try {
        const userId = uni.getStorageSync('userId') || 1001;
        // 调用后端详情接口
        const res = await get(`/user/emergency/order/detail/${this.orderId}?userId=${userId}`);
        // 严格判断返回数据是否有效
        this.instruction = (res && res.code === 200 && res.data) ? res.data : {};
      } catch (err) {
        console.error('加载指令详情失败：', err);
        uni.showToast({ title: '加载失败，请重试', icon: 'none' });
        this.instruction = {}; // 加载失败时重置为空对象，触发空状态
      } finally {
        this.loading = false; // 无论成败，关闭加载状态
      }
    },
    
    // 4. 暂时注释掉标记已读方法（避免接口报错）
    /*
    async markAsRead() {
      try {
        const userId = uni.getStorageSync('userId') || 1001;
        const res = await post(`/user/emergency/order/read/${this.orderId}`, { userId });
        if (res.code === 200) {
          this.isMarkedRead = true;
        }
      } catch (err) {
        console.warn('标记已读失败（不影响查看）：', err);
      }
    },
    */
    
    // 5. 返回列表页（增加容错）
    goBack() {
      try {
        uni.navigateBack({ delta: 1 });
      } catch (e) {
        // 无法返回时，跳转到列表页（需替换为你的列表页路径）
        uni.redirectTo({ url: '/pages/emergency/order-list/order-list' });
      }
    }
  }
}
</script>

<style scoped>
/* 整体容器 */
.detail-container { 
  padding: 20rpx; 
  background-color: #f8f8f8;
  min-height: 100vh;
  box-sizing: border-box;
}

/* 加载中样式 */
.loading {
  text-align: center;
  padding: 100rpx 0;
  color: #999;
  font-size: 28rpx;
}

/* 详情内容卡片 */
.detail-content {
  background: white;
  padding: 40rpx;
  border-radius: 16rpx;
  box-shadow: 0 2rpx 8rpx rgba(0,0,0,0.05);
}

/* 标题样式 */
.title { 
  font-size: 36rpx; 
  font-weight: bold; 
  color: #e64340; 
  margin-bottom: 30rpx; 
  line-height: 1.4;
}

/* 信息栏（时间+已读标签） */
.info-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 40rpx;
  padding-bottom: 20rpx;
  border-bottom: 1rpx solid #eee;
}

.time { 
  color: #999; 
  font-size: 26rpx; 
}

.read-tag {
  font-size: 24rpx;
  color: #52c41a;
}

/* 内容区域 */
.content { 
  line-height: 1.8; 
  color: #333; 
  font-size: 32rpx; 
  margin-bottom: 30rpx;
}

/* 状态标签 */
.status-tag {
  font-size: 26rpx;
  padding: 8rpx 16rpx;
  border-radius: 8rpx;
  margin-bottom: 30rpx;
  display: inline-block;
}

/* 不同状态的样式 */
.status-pending { background: #fff7e6; color: #faad14; } /* 未生效 */
.status-active { background: #e6fffb; color: #13c2c2; }   /* 生效中 */
.status-inactive { background: #f5f5f5; color: #8c8c8c; } /* 已失效 */

/* 返回按钮 */
.back-btn {
  text-align: center;
  background: #e64340;
  color: white;
  padding: 20rpx;
  border-radius: 12rpx;
  font-size: 30rpx;
  margin-top: 20rpx;
}

/* 空状态样式 */
.empty {
  text-align: center;
  padding: 100rpx 40rpx;
}

.empty-icon {
  font-size: 80rpx;
  display: block;
  margin-bottom: 30rpx;
  color: #ccc;
}

.empty-text {
  font-size: 32rpx;
  color: #666;
  display: block;
  margin-bottom: 15rpx;
}

.empty-desc {
  font-size: 26rpx;
  color: #999;
  display: block;
  margin-bottom: 40rpx;
}

.empty-back-btn {
  background: #e64340;
  color: white;
  padding: 20rpx 40rpx;
  border-radius: 12rpx;
  font-size: 30rpx;
  display: inline-block;
}
</style>