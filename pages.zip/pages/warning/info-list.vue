<template>
  <view class="container">
    <!-- 预警列表 -->
    <view 
      v-for="item in warningList" 
      :key="item.warningId" 
      class="card" 
      @click="goDetail(item.warningId)"
    >
      <!-- 预警等级标签 -->
      <view class="level-tag" :class="`level-${item.level}`">{{ getLevelText(item.level) }}</view>
      <text class="title">{{ item.title }}</text>
      <text class="time">{{ formatTime(item.publishTime) }}</text>
      <text class="content">{{ item.content }}</text>
    </view>

    <!-- 空状态/错误状态 -->
    <view class="empty-container" v-if="warningList.length === 0 && !loading">
      <uni-icons type="sunny" size="60" color="#ccc"></uni-icons>
      <text class="empty-text">{{ hasError ? '加载失败，请重试' : '暂无预警信息' }}</text>
      <button v-if="hasError" class="retry-btn" @click="reloadData">重新加载</button>
    </view>

    <!-- 加载中状态 -->
    <view class="loading" v-if="loading">
      <text>加载中...</text>
    </view>

    <!-- 上拉加载提示 -->
    <view class="load-tips" v-if="loadingMore && warningList.length > 0">加载中...</view>
    <view class="load-tips" v-if="noMore && warningList.length > 0">没有更多了</view>
  </view>
</template>

<script>
import { get } from '@/utils/request'

export default {
  data() {
    return {
      warningList: [], // 强制初始化为空数组，杜绝undefined/null
      loading: true,
      hasError: false,
      villageId: 101,
      currentPage: 1,
      pageSize: 10,
      loadingMore: false,
      noMore: false,
      stats: {
        urgentCount: 0,
        seriousCount: 0,
        todayAddCount: 0
      }
    }
  },
  // 下拉刷新
  onPullDownRefresh() {
    this.currentPage = 1
    this.loadWarningData(true).finally(() => {
      uni.stopPullDownRefresh()
    })
  },
  // 上拉加载
  onReachBottom() {
    if (this.loadingMore || this.noMore) return
    this.loadingMore = true
    this.loadWarningData(false).finally(() => {
      this.loadingMore = false
    })
  },
  // 页面加载
  async onLoad(options) {
    this.villageId = options.villageId || 101
    // 只调用修复后的loadWarningData，无任何旧方法调用
    await this.loadWarningData(true)
  },
  methods: {
    /**
     * 加载预警数据（核心：严格解析后端IPage分页结构，确保warningList始终是数组）
     */
    async loadWarningData(isRefresh) {
      const pageNum = isRefresh ? 1 : this.currentPage + 1
      this.loading = isRefresh
      this.hasError = false
      try {
        const res = await get('/warning/list', {
          villageId: this.villageId,
          status: 1,
          pageNum,
          pageSize: this.pageSize
        })
        // 严格匹配后端返回结构：{code:200, msg:"success", data:{records:[...]}}
        const pageData = res?.data || {} 
        const records = pageData?.records || [] 
        
        // 刷新/加载逻辑（扩展运算符强制保持数组类型）
        this.warningList = isRefresh ? [...records] : [...this.warningList, ...records]
        this.currentPage = pageNum
        this.noMore = records.length < this.pageSize

        // 统计逻辑（先判断数组类型，再执行filter）
        this.calcStats()

      } catch (err) {
        console.error('预警数据加载失败:', err)
        this.hasError = true
        uni.showToast({
          title: isRefresh ? '刷新失败' : '加载更多失败',
          icon: 'none',
          duration: 2000
        })
        if (!isRefresh) this.currentPage = pageNum - 1
      } finally {
        this.loading = false
      }
    },

    /**
     * 统计预警数据（核心修复：先校验数组类型，杜绝filter报错）
     */
    calcStats() {
      // 双重保险：确保warningList是数组
      if (!Array.isArray(this.warningList)) {
        this.warningList = []
      }
      // 执行filter统计
      this.stats.urgentCount = this.warningList.filter(i => i.level === 1).length
      this.stats.seriousCount = this.warningList.filter(i => i.level === 2).length
      this.stats.todayAddCount = 0
    },

    /**
     * 重新加载数据
     */
    reloadData() {
      this.loadWarningData(true)
    },

    /**
     * 格式化时间（兼容后端LocalDateTime的T分隔符）
     */
    formatTime(dateStr) {
      if (!dateStr) return '暂无时间'
      dateStr = dateStr.replace('T', ' ')
      const date = new Date(dateStr)
      if (isNaN(date.getTime())) return '时间格式错误'
      const padZero = (num) => String(num).padStart(2, '0')
      return `${date.getFullYear()}-${padZero(date.getMonth() + 1)}-${padZero(date.getDate())} ${padZero(date.getHours())}:${padZero(date.getMinutes())}`
    },

    /**
     * 跳转到预警详情页
     */
    goDetail(warningId) {
      if (!warningId) {
        uni.showToast({ title: '预警ID无效', icon: 'none' })
        return
      }
      uni.navigateTo({
        url: `/pages/warning/detail?id=${warningId}&villageId=${this.villageId}`
      })
    },

    /**
     * 预警等级数字转文字
     */
    getLevelText(level) {
      const levelMap = { 1: '红色', 2: '橙色', 3: '黄色', 4: '蓝色' };
      return levelMap[level] ? `${levelMap[level]}预警` : '未知预警';
    }
  }
}
</script>

<style scoped>
.container {
  padding: 20rpx;
  min-height: 100vh;
  background-color: #f5f5f5;
}

.card {
  background: white;
  padding: 30rpx;
  margin-bottom: 20rpx;
  border-radius: 12rpx;
  box-shadow: 0 2rpx 8rpx rgba(0, 0, 0, 0.1);
  transition: all 0.2s ease;
}
.card:active {
  transform: scale(0.98);
  box-shadow: 0 1rpx 4rpx rgba(0, 0, 0, 0.1);
}

.title {
  font-size: 32rpx;
  font-weight: bold;
  display: block;
  margin-bottom: 10rpx;
}
.time {
  font-size: 24rpx;
  color: #999;
  display: block;
  margin-bottom: 15rpx;
}
.content {
  font-size: 28rpx;
  line-height: 1.5;
  color: #333;
}

.empty-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 400rpx;
}
.empty-text {
  margin-top: 20rpx;
  color: #999;
  font-size: 28rpx;
}
.retry-btn {
  margin-top: 30rpx;
  background: #007aff;
  color: white;
  border-radius: 8rpx;
  padding: 10rpx 30rpx;
  font-size: 28rpx;
}

.loading {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 200rpx;
}
.loading text {
  font-size: 28rpx;
  color: #999;
}

.load-tips {
  text-align: center;
  padding: 20rpx;
  font-size: 26rpx;
  color: #999;
}

.level-tag {
  display: inline-block;
  padding: 4rpx 12rpx;
  border-radius: 4rpx;
  font-size: 22rpx;
  color: white;
  margin-bottom: 10rpx;
}
.level-1 { background: #FF3333; }
.level-2 { background: #FF9933; }
.level-3 { background: #FFFF33; color: #333; }
.level-4 { background: #3399FF; }
</style>