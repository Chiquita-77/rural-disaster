<template>
  <view class="container">
    <!-- 筛选栏：按时间/状态筛选 -->
    <view class="filter-bar">
      <picker mode="date" @change="handleDateChange" :value="selectDate">
        <view class="filter-item">
          <text>筛选日期：{{ selectDate || '全部' }}</text>
        </view>
      </picker>
      <picker mode="selector" @change="handleStatusChange" :range="statusOptions" :value="statusIndex">
        <view class="filter-item">
          <text>状态：{{ statusOptions[statusIndex] }}</text>
        </view>
      </picker>
    </view>

    <!-- 空状态 -->
    <view v-if="list.length === 0 && !loading" class="empty">暂无历史预警记录</view>
    <!-- 加载中 -->
    <view v-if="loading" class="empty">加载中...</view>
    <!-- 历史预警列表 -->
    <view v-else class="history-list">
      <view v-for="item in list" :key="item.tipId" class="history-item">
        <view class="item-header">
          <text class="title">{{ item.title }}</text>
          <text class="status-tag" :class="{'passed': item.reviewStatus === 1, 'rejected': item.reviewStatus === -1, 'pending': item.reviewStatus === 0}">
            {{ getStatusText(item.reviewStatus) }}
          </text>
        </view>
        <text class="content">{{ item.content }}</text>
        <view class="item-footer">
          <text class="time">发布时间：{{ formatTime(item.createTime) }}</text>
          <text v-if="item.reviewTime" class="review-time">审核时间：{{ formatTime(item.reviewTime) }}</text>
        </view>
        <text v-if="item.reviewComment" class="review-comment">审核备注：{{ item.reviewComment }}</text>
      </view>
    </view>
  </view>
</template>

<script>
import { get } from '@/utils/request'
import { getCurrentVillageId } from '@/utils/auth'

export default {
  data() {
    return {
      list: [],
      loading: false,
      selectDate: '',
      statusIndex: 0,
      statusOptions: ['全部', '待审核', '已通过', '已驳回'],
      villageId: ''
    }
  },
  onLoad() {
    // 核心修改：强制写死为101，不再依赖getCurrentVillageId
    this.villageId = 101
    this.loadHistoryTips()
  },
  methods: {
    async loadHistoryTips() {
      this.loading = true
      try {
        const params = {}
        // 确保villageId必传且值为101
        params.villageId = this.villageId
        if (this.statusIndex > 0 && this.statusIndex <= 3) {
          const statusMap = [0, 1, -1]
          params.reviewStatus = statusMap[this.statusIndex - 1]
        }
        if (this.selectDate) {
          params.date = this.selectDate
        }

        const res = await get('/warning/history/list', params)
        if (res.code === 200) {
          this.list = res.data || []
        } else {
          uni.showToast({
            title: res.msg || '加载失败',
            icon: 'none'
          })
        }
      } catch (err) {
        console.error('加载历史预警失败：', err)
        // 新增：打印请求参数，方便排查
        console.error('请求参数：', params)
        uni.showToast({
          title: '网络异常，加载失败',
          icon: 'none'
        })
      } finally {
        this.loading = false
      }
    },
    handleDateChange(e) {
      this.selectDate = e.detail.value
      this.loadHistoryTips()
    },
    handleStatusChange(e) {
      this.statusIndex = parseInt(e.detail.value)
      this.loadHistoryTips()
    },
    formatTime(time) {
      if (!time) return '未知时间'
      return time.includes('T')
        ? time.replace('T', ' ').substring(0, 16)
        : time.substring(0, 16)
    },
    getStatusText(status) {
      const statusMap = {
        0: '待审核',
        1: '已通过',
        '-1': '已驳回'
      }
      return statusMap[status] || '未知状态'
    }
  }
}
</script>

<style scoped>
.container {
  padding: 20rpx;
  background: #f8f9fa;
  min-height: 100vh;
}
.filter-bar {
  display: flex;
  justify-content: space-between;
  background: white;
  padding: 20rpx;
  border-radius: 12rpx;
  margin-bottom: 20rpx;
}
.filter-item {
  font-size: 28rpx;
  color: #333;
}
.empty {
  text-align: center;
  padding: 100rpx 0;
  color: #999;
  font-size: 28rpx;
}
.history-list {
  width: 100%;
}
.history-item {
  background: white;
  padding: 30rpx;
  border-radius: 12rpx;
  margin-bottom: 20rpx;
  box-shadow: 0 2rpx 8rpx rgba(0,0,0,0.05);
}
.item-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 15rpx;
}
.title {
  font-size: 32rpx;
  font-weight: bold;
  color: #333;
}
.status-tag {
  font-size: 24rpx;
  padding: 5rpx 15rpx;
  border-radius: 20rpx;
}
.status-tag.pending {
  background: #ffcc00;
  color: white;
}
.status-tag.passed {
  background: #4caf50;
  color: white;
}
.status-tag.rejected {
  background: #f44336;
  color: white;
}
.content {
  font-size: 28rpx;
  color: #666;
  line-height: 1.5;
  margin-bottom: 15rpx;
  display: block;
}
.item-footer {
  display: flex;
  justify-content: space-between;
  font-size: 24rpx;
  color: #999;
  margin-bottom: 10rpx;
}
.review-comment {
  font-size: 24rpx;
  color: #666;
  padding-top: 10rpx;
  border-top: 1px solid #f0f0f0;
}
</style>