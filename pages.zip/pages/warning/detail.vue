<template>
  <view class="detail-container">
    <!-- 加载中 -->
    <view class="loading" v-if="loading">加载中...</view>
    
    <!-- 错误状态 -->
    <view class="error" v-if="hasError">
      <text>加载失败</text>
      <button @click="loadDetail">重新加载</button>
    </view>
    
    <!-- 详情内容（严格匹配后端WarningEntity字段） -->
    <view class="detail-card" v-else-if="warning">
      <!-- 顶部标题+解除按钮 -->
      <view class="header">
        <text class="title">{{ warning.title }}</text>
        <button v-if="warning.status === 1" class="cancel-btn" @click="cancelWarning">解除预警</button>
      </view>
      
      <!-- 核心内容 -->
      <text class="detail-time">发布时间：{{ formatTime(warning.publishTime) }}</text>
      <text class="detail-content">{{ warning.content }}</text>
      <text class="detail-location">发布位置：{{ warning.locationDesc || '暂无' }}</text>
      <text class="detail-level">预警等级：{{ getLevelText(warning.level) }}</text>
      
      <!-- 底部返回按钮 -->
      <view class="back-btn-box" style="margin-top: 40rpx; padding: 0 20rpx;">
        <button class="back-btn" @click="goBackToList">返回预警列表</button>
      </view>
    </view>
  </view>
</template>

<script>
import { get, post } from '@/utils/request'

export default {
  data() {
    return {
      warning: null,
      loading: true,
      hasError: false,
      warningId: '',
      villageId: ''
    }
  },
  async onLoad(options) {
    this.warningId = options.id
    this.villageId = options.villageId || 101
    
    if (!this.warningId) {
      uni.showToast({ title: '预警ID无效', icon: 'none' })
      uni.navigateBack()
      return
    }
    
    await this.loadDetail()
  },
  methods: {
    /**
     * 加载预警详情（匹配后端 /warning/{id} 接口）
     */
    async loadDetail() {
      this.loading = true
      this.hasError = false
      try {
        const res = await get(`/warning/${this.warningId}`)
        // 后端返回 Result<WarningEntity>，取res.data为实体对象
        this.warning = res.data || null
      } catch (err) {
        this.hasError = true
        uni.showToast({ title: '加载详情失败', icon: 'none' })
      } finally {
        this.loading = false
      }
    },

    /**
     * 解除预警（匹配后端 /warning/{id}/cancel 接口）
     */
    async cancelWarning() {
      uni.showModal({
        title: '确认解除',
        content: '是否确认解除该预警？解除后将不再在列表展示',
        success: async (res) => {
          if (res.confirm) {
            try {
              await post(`/warning/${this.warningId}/cancel`)
              uni.showToast({ title: '解除成功', icon: 'success' })
              // 跳回预警列表页
              uni.redirectTo({
                url: `/pages/warning/list?villageId=${this.villageId}`
              })
            } catch (err) {
              uni.showToast({ title: '解除失败', icon: 'none' })
            }
          }
        }
      })
    },

    /**
     * 格式化时间
     */
    formatTime(dateStr) {
      if (!dateStr) return '暂无时间'
      dateStr = dateStr.replace('T', ' ')
      const date = new Date(dateStr)
      if (isNaN(date.getTime())) return '时间格式错误'
      const padZero = num => String(num).padStart(2, '0')
      return `${date.getFullYear()}-${padZero(date.getMonth()+1)}-${padZero(date.getDate())} ${padZero(date.getHours())}:${padZero(date.getMinutes())}`
    },

    /**
     * 等级转文字
     */
    getLevelText(level) {
      const levelMap = { 1: '低', 2: '中', 3: '高', 4: '紧急' }
      return levelMap[level] || '未知'
    },

    /**
     * 返回列表页
     */
    goBackToList() {
      uni.navigateBack()
    }
  }
}
</script>

<style scoped>
.detail-container {
  padding: 20rpx;
  background-color: #f5f5f5;
  min-height: 100vh;
}
.detail-card {
  background: white;
  padding: 30rpx;
  border-radius: 12rpx;
  box-shadow: 0 2rpx 8rpx rgba(0,0,0,0.1);
}
.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20rpx;
}
.header .title {
  font-size: 34rpx;
  font-weight: bold;
}
.cancel-btn { 
  background: #e64340; 
  color: white; 
  font-size: 24rpx; 
  padding: 8rpx 16rpx; 
  border-radius: 8rpx; 
  border: none;
}
.detail-time {
  font-size: 24rpx;
  color: #999;
  display: block;
  margin-bottom: 20rpx;
}
.detail-content {
  font-size: 28rpx;
  line-height: 1.6;
  margin-bottom: 20rpx;
  display: block;
}
.detail-location, .detail-level {
  font-size: 26rpx;
  color: #666;
  display: block;
  margin-bottom: 10rpx;
}
.loading {
  text-align: center;
  padding: 50rpx;
  color: #999;
}
.error {
  text-align: center;
  padding: 50rpx;
}
.error button {
  margin-top: 20rpx;
  background: #007aff;
  color: white;
  border-radius: 8rpx;
  padding: 10rpx 30rpx;
}
.back-btn {
  background-color: #007aff;
  color: white;
  border-radius: 8rpx;
  padding: 15rpx 0;
  width: 100%;
}
</style>