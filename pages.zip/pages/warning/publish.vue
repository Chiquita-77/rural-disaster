<template>
  <view class="container">
    <view class="form-item">
      <text class="label">预警标题 *</text>
      <input
        v-model="formData.title"
        class="input"
        placeholder="请输入预警标题，如：暴雨红色预警"
        maxlength="50"
      />
    </view>

    <view class="form-item">
      <text class="label">预警内容 *</text>
      <textarea
        v-model="formData.content"
        class="textarea"
        placeholder="请输入详细预警内容..."
        maxlength="500"
        auto-height
      />
    </view>

    <view class="form-item">
      <text class="label">预警等级 *</text>
      <picker mode="selector" :range="levelOptions" @change="onLevelChange">
        <view class="picker">
          {{ levelText || '请选择预警等级' }}
        </view>
      </picker>
    </view>

    <!-- 村庄信息（从上一页传入，不可编辑） -->
    <view class="form-item">
      <text class="label">发布村庄</text>
      <view class="readonly">{{ villageName || '当前村庄' }}</view>
    </view>
    <button class="submit-btn" @click="handleSubmit" :loading="submitting">
      {{ submitting ? '发布中...' : '立即发布' }}
    </button>
  </view>
</template>

<script>
import { post } from '@/utils/request'

export default {
  data() {
    return {
      villageId: '',
      villageName: '',
      submitting: false,
      formData: {
        title: '',
        content: '',
        level: '' // 1:低, 2:中, 3:高, 4:紧急
      },
      levelOptions: ['低', '中', '高', '紧急'],
      levelText: ''
    }
  },

  onLoad(options) {
    // 从村庄详情页传入 villageId 和 villageName
    this.villageId = options.villageId || 101
    this.villageName = options.villageName || 'XX村'
  },

  methods: {
    onLevelChange(e) {
      const index = e.detail.value
      this.formData.level = parseInt(index) + 1 // 转为 1,2,3,4
      this.levelText = this.levelOptions[index]
    },

    async handleSubmit() {
      // 表单校验
      if (!this.formData.title.trim()) {
        uni.showToast({ title: '请输入预警标题', icon: 'none' })
        return
      }
      if (!this.formData.content.trim()) {
        uni.showToast({ title: '请输入预警内容', icon: 'none' })
        return
      }
      if (!this.formData.level) {
        uni.showToast({ title: '请选择预警等级', icon: 'none' })
        return
      }
      this.submitting = true

      try {
        await post('/warning/publish', {
          title: this.formData.title.trim(),
          content: this.formData.content.trim(),
          level: this.formData.level,
          villageId: this.villageId,
        })

        uni.showToast({ title: '发布成功！', icon: 'success' })

        // 延迟 1 秒后返回列表页（带村庄ID，修复空格问题）
        setTimeout(() => {
          uni.redirectTo({
            url: `/pages/warning/list?villageId=${this.villageId}`
          })
        }, 1000)

      } catch (err) {
        console.error('发布失败:', err)
        uni.showToast({ title: '发布失败，请重试', icon: 'none' })
      } finally {
        this.submitting = false
      }
    }
  }
}
</script>

<style>
.container {
  padding: 30rpx;
  background-color: #f8f9fa;
}

.form-item {
  margin-bottom: 40rpx;
}

.label {
  display: block;
  font-size: 28rpx;
  color: #333;
  margin-bottom: 16rpx;
  font-weight: bold;
}

.input,
.textarea,
.picker,
.readonly {
  width: 100%;
  padding: 20rpx;
  background: white;
  border-radius: 12rpx;
  font-size: 28rpx;
  color: #333;
  box-sizing: border-box;
}

.input {
  height: 80rpx;
}

.textarea {
  min-height: 200rpx;
  line-height: 1.5;
  resize: none;
}

.picker {
  color: #666;
}

.readonly {
  background: #f0f0f0;
  color: #666;
}

.submit-btn {
  width: 100%;
  height: 90rpx;
  background: #e64340; /* 红色，符合预警主题 */
  color: white;
  font-size: 32rpx;
  border-radius: 16rpx;
  margin-top: 60rpx;
}
</style>