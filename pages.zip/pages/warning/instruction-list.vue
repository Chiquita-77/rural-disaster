<template>
  <view class="instruction-container">
    <!-- 页面标题 -->
    <view class="header">
      <text class="header-text">🚨 应急指令</text>
    </view>

    <!-- 加载中状态 -->
    <view v-if="loading" class="loading">
      <text>加载应急指令中...</text>
    </view>

    <!-- 指令列表 -->
    <view v-else-if="instructions.length > 0" class="list">
      <!-- 兼容 orderId/id 两种字段名 -->
      <view 
        v-for="item in formatInstructions" 
        :key="item.orderId || item.id"
        class="card"
        @click="goDetail(item.orderId || item.id)"
      >
        <!-- 暂时隐藏未读标记 -->
        <!-- <view v-if="!item.isRead" class="unread-tag">未读</view> -->

        <view class="title">{{ item.title || '暂无标题' }}</view>
        <view class="time">{{ item.formatCreateTime }}</view>

        <!-- 暂时隐藏送达统计按钮 -->
        <!-- <button 
          v-if="role === 3" 
          @click.stop="showDeliveryStats(item.orderId)" 
          class="stats-btn"
        >
          查看送达统计
        </button> -->
      </view>
    </view>

    <!-- 空数据状态 -->
    <view v-else class="empty">
      <text class="empty-icon">📭</text>
      <text class="empty-text">暂无应急指令</text>
      <text class="empty-desc">如有紧急通知，将第一时间展示在这里</text>
    </view>
  </view>
</template>

<script>
import { get } from '@/utils/request' // 移除无用的 post 导入
// 注释掉 auth 导入，避免依赖报错
// import { getCurrentRole } from '@/utils/auth'

export default {
  data() {
    return {
      instructions: [],
      loading: false,
      villageId: uni.getStorageSync('villageId') || 101,
      userId: uni.getStorageSync('userId') || 1001,
      role: 1, // 固定为普通用户，避免 auth 依赖报错
      showStatsModal: false,
      statsData: {},
    }
  },
  computed: {
    formatInstructions() {
      return this.instructions.map(item => {
        const formatTime = (timeStr) => {
          if (!timeStr) return '未知时间';
          try { // 加 try-catch 避免时间格式错误报错
            const date = new Date(timeStr);
            const year = date.getFullYear();
            const month = (date.getMonth() + 1).toString().padStart(2, '0');
            const day = date.getDate().toString().padStart(2, '0');
            const hour = date.getHours().toString().padStart(2, '0');
            const minute = date.getMinutes().toString().padStart(2, '0');
            return `${year}-${month}-${day} ${hour}:${minute}`;
          } catch (e) {
            return '未知时间';
          }
        };
        
        return {
          ...item,
          formatCreateTime: formatTime(item.publishTime || item.createTime), // 兼容 publishTime/createTime
          isRead: false // 固定为未读，避免已读状态检查报错
        };
      });
    }
  },
  async onShow() {
    await this.loadInstructions()
  },
  methods: {
    async loadInstructions() {
      this.loading = true;
      try {
        // 调用用户端接口，传当前村庄ID
        const res = await get(`/user/emergency/order/list?villageId=${this.villageId}`);
        // 严格判断返回数据，避免空值报错
        this.instructions = (res && res.code === 200 && res.data) ? res.data : [];
        // 注释掉已读状态检查，避免接口报错
        // await this.checkReadStatus();
      } catch (err) {
        console.error('加载应急指令失败：', err);
        uni.showToast({ title: '加载失败，请重试', icon: 'none' });
        this.instructions = [];
      } finally {
        this.loading = false;
      }
    },

    // 暂时注释掉已读状态检查，避免接口报错
    /*
    async checkReadStatus() {
      if (!this.userId) return;
      
      try {
        const unreadRes = await get(`/user/emergency/order/unread/count?userId=${this.userId}`);
        const unreadOrderIds = unreadRes.data || [];
        
        this.instructions.forEach(item => {
          item.isRead = !unreadOrderIds.includes(item.orderId);
        });
      } catch (err) {
        console.error('检查已读状态失败：', err);
        this.instructions.forEach(item => item.isRead = false);
      }
    },
    */

    // 适配详情页路径（和之前的 detail 页面路径一致）
    goDetail(id) {
      if (!id) { // 加空值判断，避免传空ID报错
        uni.showToast({ title: '指令ID不能为空', icon: 'none' });
        return;
      }
      uni.navigateTo({
        url: `/pages/warning/instruction-detail?orderId=${id}` // 适配详情页路径
        // 如果你的详情页路径是 /pages/warning/instruction-detail，替换为：
        // url: `/pages/warning/instruction-detail?orderId=${id}`
      });
    },

    // 暂时注释掉送达统计相关方法，避免接口报错
    /*
    async showDeliveryStats(orderId) {
      try {
        const res = await get(`/admin/emergency/order/receive/stats?orderId=${orderId}`);
        this.statsData = res.data;
        this.showStatsModal = true;
      } catch (err) {
        console.error(`获取指令${orderId}送达统计失败：`, err);
        uni.showToast({ title: '获取送达统计失败，请重试', icon: 'none' });
      }
    },

    closeStatsModal() {
      this.showStatsModal = false;
    },
    */
  }
}
</script>

<style scoped>
.instruction-container { 
  padding: 20rpx; 
  background-color: #f8f8f8;
  min-height: 100vh;
  box-sizing: border-box; /* 加盒模型，避免padding溢出 */
}
.header { 
  margin-bottom: 30rpx; 
}
.header-text { 
  font-size: 36rpx; 
  font-weight: bold; 
  color: #e64340; 
}
.loading {
  text-align: center;
  padding: 100rpx 0;
  color: #999;
  font-size: 28rpx;
}
.list {
  gap: 15rpx;
  display: flex; /* 加 flex 布局，gap 生效 */
  flex-direction: column;
}
.card {
  position: relative;
  background: white;
  padding: 30rpx;
  border-radius: 16rpx;
  margin-bottom: 15rpx;
  box-shadow: 0 2rpx 8rpx rgba(0,0,0,0.05);
  transition: transform 0.2s;
}
.card:active {
  transform: scale(0.98);
}
.unread-tag {
  position: absolute;
  top: 20rpx;
  right: 20rpx;
  background: #e64340;
  color: white;
  font-size: 22rpx;
  padding: 4rpx 12rpx;
  border-radius: 12rpx;
}
.title { 
  font-weight: bold; 
  font-size: 32rpx; 
  margin-bottom: 10rpx; 
  color: #333; 
}
.time { 
  color: #999; 
  font-size: 26rpx; 
}
.stats-btn {
  position: absolute;
  bottom: 20rpx;
  right: 20rpx;
  background: #1890ff;
  color: white;
  font-size: 24rpx;
  padding: 4rpx 12rpx;
  border-radius: 12rpx;
  border: none; /* 去掉按钮默认边框 */
}
.empty {
  text-align: center;
  margin-top: 100rpx;
}
.empty-icon {
  font-size: 80rpx;
  display: block;
  margin-bottom: 20rpx;
  color: #ccc; /* 加颜色，更美观 */
}
.empty-text {
  font-size: 30rpx;
  color: #666;
  display: block;
  margin-bottom: 10rpx;
}
.empty-desc {
  font-size: 26rpx;
  color: #999;
}
.modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
}
.modal-content {
  background: white;
  padding: 40rpx;
  border-radius: 16rpx;
  width: 80%;
  max-width: 600rpx;
  text-align: center;
}
.modal-title {
  font-size: 36rpx;
  font-weight: bold;
  color: #333;
  margin-bottom: 20rpx;
}
.modal-subtitle {
  font-size: 30rpx;
  color: #666;
  margin-bottom: 10rpx;
}
.modal-rate {
  font-size: 28rpx;
  color: #e64340;
  margin-bottom: 20rpx;
}
.modal-close-btn {
  background: #1890ff;
  color: white;
  padding: 10rpx 20rpx;
  border-radius: 12rpx;
  border: none; /* 去掉按钮默认边框 */
}
</style>