<template>
  <view class="home-container">
    <!-- 1. 顶部Banner大图 -->
    <view class="banner-container">
      <image 
        class="banner-img" 
        src="/static/images/disaster-banner.png" 
        mode="widthFix"
      ></image>
      <!-- 大图上的文字叠加 -->
      <view class="banner-text">
        <text class="banner-title">守护家园 科学防灾</text>
        <text class="banner-subtitle">乡村灾情预警与上报平台</text>
      </view>
    </view>

    <!-- 2. 顶部信息栏：移到Banner下方 -->
    <view class="header">
      <!-- 未登录状态 -->
      <view class="user-info" v-if="!isLogin">
        <text class="greeting">你好，游客</text>
        <text class="village">登录后查看所属村庄及完整功能</text>
      </view>
      <!-- 已登录状态 -->
      <view class="user-info" v-else>
        <text class="greeting">你好，{{ userInfo.username }}（{{ getRoleText() }}）</text>
        <text class="village">所属村庄：{{ villageName }}</text>
      </view>
      <!-- 登录/退出按钮 -->
      <button v-if="!isLogin" @click="goMine" class="login-btn">登录</button>
      <button v-else @click="handleLogout" class="logout-btn">退出</button>
    </view>

    <!-- 3. 保留：最新公告/预警轮播区（未登录也能看） -->
    <view class="notice-swiper" @click="goNoticeDetail">
      <swiper :indicator-dots="true" :autoplay="true" :interval="3000" :duration="500" class="swiper">
        <swiper-item v-for="(item, index) in noticeList" :key="index">
          <view class="swiper-item">
            <text class="notice-tag" :class="item.type === 'warning' ? 'tag-warning' : 'tag-normal'">
              {{ item.type === 'warning' ? '预警' : '公告' }}
            </text>
            <text class="notice-title">{{ item.title }}</text>
            <text class="notice-time">{{ item.time }}</text>
          </view>
        </swiper-item>
      </swiper>
    </view>

    <!-- 4. 保留：本村灾情速报区（未登录也能看，登录后更详细） -->
    <view class="disaster-quick">
      <view class="section-title">📊 本村灾情速报</view>
      <view class="disaster-list">
        <view class="disaster-item" v-for="(item, index) in disasterList" :key="index" @click="goDisasterDetail(item.id)">
          <view class="disaster-type" :class="item.level === 'high' ? 'level-high' : 'level-normal'">
            {{ item.type }}
          </view>
          <view class="disaster-info">
            <text class="disaster-title">{{ item.title }}</text>
            <text class="disaster-time">{{ item.time }}</text>
          </view>
        </view>
      </view>
    </view>

    <!-- 新增：引导到服务页的提示 -->
    <view class="guide-to-service">
      <text class="guide-text">更多功能请前往「服务中心」</text>
      <button @click="goService" class="go-service-btn">进入服务中心</button>
    </view>
  </view>
</template>

<script>
import { getUserInfo, logout } from '@/utils/auth'

export default {
  data() {
    return {
      userInfo: {},
      villageName: 'XX村',
      isLogin: false, // 登录状态标识
      role: 0, // 角色 1=村民 2=信息员 3=管理员
      // 公告/预警轮播数据（模拟）
      noticeList: [
        {
          id: 1,
          type: 'warning',
          title: '暴雨蓝色预警：未来24小时有强降雨',
          time: '2025-10-20 08:30'
        },
        {
          id: 2,
          type: 'normal',
          title: '关于开展本村防灾演练的通知',
          time: '2025-10-19 16:00'
        }
      ],
      // 本村灾情速报数据（模拟）
      disasterList: [
        {
          id: 1,
          type: '山体滑坡',
          level: 'high',
          title: '村东山体出现小型滑坡，已封锁道路',
          time: '2025-10-19 14:20'
        },
        {
          id: 2,
          type: '农作物受灾',
          level: 'normal',
          title: '部分农田受淹，正在组织排涝',
          time: '2025-10-18 10:15'
        }
      ]
    }
  },
  onShow() {
    // 刷新登录状态
    this.checkLoginStatus()
    // 监听登录成功事件
    uni.$on('loginSuccess', () => {
      this.checkLoginStatus()
    })
  },
  onUnload() {
    // 移除事件监听
    uni.$off('loginSuccess')
  },
  methods: {
    /** 检查登录状态 */
    checkLoginStatus() {
      this.userInfo = getUserInfo() || {}
      this.isLogin = !!this.userInfo.userId
      this.role = this.userInfo.role || 1
      this.villageName = this.userInfo.villageId ? `第${this.userInfo.villageId}村` : '未知村庄'
    },

    /** 跳转到我的页面登录 */
    goMine() {
      uni.switchTab({ url: '/pages/mine/index' })
    },

    /** 跳转到服务中心 */
    goService() {
      uni.switchTab({ url: '/pages/service/index' }) // 替换成你服务页的实际路径
    },

    /** 获取角色文本 */
    getRoleText() {
      const roleMap = {
        1: '村民',
        2: '信息员',
        3: '乡镇管理员'
      }
      return roleMap[this.role] || '村民'
    },

    /** 退出登录 */
    handleLogout() {
      logout()
      this.checkLoginStatus()
      uni.showToast({ title: '退出成功', icon: 'success' })
    },

    /** 公告/预警详情跳转 */
    goNoticeDetail() {
      if (!this.isLogin) {
        this.loginTip('查看公告/预警详情')
        return
      }
      uni.navigateTo({ url: '/pages/warning/detail?id=1' })
    },

    /** 灾情详情跳转 */
    goDisasterDetail(id) {
      if (!this.isLogin) {
        this.loginTip('查看灾情详情')
        return
      }
      uni.navigateTo({ url: `/pages/report/detail?id=${id}` })
    },

    /** 统一登录提示弹窗 */
    loginTip(operateName) {
      uni.showModal({
        title: '提示',
        content: `请先登录后${operateName}`,
        confirmText: '去登录',
        cancelText: '取消',
        success: (res) => {
          if (res.confirm) {
            this.goMine()
          }
        }
      })
    }
  }
}
</script>

<style scoped>
.home-container {
  padding: 0; /* 移除默认padding，让Banner全屏 */
  background-color: #f8f8f8;
  min-height: 100vh;
}

/* 1. Banner大图样式 */
.banner-container {
  position: relative;
  width: 100%;
}
.banner-img {
  width: 100%;
  height: auto;
  border-radius: 0 0 20rpx 20rpx; /* 底部圆角 */
}
.banner-text {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  text-align: center;
  color: white;
  text-shadow: 0 2rpx 4rpx rgba(0,0,0,0.5); /* 文字阴影更醒目 */
}
.banner-title {
  font-size: 40rpx;
  font-weight: bold;
  display: block;
  margin-bottom: 10rpx;
}
.banner-subtitle {
  font-size: 28rpx;
  display: block;
}

/* 2. 顶部信息栏样式（微调） */
.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: white;
  padding: 30rpx;
  margin: 20rpx 20rpx 0; /* 调整margin */
  border-radius: 16rpx;
  box-shadow: 0 2rpx 8rpx rgba(0,0,0,0.05);
}
.user-info {
  display: flex;
  flex-direction: column;
  gap: 10rpx;
}
.greeting {
  font-size: 32rpx;
  font-weight: bold;
  color: #333;
}
.village {
  font-size: 26rpx;
  color: #666;
}
.login-btn {
  background: #1890ff;
  color: white;
  padding: 15rpx 25rpx;
  border-radius: 8rpx;
  font-size: 26rpx;
}
.logout-btn {
  background: #ff4d4f;
  color: white;
  padding: 15rpx 25rpx;
  border-radius: 8rpx;
  font-size: 26rpx;
}

/* 3. 公告/预警轮播区样式（保留） */
.notice-swiper {
  background: white;
  border-radius: 16rpx;
  margin: 20rpx;
  box-shadow: 0 2rpx 8rpx rgba(0,0,0,0.05);
  overflow: hidden;
}
.swiper {
  height: 160rpx;
}
.swiper-item {
  padding: 30rpx;
  position: relative;
}
.notice-tag {
  font-size: 22rpx;
  padding: 4rpx 12rpx;
  border-radius: 12rpx;
  margin-bottom: 15rpx;
  display: inline-block;
}
.tag-warning {
  background: #e64340;
  color: white;
}
.tag-normal {
  background: #1890ff;
  color: white;
}
.notice-title {
  font-size: 28rpx;
  font-weight: bold;
  color: #333;
  display: block;
  margin-bottom: 10rpx;
}
.notice-time {
  font-size: 24rpx;
  color: #999;
}

/* 4. 本村灾情速报区样式（保留） */
.disaster-quick {
  background: white;
  border-radius: 16rpx;
  margin: 0 20rpx 20rpx;
  box-shadow: 0 2rpx 8rpx rgba(0,0,0,0.05);
  padding: 30rpx;
}
.section-title {
  font-size: 28rpx;
  font-weight: bold;
  color: #333;
  margin-bottom: 20rpx;
}
.disaster-list {
  gap: 15rpx;
}
.disaster-item {
  display: flex;
  align-items: center;
  padding: 20rpx 0;
  border-bottom: 1rpx solid #f0f0f0;
}
.disaster-item:last-child {
  border-bottom: none;
}
.disaster-type {
  font-size: 22rpx;
  padding: 6rpx 12rpx;
  border-radius: 12rpx;
  margin-right: 20rpx;
  color: white;
}
.level-high {
  background: #e64340;
}
.level-normal {
  background: #faad14;
}
.disaster-info {
  flex: 1;
}
.disaster-title {
  font-size: 26rpx;
  color: #333;
  display: block;
  margin-bottom: 5rpx;
}
.disaster-time {
  font-size: 22rpx;
  color: #999;
}

/* 5. 引导到服务页的样式 */
.guide-to-service {
  text-align: center;
  margin: 20rpx;
  padding: 30rpx;
  background: white;
  border-radius: 16rpx;
  box-shadow: 0 2rpx 8rpx rgba(0,0,0,0.05);
}
.guide-text {
  font-size: 28rpx;
  color: #666;
  display: block;
  margin-bottom: 20rpx;
}
.go-service-btn {
  background: #1890ff;
  color: white;
  padding: 20rpx 40rpx;
  border-radius: 8rpx;
  font-size: 28rpx;
}
</style>