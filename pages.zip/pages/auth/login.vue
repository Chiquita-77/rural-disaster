<template>
  <view class="login-container">
    <text class="title">灾害预警与防灾指导平台</text>
    
    <view class="form">
      <view class="input-item">
        <text class="label">用户名/手机号</text> <!-- 提示更友好 -->
        <input v-model="phone" type="text" placeholder="请输入手机号" class="input" />
      </view>
      <view class="input-item">
        <text class="label">密码</text>
        <input v-model="password" type="password" placeholder="请输入密码" class="input" />
      </view>
      <view class="input-item">
        <text class="label">角色选择</text>
        <picker @change="onRoleChange" :value="roleIndex" :range="roleList" class="picker">
          <view class="picker-text">{{ roleList[roleIndex] }}</view>
        </picker>
      </view>
      
      <button @click="handleLogin" class="btn login-btn">登录</button>
      <button @click="goRegister" class="btn register-btn">注册账号</button>
    </view>
  </view>
</template>

<script>
import { post } from '@/utils/request'
import { setUserInfo, getCurrentUserId } from '@/utils/auth'

export default {
  data() {
    return {
      phone: '', // 核心修正：改为phone，匹配后端接口
      password: '',
      roleList: ['村民', '村级信息员', '乡镇管理员'],
      roleIndex: 0,
      roleMap: { 0: 1, 1: 2, 2: 3 } // 1=村民, 2=信息员, 3=管理员
    }
  },
  onShow() {
    // 已登录则自动跳转首页
    if (getCurrentUserId()) {
      this.redirectToHome()
    }
  },
  methods: {
    onRoleChange(e) {
      this.roleIndex = e.detail.value
    },
    async handleLogin() {
      // 校验输入
      if (!this.phone || !this.password) {
        return uni.showToast({ title: '手机号/密码不能为空', icon: 'none' })
      }
      
      try {
        // 核心修正：传参改为phone，匹配后端接口
        const res = await post('/user/login', {
          phone: this.phone,
          password: this.password,
          role: this.roleMap[this.roleIndex]
        })
        
        if (res.code === 200) {
          setUserInfo(res.data) // 存储用户信息
          uni.showToast({ title: '登录成功', icon: 'success' })
          this.redirectToHome()
        } else {
          uni.showToast({ title: res.msg || '登录失败', icon: 'none' })
        }
      } catch (err) {
        console.error('登录异常：', err)
        uni.showToast({ title: '网络异常，请重试', icon: 'none' })
      }
    },
    goRegister() {
      uni.navigateTo({ url: '/pages/auth/register' })
    },
    redirectToHome() {
      const user = uni.getStorageSync('userInfo')
      if (!user) return
      
      // 按角色跳转对应首页
      if (user.role === 1) {
        uni.switchTab({ url: '/pages/index/index' })
      } else if (user.role === 2) {
        uni.switchTab({ url: '/pages/village/list' })
      } else if (user.role === 3) {
        uni.switchTab({ url: '/pages/admin/index' })
      }
    }
  }
}
</script>

<style scoped>
.login-container { 
  padding: 60rpx 40rpx; 
  background-color: #f8f8f8;
  min-height: 100vh;
}
.title { 
  display: block;
  font-size: 48rpx; 
  text-align: center;
  margin-bottom: 80rpx; 
  color: #e64340; 
  font-weight: bold;
}
.form {
  background: white;
  padding: 40rpx;
  border-radius: 20rpx;
  box-shadow: 0 4rpx 12rpx rgba(0,0,0,0.05);
}
.input-item {
  margin-bottom: 30rpx;
}
.label {
  display: block;
  font-size: 28rpx;
  color: #333;
  margin-bottom: 10rpx;
}
.input, .picker-text {
  padding: 20rpx;
  border: 1rpx solid #eee;
  border-radius: 12rpx;
  font-size: 28rpx;
  color: #666;
}
.picker {
  border: 1rpx solid #eee;
  border-radius: 12rpx;
}
.picker-text {
  padding: 20rpx;
}
.btn {
  width: 100%;
  padding: 24rpx;
  border-radius: 12rpx;
  color: white;
  font-size: 32rpx;
  margin-top: 20rpx;
}
.login-btn {
  background: #1890ff;
}
.register-btn {
  background: #52c41a;
}
</style>