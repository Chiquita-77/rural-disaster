<template>
  <view class="register-container">
    <text class="title">用户注册</text>

    <view class="form">
      <view class="input-item">
        <text class="label">用户名</text>
        <input v-model="form.username" type="text" placeholder="请输入用户名" class="input" />
      </view>
      <view class="input-item">
        <text class="label">手机号</text>
        <input v-model="form.phone" type="number" placeholder="请输入11位手机号" class="input" />
      </view>
      <view class="input-item">
        <text class="label">密码</text>
        <input v-model="form.password" type="password" placeholder="请输入6位以上密码" class="input" />
      </view>
      <view class="input-item">
        <text class="label">确认密码</text>
        <input v-model="form.confirmPassword" type="password" placeholder="请再次输入密码" class="input" />
      </view>
      <view class="input-item">
        <text class="label">角色选择</text>
        <picker @change="onRoleChange" :value="roleIndex" :range="roleList" class="picker">
          <view class="picker-text">{{ roleList[roleIndex] }}</view>
        </picker>
      </view>

      <!-- 村民/信息员：选择村庄 -->
      <view class="input-item" v-if="form.role === 1 || form.role === 2">
        <text class="label">所属村庄</text>
        <picker 
          @change="onVillageChange" 
          :value="villageIndex" 
          :range="villageList" 
          range-key="villageName" 
          class="picker"
        >
          <view class="picker-text">
            {{ villageList[villageIndex]?.villageName || '加载中...' }}
          </view>
        </picker>
      </view>

      <!-- 管理员：选择乡镇（暂时先保留模拟，后面同理） -->
      <view class="input-item" v-if="form.role === 3">
        <text class="label">所属乡镇</text>
        <picker @change="onTownChange" :value="townIndex" :range="townList" range-key="name" class="picker">
          <view class="picker-text">{{ townList[townIndex]?.name || '请选择乡镇' }}</view>
        </picker>
      </view>

      <button @click="handleRegister" class="btn register-btn">注册</button>
      <button @click="goLogin" class="btn back-login-btn">返回登录</button>
    </view>
  </view>
</template>

<script>
import { post, get } from '@/utils/request'

export default {
  data() {
    return {
      form: {
        username: '',
        phone: '',
        password: '',
        confirmPassword: '',
        role: 1, // 默认村民
        villageId: null,
        townId: null
      },
      roleList: ['村民', '村级信息员', '乡镇管理员'],
      roleIndex: 0,
      roleMap: { 0: 1, 1: 2, 2: 3 }, // 对应后端role字段
      // 从接口拉取的村庄列表
      villageList: [],
      villageIndex: 0,
      // 乡镇列表暂时先保留模拟，后面同理
      townList: [
        { id: 1, name: 'A镇' },
        { id: 2, name: 'B镇' }
      ],
      townIndex: 0
    }
  },
  async onLoad() {
    // 页面加载时拉取村庄列表
    await this.loadVillageList()
  },
  methods: {
    /** 加载所有村庄列表 */
    async loadVillageList() {
      try {
        const res = await get('/village/list')
        if (res.code === 200 && res.data) {
          this.villageList = res.data
          // 默认选中第一个村庄
          if (this.villageList.length > 0) {
            this.villageIndex = 0
            this.form.villageId = this.villageList[0].villageId
          }
        } else {
          uni.showToast({ title: '加载村庄列表失败', icon: 'none' })
        }
      } catch (err) {
        console.error('加载村庄列表异常：', err)
        uni.showToast({ title: '网络异常，请重试', icon: 'none' })
      }
    },

    onRoleChange(e) {
      this.roleIndex = e.detail.value
      this.form.role = this.roleMap[this.roleIndex]
      // 切换角色时清空关联字段
      this.form.villageId = null
      this.form.townId = null
    },
    onVillageChange(e) {
      this.villageIndex = e.detail.value
      this.form.villageId = this.villageList[this.villageIndex].villageId
    },
    onTownChange(e) {
      this.townIndex = e.detail.value
      this.form.townId = this.townList[this.townIndex].id
    },
    async handleRegister() {
      // 前端校验
      if (!this.form.username || !this.form.phone || !this.form.password || !this.form.confirmPassword) {
        return uni.showToast({ title: '请填写完整信息', icon: 'none' })
      }
      if (!/^1[3-9]\d{9}$/.test(this.form.phone)) {
        return uni.showToast({ title: '请输入正确的手机号', icon: 'none' })
      }
      if (this.form.password.length < 6) {
        return uni.showToast({ title: '密码长度不能少于6位', icon: 'none' })
      }
      if (this.form.password !== this.form.confirmPassword) {
        return uni.showToast({ title: '两次输入的密码不一致', icon: 'none' })
      }
      if ((this.form.role === 1 || this.form.role === 2) && !this.form.villageId) {
        return uni.showToast({ title: '请选择所属村庄', icon: 'none' })
      }
      if (this.form.role === 3 && !this.form.townId) {
        return uni.showToast({ title: '请选择所属乡镇', icon: 'none' })
      }

      try {
        const res = await post('/user/register', {
          username: this.form.username,
          phone: this.form.phone,
          password: this.form.password,
          role: this.form.role,
          villageId: this.form.villageId,
          townId: this.form.townId
        })

        if (res.code === 200) {
          uni.showToast({ title: '注册成功，请登录', icon: 'success' })
          uni.switchTab({ url: '/pages/mine/index' })
        } else {
          uni.showToast({ title: res.msg || '注册失败', icon: 'none' })
        }
      } catch (err) {
        console.error('注册异常：', err)
        uni.showToast({ title: '网络异常，请重试', icon: 'none' })
      }
    },
    goLogin() {
      uni.switchTab({ url: '/pages/mine/index' })
    }
  }
}
</script>

<style scoped>
.register-container {
  padding: 60rpx 40rpx;
  background-color: #f8f8f8;
  min-height: 100vh;
}
.title {
  display: block;
  font-size: 48rpx;
  text-align: center;
  margin-bottom: 60rpx;
  color: #1890ff;
  font-weight: bold;
}
.form {
  background: white;
  padding: 40rpx;
  border-radius: 20rpx;
  box-shadow: 0 4rpx 12rpx rgba(0,0,0,0.05);
}
.input-item {
  margin-bottom: 30rpx;
}
.label {
  display: block;
  font-size: 28rpx;
  color: #333;
  margin-bottom: 10rpx;
}
.input, .picker-text {
  padding: 20rpx;
  border: 1rpx solid #eee;
  border-radius: 12rpx;
  font-size: 28rpx;
  color: #666;
}
.picker {
  border: 1rpx solid #eee;
  border-radius: 12rpx;
}
.picker-text {
  padding: 20rpx;
}
.btn {
  width: 100%;
  padding: 24rpx;
  border-radius: 12rpx;
  color: white;
  font-size: 32rpx;
  margin-top: 20rpx;
}
.register-btn {
  background: #1890ff;
}
.back-login-btn {
  background: #999;
}
</style>