<template>
  <view class="login-container">
    <!-- 标题 -->
    <view class="title">管理员验证</view>

    <!-- 账号输入框 -->
    <view class="form-item">
      <text class="label">管理员账号 *</text>
      <input
        v-model="formData.username"
        class="input"
        placeholder="请输入管理员账号"
        maxlength="20"
      />
    </view>

    <!-- 密码输入框 -->
    <view class="form-item">
      <text class="label">管理员密码 *</text>
      <input
        v-model="formData.password"
        class="input"
        type="password"
        placeholder="请输入管理员密码"
        maxlength="20"
      />
    </view>

    <!-- 登录按钮 -->
    <button class="login-btn" @click="handleLogin" :loading="submitting">
      {{ submitting ? '验证中...' : '验证并进入发布' }}
    </button>
  </view>
</template>

<script>
export default {
  data() {
    return {
      // 1. 接收从村庄详情页传递的村庄参数
      villageId: '',
      villageName: '',
      submitting: false,
      formData: {
        username: '', // 用户输入的账号
        password: ''  // 用户输入的密码
      },
      // 2. 预设的管理员账号密码（可自行修改）
      adminConfig: {
        username: 'admin',   // 固定账号
        password: '123456'   // 固定密码
      }
    }
  },

  // 3. 页面加载时接收村庄参数
  onLoad(options) {
    // 拿到上一页传递的村庄ID和名称
    this.villageId = options.villageId || ''
    this.villageName = options.villageName || ''
  },

  methods: {
    // 4. 核心：登录验证+跳转逻辑
    handleLogin() {
      // 第一步：前端空值校验
      if (!this.formData.username.trim()) {
        uni.showToast({ title: '请输入管理员账号', icon: 'none' })
        return
      }
      if (!this.formData.password.trim()) {
        uni.showToast({ title: '请输入管理员密码', icon: 'none' })
        return
      }

      this.submitting = true

      // 第二步：校验账号密码是否正确
      if (
        this.formData.username !== this.adminConfig.username ||
        this.formData.password !== this.adminConfig.password
      ) {
        // 密码错误：提示+终止流程
        uni.showToast({ title: '账号或密码错误', icon: 'none', duration: 2000 })
        this.submitting = false
        return
      }

      // 第三步：密码正确：跳转到发布预警页，携带村庄参数
      uni.navigateTo({
        url: `/pages/warning/publish?villageId=${this.villageId}&villageName=${this.villageName}`
      })
      this.submitting = false
    }
  }
}
</script>

<style scoped>
.login-container {
  padding: 40rpx 30rpx;
  background-color: #f8f9fa;
  min-height: 100vh;
}

.title {
  font-size: 36rpx;
  font-weight: bold;
  color: #333;
  text-align: center;
  margin-bottom: 60rpx;
  margin-top: 100rpx;
}

.form-item {
  margin-bottom: 40rpx;
}

.label {
  display: block;
  font-size: 28rpx;
  color: #333;
  margin-bottom: 16rpx;
  font-weight: bold;
}

.input {
  width: 100%;
  height: 80rpx;
  padding: 0 20rpx;
  background: white;
  border-radius: 12rpx;
  font-size: 28rpx;
  color: #333;
  box-sizing: border-box;
}

.login-btn {
  width: 100%;
  height: 90rpx;
  background: #e64340;
  color: white;
  font-size: 32rpx;
  border-radius: 16rpx;
  margin-top: 60rpx;
  border: none;
}
</style>